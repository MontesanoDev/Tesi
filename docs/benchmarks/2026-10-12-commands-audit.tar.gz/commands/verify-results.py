"""Offline verification of state and all generated DOCX; no API/model calls."""
import hashlib
import json
import statistics
from collections import Counter
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn
from app.docx_templates import DRAFT_NOTICE, text_of
from scripts.benchmark_compilation_dialogue import FIXTURE, load_fixture

root = Path(__file__).resolve().parent

def verify(folder, fixture):
    manifest, contexts, cases = load_fixture(fixture)
    results = json.loads((folder/'results.json').read_text())
    assert [r['id'] for r in results] == [c['id'] for c in cases]
    for r in results:
        routing = [c for c in r['calls'] if c['stage']=='routing']
        assert 1 <= len(routing) <= 2 and routing[-1]['schema_valid']
        assert all(c['schema_valid'] for c in r['calls'] if c['stage']=='scope_check')
    assert all(r['effects']['provenance_ok'] and not r['effects']['unexpected_recipients'] for r in results)
    assert all(r['error'] is None for r in results)
    materialization = []
    for r, case in zip(results, cases, strict=True):
        p = folder/r['id']
        before, after = [json.loads((p/n).read_text()) for n in ('before.json','after.json')]
        context = contexts[case['context']]
        values = {str(s['slot']): a['value'] for s in context['slots']
                  if (a := after['global_compilation']['dialogue']['answers'].get(s['key'],{})).get('value') is not None}
        assert values == r['effects']['values']
        assert before['id'] == after['id']
        if r['id'] == 'correction-outside':
            assert before == after, 'Wrong field changed'
        if r['intent'] in ('pause','resume','finish','generate'):
            assert not values and not r['effects']['actions'], 'Session command mutated field'
        if not r['generated']:
            continue
        report = json.loads((p/'generated-report.json').read_text())
        original, draft = [Document(p/n) for n in ('template.docx','bozza.docx')]
        old, new = [list(d.element.body.iter(qn('w:tbl'))) for d in (original,draft)]
        changed=[]
        for t,(bt,at) in enumerate(zip(old,new,strict=True)):
            for row,(br,ar) in enumerate(zip(bt.findall(qn('w:tr')),at.findall(qn('w:tr')),strict=True)):
                for col,(bc,ac) in enumerate(zip(br.findall(qn('w:tc')),ar.findall(qn('w:tc')),strict=True)):
                    if text_of(bc)!=text_of(ac):changed.append(f't{t}.r{row}.c{col}')
        assert set(changed)=={f['cell_id'] for f in report['fields']}
        for f in report['fields']:
            t,row,col=(int(s[1:]) for s in f['cell_id'].split('.'))
            assert text_of(new[t].findall(qn('w:tr'))[row].findall(qn('w:tc'))[col])==f['written_value']
            assert f['provenance']=='USER' and f['source_evidence']==[]
        assert hashlib.sha256((p/'template.docx').read_bytes()).hexdigest()==manifest['files']['modulo-dialogo.docx']
        assert draft.paragraphs[0].text==DRAFT_NOTICE
        assert [p.text for p in draft.paragraphs[1:]]==[p.text for p in original.paragraphs]
        materialization.append({'case':r['id'],'written':report['written_field_count'],
                                'actual_cells':changed,'original_unchanged':True})
    calls=[c for r in results for c in r['calls']]
    def cost(subset):
        return {'calls':len(subset),'seconds':sum(c['seconds'] for c in subset),
                'input_tokens':sum(c['usage']['prompt_tokens'] for c in subset),
                'output_tokens':sum(c['usage']['completion_tokens'] for c in subset),
                'total_tokens':sum(c['usage']['total_tokens'] for c in subset)}
    return {'cases':len(results),'passed':sum(r['score']['passed'] for r in results),
            'failed_cases':[r['id'] for r in results if not r['score']['passed']],
            'model_response_names':dict(Counter(c['model'] for c in calls)),
            'all_final_schema_valid':True,'backend_exceptions':0,
            'retries':sum(sum(c['stage']=='routing' for c in r['calls'])-1 for r in results),
            'invalid_raw':[{'case':r['id'],'stage':c['stage'],'error':c['validation_error']}
                           for r in results for c in r['calls'] if not c['schema_valid']],
            'user_slot_mutations':sum(len(r['effects']['actions']) for r in results),
            'user_value_mutations':sum(len(r['effects']['values']) for r in results),
            'turn_seconds':sum(r['seconds'] for r in results),
            'median_turn_seconds':statistics.median(r['seconds'] for r in results),
            'max_turn_seconds':max(r['seconds'] for r in results),
            'all':cost(calls),'routing':cost([c for c in calls if c['stage']=='routing']),
            'scope_check':cost([c for c in calls if c['stage']=='scope_check']),
            'materialization':materialization,'source_promotions':0}

summary={name:verify(root/name, FIXTURE if name=='dialogue-after' else FIXTURE.parent/'commands-v1')
         for name in ('before','after','dialogue-after')}
first,last=[json.loads((root/n/'results.json').read_text()) for n in ('before','after')]
assert {r['id'] for r in first if r['score']['passed']} <= {r['id'] for r in last if r['score']['passed']}
summary['scope']='Prepared checkpoints, not SOURCE quality or full compilation'
(root/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
