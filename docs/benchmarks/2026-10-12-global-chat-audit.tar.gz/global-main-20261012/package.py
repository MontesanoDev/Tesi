"""Archive acquired evidence only; never archive runtime DB or keys."""
import hashlib
import json
import shutil
import sqlite3
import tarfile
from pathlib import Path

from cryptography.fernet import Fernet
from app.db import DEFAULT_DB_PATH

root=Path('data/compilation-audit/global-main-20261012').resolve()
public=Path('../docs/benchmarks').resolve()
archive=public/'2026-10-12-global-chat-audit.tar.gz'
private=root/'runtime'
cipher=Fernet(DEFAULT_DB_PATH.with_suffix('.ai-key').read_bytes())
with sqlite3.connect(f'file:{DEFAULT_DB_PATH.resolve()}?mode=ro',uri=True) as db:
 secrets=[cipher.decrypt(row[0].encode()) for row in db.execute('SELECT encrypted_api_key FROM ai_profiles WHERE encrypted_api_key IS NOT NULL') if row[0]]
assert private.is_dir() and private.parent==root
# All useful persisted state and generated artifacts were already copied above.
assert (root/'materialization.json').is_file()
shutil.rmtree(private)
integrity=json.loads((root/'real-integrity.json').read_text())
integrity.update(runtime_retained_until_explicit_export=False,temporary_private_runtime_removed=True)
(root/'real-integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name not in {'archive-inventory.json','package.log'})
inventory={}
for path in files:
 assert not (path.suffix in {'.db','.sqlite','.ai-key'} or path.name.startswith('.env')),path
 data=path.read_bytes()
 assert not any(secret in data for secret in secrets),f'Credential in {path.relative_to(root)}'
 inventory[str(path.relative_to(root))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(root/'archive-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
files.append(root/'archive-inventory.json')
with tarfile.open(archive,'w:gz') as bundle:
 for path in files:
  bundle.add(path,arcname='global-main-20261012/'+str(path.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
 members=bundle.getmembers()
 assert len(members)==len(files)
 for member in members:
  path=root/member.name.split('/',1)[1]
  assert member.isfile() and bundle.extractfile(member).read()==path.read_bytes()
checks={'archive':archive.name,'files':len(files),'bytes':archive.stat().st_size,
 'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'byte_for_byte_verified':True,
 'configured_credentials_absent':True,'no_database_or_private_configuration':True,
 'temporary_private_runtime_removed':True,'live_data_integrity':integrity,
 'software':{'backend':1847,'frontend':101,'browser':8,'ruff':True,'frontend_lint':True,'frontend_build':True}}
(public/'2026-10-12-global-chat-final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
