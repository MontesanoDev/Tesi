"""Explicit controlled review of already acquired proposals; zero provider calls."""
import asyncio
import hashlib
import json
import os
from io import BytesIO
from pathlib import Path

import httpx
from docx import Document
from lxml import etree
from docx.oxml.ns import qn

from app.main import app
from app.docx_templates import text_of, DRAFT_NOTICE
from app.db import DEFAULT_DB_PATH, DEFAULT_STORAGE_PATH

ROOT=Path('data/compilation-audit/global-main-20261012').resolve()
RUNTIME=ROOT/'runtime'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def save(path,data):
    (ROOT/path).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
selections={
 'catanzaro': {'ids':['t0.r5.c1','t0.r6.c1','t0.r7.c1','t0.r9.c1','t0.r10.c1','t26.r0.c1','t26.r1.c1','t26.r3.c1','t26.r4.c1'],
 'conditions':['c_part','c_soc_ing'], 'note':'Controlled USER confirmation for test draft: participation and engineering-company branch. No USER factual values. Operative address excluded pending conditional review.'},
 'labirinto': {'ids':None,'conditions':['c_4c'], 'note':'Controlled USER confirmation for test draft: engineering-company branch in fixture scenario. No USER factual values; alternatives, checkboxes and omissions excluded.'}}
save('review-protocol.json',selections)

async def main():
 outcomes={}
 async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://isolated') as client:
  for name,review in selections.items():
   db,uploads=('snapshot.db','uploads') if name=='catanzaro' else ('fixture.db','fixture-uploads')
   os.environ.update(MAPI_DB_PATH=str(RUNTIME/db),MAPI_STORAGE_PATH=str(RUNTIME/uploads))
   state=json.loads((ROOT/name/'state.json').read_text())
   ids=review['ids'] or [f['candidate_id'] for f in state['global_compilation']['fields'] if f['selectable']]
   body={'version':state['version'],'candidate_ids':ids,'confirmed_condition_ids':review['conditions'],'allow_unresolved':True}
   base=f"/api/projects/{state['project_id']}/compilation-sessions/{state['id']}"
   save(f'{name}/review-request.json',body)
   previous=ROOT/name/'export-response.json'
   if not previous.exists() or json.loads(previous.read_text())['status']!=200:
    response=await client.post(base+'/global-draft',json=body)
    save(f'{name}/export-response.json',{'status':response.status_code,'body':response.json()})
    assert response.status_code==200,response.text
   final=(await client.get(base)).json()
   save(f'{name}/generated-state.json',final)
   for kind,filename in [('docx','bozza.docx'),('report','report.json'),('template','original.docx')]:
    response=await client.get(final['last_generation']['downloads'][kind])
    assert response.status_code==200,response.text
    (ROOT/name/filename).write_bytes(response.content)
   report=json.loads((ROOT/name/'report.json').read_text())
   original=(ROOT/name/'original.docx').read_bytes()
   generated=(ROOT/name/'bozza.docx').read_bytes()
   assert sha(original)==state['template_sha256']
   assert final['summary']['resolved']==0 and final['fields']==[]
   document,template=Document(BytesIO(generated)),Document(BytesIO(original))
   tables=list(document.element.body.iter(qn("w:tbl")))
   originals=list(template.element.body.iter(qn("w:tbl")))
   checks=[]
   for field in report['fields']:
    cid=field['cell_id']
    t,row,col=(int(p[1:]) for p in cid.split('.'))
    actual=text_of(tables[t].findall(qn("w:tr"))[row].findall(qn("w:tc"))[col])
    prior=text_of(originals[t].findall(qn("w:tr"))[row].findall(qn("w:tc"))[col])
    checks.append({'candidate_id':cid,'value':field['written_value'],'actual':actual,'original':prior,
     'match':actual==field['written_value'],'provenance':field['provenance'],'reviewed_by':field['reviewed_by'],
     'source_evidence':field['source_evidence']})
    assert actual==field['written_value']
    assert field['provenance']=='SOURCE' and field['reviewed_by']=='USER'
   changes=[]
   for t,(before,after) in enumerate(zip(originals,tables,strict=True)):
    for row,(old,new) in enumerate(zip(before.findall(qn("w:tr")),after.findall(qn("w:tr")),strict=True)):
     for col,(a,b) in enumerate(zip(old.findall(qn("w:tc")),new.findall(qn("w:tc")),strict=True)):
      if text_of(a)!=text_of(b):
       changes.append(f't{t}.r{row}.c{col}')
   assert set(changes)==set(ids),(changes,ids)
   assert document.paragraphs[0].text==DRAFT_NOTICE
   assert [p.text for p in template.paragraphs]==[p.text for p in document.paragraphs[1:]]
   assert [etree.tostring(n,method="c14n") for n in template.element.iter(qn('w:sdt'))]==[etree.tostring(n,method="c14n") for n in document.element.iter(qn('w:sdt'))]
   outcomes[name]={'selected_count':len(ids),'written_count':len(checks),'checks':checks,'changed_cells':changes,
    'exactly_selected_cells_changed':True,'native_controls_unchanged':True,'original_unchanged':True,
    'resolved':0,'user_factual_values':0,'status':final['status'],'source_values_user_reviewed':len(checks),
    'unselected_fields_unmodified':True,'draft_only':True}
   print(name,'GENERATED',len(checks),'SOURCE values / explicit USER review',flush=True)
 save('materialization.json',outcomes)
 integrity=json.loads((ROOT/'real-integrity.json').read_text())
 integrity['live_db_after_export_sha256']=sha(DEFAULT_DB_PATH.read_bytes())
 integrity['live_db_unchanged_after_export']=integrity['live_db_before_sha256']==integrity['live_db_after_export_sha256']
 path=DEFAULT_STORAGE_PATH/'prova/_forms/d2783f0c9bca4796b1c3f445ba38a655.docx'
 integrity['original_unchanged_after_export']=sha(path.read_bytes())==integrity['original_sha256']
 save('real-integrity.json',integrity)
asyncio.run(main())
