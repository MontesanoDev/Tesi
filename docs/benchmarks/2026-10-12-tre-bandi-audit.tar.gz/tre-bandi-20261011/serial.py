"""Separate serial control after all nine preregistered trials finished."""
from __future__ import annotations

import json
import subprocess
from datetime import UTC, datetime

from series import REPO, ROOT, live_fingerprint, save, trial


def main():
    original = json.loads((ROOT / "protocol.json").read_text())
    assert json.loads((ROOT / "integrity.json").read_text())["calls_finished"] == 9
    assert not (ROOT / "serial-protocol.json").exists()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    assert head == original["head"]
    save("serial-protocol.json", {
        "created_at": datetime.now(UTC).isoformat(), "head": head,
        "reason": "Two 300-second timeouts in the nine-call concurrent series; "
                  "observe the same documents without concurrent requests, "
                  "not a replacement of failures or automatic application retry",
        "cases_order": ["catanzaro", "minervino", "trapani"],
        "repetitions_per_case": 1, "calls_planned": 3,
        "max_concurrency": 1, "timeout_per_call_seconds": 300,
        "same_input_prompt_schema_sources_and_code": True,
        "automatic_retries": 0, "session_writes": 0, "docx_writes": 0,
    })
    save("live-before-serial.json", live_fingerprint())
    results = []
    for case in ["catanzaro", "minervino", "trapani"]:
        results.append(trial(case, 4))
        save("serial-results.json", results)
    after = live_fingerprint()
    save("live-after-serial.json", after)
    save("serial-integrity.json", {
        "live_unchanged_from_main_baseline": after == json.loads(
            (ROOT / "live-before.json").read_text()),
        "live_unchanged_from_serial_baseline": after == json.loads(
            (ROOT / "live-before-serial.json").read_text()),
        "head_unchanged": head == subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        "calls_finished": len(results),
    })
    print("SERIAL_FINISHED", flush=True)


if __name__ == "__main__":
    main()
