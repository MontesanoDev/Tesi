"""Offline inventory and exact replay of every acquired proposal; no model calls."""
from __future__ import annotations

import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

from app.compilation_global import validate_global_proposal
from app.docx_templates import inspect_docx

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[3]


def load(path):
    return json.loads(path.read_text())


def main():
    protocol = load(ROOT / "protocol.json")
    results, checks = [], []
    for case in protocol["cases"]:
        request_hashes = []
        for repetition in range(1, 5):
            root = ROOT / f"{case}-run{repetition}"
            if not (root / "manifest.json").exists():
                continue
            metrics = load(root / "metrics.json")
            manifest = load(root / "manifest.json")
            manifest_ok = all(hashlib.sha256((root / p).read_bytes()).hexdigest() == h
                              for p, h in manifest.items())
            code_ok = all((root / "code" / p).read_bytes() == subprocess.check_output(
                ["git", "show", f"{protocol['head']}:backend/{p}"], cwd=REPO)
                for p in [str(p.relative_to(root / "code"))
                          for p in (root / "code").rglob("*.py")])
            data = load(root / "input.json")
            request_hashes.append(hashlib.sha256((root / "request.json").read_bytes()).hexdigest())
            paragraphs = {p["id"]: p["text"] for b in data["form"]["blocks"]
                          for p in b["paragraphs"]}
            raw = None
            if (root / "response.txt").exists():
                raw = (root / "response.txt").read_text()
            elif (root / "http-response.txt").exists():
                http = load(root / "http-response.txt")
                raw = http.get("choices", [{}])[0].get("message", {}).get("content")
            try:
                proposal = json.loads(raw) if raw else {}
            except ValueError:
                proposal = {}
            structured_output_observed = isinstance(proposal.get("fields"), dict)
            audit = load(root / "validation.json") if (root / "validation.json").exists() else None
            replay_ok = None
            if audit is not None:
                layout = inspect_docx(
                    (root / "original.docx").read_bytes(), require_candidates=False)
                sources = load(ROOT / "inputs" / case / "sources.json")
                replay_ok = validate_global_proposal(raw, layout, "prova", sources) == audit
            validated = {f["candidate_id"]: f for f in (audit or {}).get("fields", [])}
            rows = []
            assignments = proposal.get("fields", {})
            facts = proposal.get("facts", {})
            for candidate_id, candidate in data["form"]["candidates"].items():
                field = validated.get(candidate_id, {})
                assignment = assignments.get(candidate_id, {})
                fact = facts.get(assignment.get("fact_id"), {})
                row = {
                    "candidate_id": candidate_id, "structural_candidate": candidate,
                    "form_local_context": {
                        p: paragraphs[p] for p in candidate["anchor_paragraph_ids"]},
                    "assignment": assignment or None, "fact": fact or None,
                    "validation": field.get("validation", "NOT_VALIDATED"),
                    "validation_errors": field.get("validation_errors", []),
                    "label": field.get("label") or assignment.get("label"),
                    "proposed_value": field.get("proposed_value", field.get("value")),
                    "source_grounded": field.get("validation") == "GROUNDED_PROPOSAL" or
                                       field.get("proposal_grounding") == "GROUNDED_PROPOSAL",
                    "source_evidence": field.get("source_evidence", []),
                    "condition_checks": field.get("condition_checks", {}),
                    "written_value": field.get("written_value"),
                    "field_audit": field or None,
                    "omitted": candidate_id not in assignments
                        if structured_output_observed else None,
                    "semantic_review_required": True,
                }
                rows.append(row)
            emitted = [row for row in rows if row["omitted"] is False]
            summaries = {
                "case": case, "repetition": repetition, "metrics": metrics,
                "phase": "serial_control" if repetition == 4 else "main_concurrent_series",
                "structured_output_observed": structured_output_observed,
                "raw_field_count": len(assignments) if structured_output_observed else None,
                "source_grounded_proposals": sum(r["source_grounded"] for r in emitted),
                "source_grounded_unconditional": sum(
                    r["validation"] == "GROUNDED_PROPOSAL" for r in emitted),
                "source_grounded_conditional": sum(r["field_audit"].get("proposal_grounding") ==
                    "GROUNDED_PROPOSAL" for r in emitted if r["field_audit"]),
                "emitted_dispositions": dict(Counter(
                    a.get("disposition") for a in assignments.values())),
                "omitted_count": sum(r["omitted"] for r in rows)
                    if structured_output_observed else None,
                "unknown_assignment_ids": sorted(
                    set(assignments) - set(data["form"]["candidates"])),
                "facts": (audit or {}).get("facts", {}),
                "conditions": (audit or {}).get("conditions", {}),
                "bindings": (audit or {}).get("bindings", {}),
                "rows": rows,
            }
            results.append(summaries)
            checks.append({"case": case, "repetition": repetition,
                           "manifest_ok": manifest_ok, "code_matches_frozen_head": code_ok,
                           "exact_replay": replay_ok,
                           "all_written_values_null": all(r["written_value"] is None for r in rows),
                           "all_grounded_proofs_source": all(
                               r["source_evidence"] and all(
                                   e["role"] == "source" for e in r["source_evidence"])
                               for r in emitted if r["source_grounded"]),
                           "no_user_values": data["user_values"] == [],
                           "source_corpus_matches_snapshot": data["sources"] == [
                               {k: s[k] for k in data["sources"][0]}
                               for s in load(ROOT / "inputs" / case / "sources.json")]})
        checks.append({"case": case, "identical_request_bodies": len(set(request_hashes)) == 1,
                       "request_count": len(request_hashes)})
    output = {"protocol": protocol, "scope": "complete inventory, deterministic grounding and "
              "manual semantic review, no accuracy percentage or final DOCX", "results": results,
              "checks": checks}
    (ROOT / "analysis.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    for result in results:
        print(json.dumps({k: result[k] for k in ["case", "repetition", "raw_field_count",
              "source_grounded_proposals", "source_grounded_unconditional",
              "source_grounded_conditional", "emitted_dispositions", "omitted_count"]}))
        for row in result["rows"]:
            if row["omitted"] is False:
                print(json.dumps({k: row[k] for k in ["candidate_id", "label", "proposed_value",
                    "validation", "source_grounded", "validation_errors"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
