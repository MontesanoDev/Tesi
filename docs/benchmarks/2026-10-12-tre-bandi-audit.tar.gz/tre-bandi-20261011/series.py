"""Nine preregistered real calls, unchanged experimental compiler and live data."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

from app.db import get_db_path, get_storage_path
from app.docx_templates import inspect_docx
from app.compilation_global import build_global_input
from scripts.benchmark_compilation_global import load_document_corpus

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT.parents[2]
REPO = BACKEND.parent
CASES = {
    "catanzaro": "demo-documents/bandi/catanzaro-dl-cse/modello/domanda-partecipazione.docx",
    "minervino": "demo-documents/bandi/minervino-elenco-sia/originali/domanda-iscrizione.docx",
    "trapani": "demo-documents/bandi/trapani-green/originali/manifestazione-interesse.docx",
}


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def live_fingerprint():
    with sqlite3.connect(f"file:{get_db_path().resolve()}?mode=ro", uri=True) as db:
        tables = [r[0] for r in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        result = {}
        for table in tables:
            rows = db.execute('SELECT * FROM "' + table.replace('"', '""') + '"').fetchall()
            serialized = sorted(repr(row) for row in rows)
            result[table] = {"rows": len(rows), "sha256": digest(
                json.dumps(serialized, ensure_ascii=False).encode())}
        originals = {}
        for row in db.execute("SELECT storage_path FROM project_files WHERE kind='form'"):
            if row[0]:
                path = get_storage_path() / row[0]
                originals[row[0]] = digest(path.read_bytes()) if path.exists() else "missing"
    return {"tables": result, "stored_originals": originals}


def trial(case, number):
    output = ROOT / f"{case}-run{number}"
    command = [sys.executable, "-m", "scripts.benchmark_compilation_global",
               "--fixture", str(ROOT / "inputs" / case),
               "--profile-project", "prova", "--output", str(output),
               "--max-seconds", "300"]
    with (ROOT / f"{case}-run{number}.log").open("w") as log:
        result = subprocess.run(command, cwd=BACKEND, stdout=log, stderr=subprocess.STDOUT)
    metrics = json.loads((output / "metrics.json").read_text()) if (
        output / "metrics.json").exists() else {}
    summary = {"case": case, "repetition": number, "exit_code": result.returncode,
               "state": metrics.get("state"), "candidate_count": metrics.get("candidate_count"),
               "seconds": metrics.get("ai_seconds"), "usage": metrics.get("usage"),
               "counts": metrics.get("validation_counts"),
               "conditional": metrics.get("grounded_conditional_proposals"),
               "unassigned": metrics.get("unassigned"),
               "assessment": metrics.get("proposal_assessment")}
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    return summary


def main():
    if (ROOT / "protocol.json").exists():
        raise RuntimeError("Protocol already exists; do not overwrite or repeat selectively")
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    before = live_fingerprint()
    save("live-before.json", before)
    with tempfile.TemporaryDirectory(prefix="mapi-three-forms-") as directory:
        snapshot_path = Path(directory) / "snapshot.db"
        with sqlite3.connect(f"file:{get_db_path().resolve()}?mode=ro", uri=True) as live:
            with sqlite3.connect(snapshot_path) as snapshot:
                live.backup(snapshot)
        with sqlite3.connect(f"file:{snapshot_path}?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            sources = load_document_corpus(db, "prova")
    descriptions = {}
    for case, relative in CASES.items():
        original = REPO / relative
        path = ROOT / "inputs" / case
        path.mkdir(parents=True, exist_ok=False)
        shutil.copy2(original, path / "original.docx")
        (path / "sources.json").write_text(json.dumps(sources, ensure_ascii=False, indent=2) + "\n")
        placeholder = {"version": "manual-only-no-gold", "project_id": "prova",
                       "original_sha256": digest(original.read_bytes()), "fields": []}
        (path / "manual-only.json").write_text(json.dumps(placeholder, indent=2) + "\n")
        manifest = {"project_id": "prova", "form": "original.docx", "sources": "sources.json",
                    "gold": "manual-only.json", "files": {
                        name: digest((path / name).read_bytes())
                        for name in ["original.docx", "sources.json", "manual-only.json"]}}
        (path / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        layout = inspect_docx(original.read_bytes(), require_candidates=False)
        data = build_global_input(layout, "prova", sources)
        descriptions[case] = {"original": relative, "original_sha256": layout.sha256,
                              "candidate_count": len(data["form"]["candidates"]),
                              "candidate_types": dict(Counter(c["type"] for c in
                                  data["form"]["candidates"].values())),
                              "corpus_sha256": digest((path / "sources.json").read_bytes())}
    protocol = {"created_at": datetime.now(UTC).isoformat(), "head": head,
                "cases": descriptions, "repetitions_per_case": 3,
                "calls_planned": 9, "max_concurrency": 3, "timeout_per_call_seconds": 300,
                "profile_project": "prova", "source_project": "prova", "source_chunks": len(sources),
                "source_categories": dict(Counter(s["category"] for s in sources)),
                "source_names": sorted(set(s["source_name"] for s in sources)),
                "thinking": "default low", "automatic_retries": 0,
                "application_changes": 0, "user_values": 0, "session_writes": 0,
                "docx_writes": 0, "gold": None,
                "scope": "complete original catalog + identical authorized small SOURCE corpus; "
                         "proposal/grounding/manual review, not final DOCX or full semantic approval",
                "manual_review": "all emitted proposals, roles/subjects/sections and selected "
                                 "standard fields; omissions do not prove MISSING/NA; "
                                 "checkbox/granularity defects recorded without fixes",
                "fixture_instructions_not_used": True,
                "preflight_failure": "Initial inspection used nonexistent layout.candidates; "
                                     "corrected audit inspection to build_global_input, no API call"}
    save("protocol.json", protocol)
    print(json.dumps({"protocol": protocol}, ensure_ascii=False), flush=True)
    results = []
    for number in range(1, 4):
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(trial, case, number) for case in CASES]
            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())
                save("series-results.json", results)
        current = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
        if current != head:
            raise RuntimeError("Code changed during frozen series")
    after = live_fingerprint()
    save("live-after.json", after)
    save("integrity.json", {"live_unchanged": before == after,
                           "originals_unchanged": all(digest((REPO / p).read_bytes()) ==
                               descriptions[c]["original_sha256"] for c, p in CASES.items()),
                           "head_unchanged": current == head,
                           "calls_finished": len(results)})
    print("SERIES_FINISHED", flush=True)


if __name__ == "__main__":
    main()
