"""Read-only analysis of frozen real captures; no provider calls or grading LLM."""
import hashlib
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[4]
base = repo / "backend/data/compilation-audit"
runs = []
for number in (1, 2, 3):
    root = base / f"labirinto-v1-20261011-run{number}"
    metrics = json.loads((root / "metrics.json").read_text())
    score = json.loads((root / "fixture-score.json").read_text())
    audit = json.loads((root / "validation.json").read_text())
    validations = {f["candidate_id"]: f for f in audit["fields"]}
    code = json.loads((root / "code.json").read_text())
    for row in score["fields"]:
        row["validation_errors"] = validations[row["candidate_id"]]["validation_errors"]
    runs.append({
        "run": number, "audit_directory": str(root.relative_to(repo)),
        "code": code, "metrics": metrics,
        "input_sha256": hashlib.sha256((root / "input.json").read_bytes()).hexdigest(),
        "request_sha256": hashlib.sha256((root / "request.json").read_bytes()).hexdigest(),
        "score": score,
        "observed_grounded_improper_assignments": [
            row["key"] for row in score["fields"]
            if row["unexpected_value"] and row["local_validation"] == "GROUNDED_PROPOSAL"],
    })
assert len({r["input_sha256"] for r in runs}) == 1
assert len({r["request_sha256"] for r in runs}) == 1
assert len({r["code"]["head"] for r in runs}) == 1
assert all(r["metrics"]["original_unchanged"] for r in runs)
result = {
    "date": "2026-10-11", "fixture_version": 1,
    "status": "real exploratory baseline, no semantic acceptance or DOCX generation",
    "frozen_code": runs[0]["code"]["head"],
    "identical_input_and_request": True,
    "total_calls": sum(r["metrics"]["semantic_calls"] for r in runs),
    "total_tokens": sum(r["metrics"]["usage"]["total_tokens"] for r in runs),
    "total_ai_seconds": sum(r["metrics"]["ai_seconds"] for r in runs),
    "session_writes": 0, "docx_writes": 0, "user_turns": "not measured",
    "software_checks": {
        "targeted": {"passed": 209, "seconds": 18.06,
                     "capture": "tool execution result, summarized in relazioni.md"},
        "full_backend": {"passed": 1615, "seconds": 187.33,
                         "log": "labirinto-v1-20261011-checks/backend-full.log"},
        "ruff": "passed", "fixture_reproducibility": "passed", "frontend": "unchanged/not run",
    },
    "review_notes": [
        "All 22 targets are authored before the baseline; 18 value/source matches in each run.",
        "Correct literal matches are not a complete independent semantic verdict.",
        "Four alternative type checkboxes are omitted; omissions do not prove false or NA.",
        "Six engineering/director values are proposed correctly but rejected on unknown conditions.",
        "Operative site is proposed despite the local only-if-different clause; rejected in all runs.",
        "All runs choose policy A despite two discordant attestations; literal grounding lets it pass.",
        "Run 2 additionally infers practice signer/role and fills excluded or unknown subject branches.",
        "No qualifications date, ISO value, participation, arbitrary signature or outside-project data.",
        "Full conflict classification versus ambiguity is not scored by this sparse-output benchmark.",
    ],
    "runs": runs,
}
target = repo / "docs/benchmarks/2026-10-11-labirinto-v1-baseline.json"
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in {"runs", "review_notes"}},
                 ensure_ascii=False, indent=2))
