from __future__ import annotations

import os
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

DEFAULT_DB_PATH = Path(__file__).resolve().parents[1] / "data" / "mapi.db"
DEFAULT_STORAGE_PATH = Path(__file__).resolve().parents[1] / "data" / "uploads"
DEFAULT_KNOWLEDGE_PATH = Path(__file__).resolve().parents[1] / "data" / "knowledge"


def get_db_path() -> Path:
    configured = os.getenv("MAPI_DB_PATH")
    return Path(configured) if configured else DEFAULT_DB_PATH


def get_storage_path() -> Path:
    configured = os.getenv("MAPI_STORAGE_PATH")
    return Path(configured) if configured else DEFAULT_STORAGE_PATH


def get_knowledge_path() -> Path:
    configured = os.getenv("MAPI_KNOWLEDGE_PATH")
    return Path(configured) if configured else DEFAULT_KNOWLEDGE_PATH


def _ensure_column(db: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    columns = {row[1] for row in db.execute(f"PRAGMA table_info({table})")}
    if column not in columns:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


@contextmanager
def connection() -> Iterator[sqlite3.Connection]:
    path = get_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    try:
        yield db
        db.commit()
    finally:
        db.close()


def init_database() -> None:
    with connection() as db:
        _migrate_ai_providers(db)
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                status TEXT NOT NULL,
                status_tone TEXT NOT NULL,
                updated_label TEXT NOT NULL,
                instructions TEXT NOT NULL,
                shared_source_count INTEGER NOT NULL DEFAULT 0,
                model_count INTEGER NOT NULL DEFAULT 0,
                call_fact_count INTEGER NOT NULL DEFAULT 0,
                missing_fact_count INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS app_metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS ai_profiles (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                provider TEXT NOT NULL,
                base_url TEXT NOT NULL,
                model TEXT NOT NULL,
                encrypted_api_key TEXT,
                context_window INTEGER NOT NULL DEFAULT 32768,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS ai_preferences (
                id INTEGER PRIMARY KEY CHECK(id = 1),
                default_profile_id TEXT REFERENCES ai_profiles(id) ON DELETE SET NULL
            );
            INSERT OR IGNORE INTO ai_preferences(id) VALUES (1);

            CREATE TABLE IF NOT EXISTS ai_login_flows (
                token_hash TEXT PRIMARY KEY,
                encrypted_verifier TEXT,
                encrypted_api_key TEXT,
                status TEXT NOT NULL,
                expires_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS project_ai_settings (
                project_id TEXT PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
                profile_id TEXT REFERENCES ai_profiles(id) ON DELETE RESTRICT,
                thinking_mode INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS project_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                metadata TEXT NOT NULL,
                kind TEXT NOT NULL,
                status TEXT NOT NULL,
                storage_path TEXT,
                mime_type TEXT,
                byte_size INTEGER NOT NULL DEFAULT 0,
                page_count INTEGER NOT NULL DEFAULT 0,
                chunk_count INTEGER NOT NULL DEFAULT 0,
                sort_order INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS document_chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                file_id INTEGER NOT NULL REFERENCES project_files(id) ON DELETE CASCADE,
                chunk_index INTEGER NOT NULL,
                content TEXT NOT NULL,
                char_count INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(file_id, chunk_index)
            );

            CREATE INDEX IF NOT EXISTS idx_document_chunks_project
            ON document_chunks(project_id);

            CREATE VIRTUAL TABLE IF NOT EXISTS document_chunks_fts USING fts5(
                project_id UNINDEXED,
                file_id UNINDEXED,
                content,
                tokenize = 'unicode61 remove_diacritics 2'
            );

            CREATE TRIGGER IF NOT EXISTS document_chunks_fts_insert
            AFTER INSERT ON document_chunks BEGIN
                INSERT INTO document_chunks_fts(rowid, project_id, file_id, content)
                VALUES (new.id, new.project_id, new.file_id, new.content);
            END;

            CREATE TRIGGER IF NOT EXISTS document_chunks_fts_delete
            AFTER DELETE ON document_chunks BEGIN
                DELETE FROM document_chunks_fts WHERE rowid = old.id;
            END;

            CREATE TRIGGER IF NOT EXISTS document_chunks_fts_update
            AFTER UPDATE ON document_chunks BEGIN
                DELETE FROM document_chunks_fts WHERE rowid = old.id;
                INSERT INTO document_chunks_fts(rowid, project_id, file_id, content)
                VALUES (new.id, new.project_id, new.file_id, new.content);
            END;

            CREATE TABLE IF NOT EXISTS knowledge_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                detail TEXT NOT NULL,
                scope TEXT NOT NULL,
                tone TEXT NOT NULL,
                item_count INTEGER NOT NULL DEFAULT 0,
                sort_order INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS global_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'company',
                metadata TEXT NOT NULL,
                status TEXT NOT NULL,
                storage_path TEXT NOT NULL UNIQUE,
                mime_type TEXT NOT NULL,
                byte_size INTEGER NOT NULL DEFAULT 0,
                page_count INTEGER NOT NULL DEFAULT 0,
                chunk_count INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS global_document_chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id INTEGER NOT NULL REFERENCES global_documents(id) ON DELETE CASCADE,
                chunk_index INTEGER NOT NULL,
                content TEXT NOT NULL,
                char_count INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(document_id, chunk_index)
            );

            CREATE VIRTUAL TABLE IF NOT EXISTS global_document_chunks_fts USING fts5(
                document_id UNINDEXED,
                content,
                tokenize = 'unicode61 remove_diacritics 2'
            );

            CREATE TRIGGER IF NOT EXISTS global_document_chunks_fts_insert
            AFTER INSERT ON global_document_chunks BEGIN
                INSERT INTO global_document_chunks_fts(rowid, document_id, content)
                VALUES (new.id, new.document_id, new.content);
            END;

            CREATE TRIGGER IF NOT EXISTS global_document_chunks_fts_delete
            AFTER DELETE ON global_document_chunks BEGIN
                DELETE FROM global_document_chunks_fts WHERE rowid = old.id;
            END;

            CREATE TRIGGER IF NOT EXISTS global_document_chunks_fts_update
            AFTER UPDATE ON global_document_chunks BEGIN
                DELETE FROM global_document_chunks_fts WHERE rowid = old.id;
                INSERT INTO global_document_chunks_fts(rowid, document_id, content)
                VALUES (new.id, new.document_id, new.content);
            END;

            CREATE TABLE IF NOT EXISTS project_global_document_links (
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                document_id INTEGER NOT NULL REFERENCES global_documents(id) ON DELETE CASCADE,
                linked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (project_id, document_id)
            );

            CREATE INDEX IF NOT EXISTS idx_project_global_document_links_document
            ON project_global_document_links(document_id);

            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                metadata TEXT NOT NULL,
                target TEXT,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS conversation_turns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
                question TEXT NOT NULL,
                answer TEXT,
                citations_json TEXT NOT NULL DEFAULT '[]',
                missing_information_json TEXT NOT NULL DEFAULT '[]',
                evidence_json TEXT NOT NULL DEFAULT '[]',
                generation_status TEXT NOT NULL,
                model TEXT,
                total_tokens INTEGER,
                notice TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_conversation_turns_conversation
            ON conversation_turns(conversation_id, id);

            CREATE TABLE IF NOT EXISTS knowledge_artifacts (
                id TEXT PRIMARY KEY,
                project_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
                kind TEXT NOT NULL,
                scope TEXT NOT NULL,
                title TEXT NOT NULL,
                filename TEXT NOT NULL,
                storage_path TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                byte_size INTEGER NOT NULL DEFAULT 0,
                version INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS project_artifact_links (
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                artifact_id TEXT NOT NULL REFERENCES knowledge_artifacts(id) ON DELETE CASCADE,
                file_id INTEGER NOT NULL UNIQUE REFERENCES project_files(id) ON DELETE CASCADE,
                PRIMARY KEY (project_id, artifact_id)
            );

            CREATE INDEX IF NOT EXISTS idx_project_artifact_links_artifact
            ON project_artifact_links(artifact_id);

            CREATE TABLE IF NOT EXISTS document_fields (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                section TEXT NOT NULL,
                label TEXT NOT NULL,
                value TEXT,
                provenance TEXT,
                source_kind TEXT NOT NULL,
                status TEXT NOT NULL,
                sort_order INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS document_compilations (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                template_name TEXT NOT NULL,
                storage_path TEXT NOT NULL UNIQUE,
                report_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_document_compilations_project
            ON document_compilations(project_id, created_at);

            CREATE TABLE IF NOT EXISTS compilation_sessions (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                form_id INTEGER REFERENCES project_files(id) ON DELETE SET NULL,
                conversation_id TEXT REFERENCES conversations(id) ON DELETE SET NULL,
                original BLOB NOT NULL,
                state_json TEXT NOT NULL,
                version INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_compilation_sessions_project
            ON compilation_sessions(project_id, created_at);
            CREATE TABLE IF NOT EXISTS compilation_session_revisions (
                session_id TEXT NOT NULL REFERENCES compilation_sessions(id) ON DELETE CASCADE,
                version INTEGER NOT NULL,
                event_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY (session_id, version)
            );
            """
        )
        _ensure_column(db, "projects", "updated_at", "TEXT")
        # Older projects have no modification history; creation is the known fallback.
        db.execute("UPDATE projects SET updated_at = created_at WHERE updated_at IS NULL")
        _ensure_column(db, "project_files", "storage_path", "TEXT")
        _ensure_column(db, "project_files", "mime_type", "TEXT")
        _ensure_column(db, "project_files", "byte_size", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(db, "project_files", "page_count", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(db, "project_files", "chunk_count", "INTEGER NOT NULL DEFAULT 0")
        db.execute("DROP TABLE IF EXISTS company_facts")
        _ensure_column(
            db,
            "global_documents",
            "category",
            "TEXT NOT NULL DEFAULT 'company'",
        )
        _ensure_column(db, "conversations", "created_at", "TEXT")
        _ensure_column(db, "conversations", "updated_at", "TEXT")
        _ensure_column(
            db, "conversations", "selected_form_id",
            "INTEGER REFERENCES project_files(id) ON DELETE SET NULL",
        )
        _ensure_column(db, "conversation_turns", "form_reference_json", "TEXT")
        _ensure_column(
            db, "conversations", "selected_document_id",
            "INTEGER REFERENCES project_files(id) ON DELETE SET NULL",
        )
        _ensure_column(db, "conversation_turns", "document_reference_json", "TEXT")
        _ensure_column(db, "conversation_turns", "compilation_json", "TEXT")
        _ensure_column(db, "project_ai_settings", "thinking_mode", "INTEGER NOT NULL DEFAULT 0")
        _migrate_project_ai_settings(db)
        db.execute(
            """
            UPDATE conversations
            SET created_at = COALESCE(created_at, CURRENT_TIMESTAMP),
                updated_at = COALESCE(updated_at, CURRENT_TIMESTAMP)
            """
        )
        db.execute(
            """
            INSERT OR REPLACE INTO document_chunks_fts(rowid, project_id, file_id, content)
            SELECT id, project_id, file_id, content FROM document_chunks
            """
        )
        db.execute(
            """
            INSERT OR REPLACE INTO global_document_chunks_fts(rowid, document_id, content)
            SELECT id, document_id, content FROM global_document_chunks
            """
        )


def _migrate_project_ai_settings(db: sqlite3.Connection) -> None:
    """Allow default inheritance, preserving project preferences in init's transaction."""
    columns = {row["name"]: row for row in db.execute("PRAGMA table_info(project_ai_settings)")}
    if not columns["profile_id"]["notnull"]:
        return
    # This child table has no inbound references; FK enforcement can stay enabled.
    db.execute("""CREATE TABLE project_ai_settings_nullable (
        project_id TEXT PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
        profile_id TEXT REFERENCES ai_profiles(id) ON DELETE RESTRICT,
        thinking_mode INTEGER NOT NULL DEFAULT 0
    )""")
    db.execute(
        "INSERT INTO project_ai_settings_nullable(project_id, profile_id, thinking_mode) "
        "SELECT project_id, profile_id, thinking_mode FROM project_ai_settings"
    )
    db.execute("DROP TABLE project_ai_settings")
    db.execute("ALTER TABLE project_ai_settings_nullable RENAME TO project_ai_settings")
    if db.execute("PRAGMA foreign_key_check(project_ai_settings)").fetchone():
        raise RuntimeError("La migrazione delle preferenze AI viola i collegamenti del database")


def _migrate_ai_providers(db: sqlite3.Connection) -> None:
    """Remove the original three-provider CHECK, preserving IDs, secrets and foreign keys."""
    row = db.execute("SELECT sql FROM sqlite_master WHERE name='ai_profiles'").fetchone()
    if row is None or "CHECK" not in row[0].upper():
        return
    # SQLite cannot alter a CHECK. Disable FK actions only for this atomic table replacement.
    db.execute("PRAGMA foreign_keys = OFF")
    try:
        db.execute("BEGIN IMMEDIATE")
        db.execute("""CREATE TABLE ai_profiles_expanded (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, provider TEXT NOT NULL,
            base_url TEXT NOT NULL, model TEXT NOT NULL, encrypted_api_key TEXT,
            context_window INTEGER NOT NULL DEFAULT 32768,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        db.execute("INSERT INTO ai_profiles_expanded SELECT * FROM ai_profiles")
        db.execute("DROP TABLE ai_profiles")
        db.execute("ALTER TABLE ai_profiles_expanded RENAME TO ai_profiles")
        if db.execute("PRAGMA foreign_key_check").fetchone():
            raise RuntimeError("La migrazione dei modelli AI viola i collegamenti del database")
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.execute("PRAGMA foreign_keys = ON")


def touch_project(db: sqlite3.Connection, project_id: str) -> None:
    db.execute(
        """
        UPDATE projects
        SET updated_at = strftime('%Y-%m-%d %H:%M:%f', 'now'),
            updated_label = 'Aggiornato ora'
        WHERE id = ?
        """,
        (project_id,),
    )
