"""Read-only analysis of frozen real captures, never provider calls or repairs."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path('data/compilation-audit')
SAMPLES = {
 't0.r0.c1': 'Sottoscrittore', 't0.r3.c1': 'Carica sottoscrittore',
 't0.r4.c1': 'Estremi procura', 't0.r5.c1': 'Operatore economico',
 't0.r6.c1': 'Forma giuridica', 't0.r7.c1': 'Sede legale',
 't0.r8.c1': 'Sede operativa', 't0.r9.c1': 'Codice fiscale',
 't0.r10.c1': 'Partita IVA', 't25.r3.c1': 'Numero/data CCIAA',
 't26.r0.c1': 'Direttore tecnico nome', 't26.r1.c1': 'Qualifica direttore',
 't26.r2.c1': 'Data abilitazione', 't26.r3.c1': 'Ordine professionale',
 't26.r4.c1': 'Numero albo', 't40.r0.c1': 'Consorziata esecutrice',
}

def read(path):
 return json.loads(path.read_text())

runs = []
for i in (1, 2, 3, 4):
 folder = ROOT / f'global-sparse-20261011-run{i}'
 metrics = read(folder/'metrics.json')
 if metrics['state'] not in ('proposal_audited', 'failed'):
  raise RuntimeError('Provider still running')
 data = read(folder/'input.json')
 raw = read(folder/'response.txt') if (folder/'response.txt').exists() else {}
 validation = read(folder/'validation.json') if (folder/'validation.json').exists() else {}
 fields = {f['candidate_id']: f for f in validation.get('fields', [])}
 samples = []
 for cid, label in SAMPLES.items():
  record = raw.get('fields', {}).get(cid)
  fact_id = record.get('fact_id') if isinstance(record, dict) else None
  fact = raw.get('facts', {}).get(fact_id, {})
  accepted = fields.get(cid, {})
  samples.append({'candidate_id': cid, 'benchmark_label': label,
   'proposal': record, 'fact_id': fact_id, 'raw_fact': fact,
   'proposed_value': fact.get('value'),
   'validation': accepted.get('validation'), 'value': accepted.get('value'),
   'errors': accepted.get('validation_errors', []),
   'conditions': accepted.get('conditions', []),
   'condition_checks': accepted.get('condition_checks', {}),
   'source_evidence': accepted.get('source_evidence', []),
   'semantic_annotation': 'pending human review'})
 manifest = read(folder/'manifest.json')
 for name, sha in manifest.items():
  assert hashlib.sha256((folder/name).read_bytes()).hexdigest() == sha, name
 runs.append({'run': i, 'metrics': metrics,
  'code': read(folder/'code.json'),
  'input_sha256': hashlib.sha256((folder/'input.json').read_bytes()).hexdigest(),
  'request_sha256': hashlib.sha256((folder/'request.json').read_bytes()).hexdigest(),
  'source_roles': dict(Counter(s['role'] for s in data['sources'])),
  'source_categories': dict(Counter(s['category'] or 'project' for s in data['sources'])),
  'raw_fields': len(raw.get('fields', {})), 'raw_facts': len(raw.get('facts', {})),
  'raw_conditions': len(raw.get('conditions', {})),
  'proposed_dispositions': dict(Counter(f.get('disposition') for f in raw.get('fields', {}).values())),
  'scope_kinds': dict(Counter(t.get('kind') for c in raw.get('conditions', {}).values()
                             for t in c.get('scope', []))),
  'validation_counts': validation.get('counts', {}),
  'rejected_unknown_assignments': validation.get('rejected_assignments', {}),
  'rejected_fields': [{'candidate_id': f['candidate_id'],
                       'errors': f.get('validation_errors', []), 'proposal': f.get('proposal')}
                     for f in fields.values() if f['validation'] == 'REJECTED'],
  'facts_counts': dict(Counter(f['validation'] for f in validation.get('facts', {}).values())),
  'condition_counts': dict(Counter(c['validation'] for c in validation.get('conditions', {}).values())),
  'condition_errors': {k: c['validation_errors'] for k, c in validation.get('conditions', {}).items()
                       if c['validation_errors']},
  'samples': samples, 'manifest_verified': True})

for left, right in ((runs[0], runs[1]), (runs[2], runs[3])):
 assert left['input_sha256'] == right['input_sha256']
 assert left['request_sha256'] == right['request_sha256']
 assert left['code']['head'] == right['code']['head']
summary = {'benchmark': 'compilation-global-sparse', 'date': '2026-10-11',
 'protocol': {'real_provider': 'deepseek-flash', 'independent_calls': 4,
  'calls_per_experiment': 1, 'retries': 0, 'user_values': 0,
  'session_writes': 0, 'docx_writes': 0, 'semantic_acceptance': False,
  'manifests_verified': True, 'frozen_pairs': [[runs[0]['code']['head'], 1, 2], [runs[2]['code']['head'], 3, 4]],
  'identical_inputs_within_pairs': True, 'identical_requests_within_pairs': True},
 'runs': runs,
 'total_tokens': sum(r['metrics'].get('usage', {}).get('total_tokens', 0) for r in runs),
 'total_ai_seconds': sum(r['metrics']['ai_seconds'] for r in runs)}
output = ROOT/'global-sparse-20261011-analysis'/'summary.json'
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
for run in runs:
 print(json.dumps({k: run[k] for k in ('run', 'raw_fields', 'raw_facts', 'raw_conditions',
  'validation_counts', 'scope_kinds', 'condition_counts', 'condition_errors')}, ensure_ascii=False))
 for sample in run['samples']:
  print(json.dumps({k: sample[k] for k in ('candidate_id', 'proposed_value', 'validation', 'errors')}, ensure_ascii=False))
