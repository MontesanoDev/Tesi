"""Human annotations of captured proposals, not semantic backend verdicts."""
import hashlib
import json
from pathlib import Path

ROOT=Path('data/compilation-audit')
p=ROOT/'global-sparse-20261011-analysis/summary.json'
s=json.loads(p.read_text())
standard={'t0.r5.c1','t0.r6.c1','t0.r7.c1','t0.r9.c1','t0.r10.c1'}
director={'t26.r0.c1','t26.r1.c1','t26.r3.c1','t26.r4.c1'}
for run in s['runs']:
 i=run['run']
 raw=json.loads((ROOT/f'global-sparse-20261011-run{i}/response.txt').read_text())
 data=json.loads((ROOT/f'global-sparse-20261011-run{i}/input.json').read_text())
 for sample in run['samples']:
  cid=sample['candidate_id']
  value=sample['proposed_value']
  if cid in standard:
   note='Valore SOURCE corretto per la proprietà aziendale' if value else 'Nessun valore proposto, nonostante la SOURCE presente: fact_id null'
  elif cid in director:
   note='Fatto professionale atomico presente nella SOURCE; applicabilità del ramo non verificata'
  elif cid in {'t0.r0.c1','t0.r3.c1'}:
   note='La carica aziendale non prova chi sottoscrive questa pratica; nessuna assegnazione automaticamente accettabile'
  elif cid=='t0.r8.c1':
   note='Coincide con la sede legale: value improprio se proposto; NA richiede la condizione calcolata, non la sola conclusione del modello'
  elif cid=='t25.r3.c1':
   note='REA non equivale al numero/data di iscrizione CCIAA; la combinazione di dati non è un valore letterale unico'
  elif cid=='t40.r0.c1':
   note='Il profilo aziendale non prova il ruolo di consorziata esecutrice né la sua esclusione'
  elif cid=='t0.r4.c1':
   note='Poteri di amministratore non escludono automaticamente la procura; nessun valore o NA verificato'
  else:
   note='Nessun valore utilizzabile attestato per questa posizione nel campione'
  sample['semantic_annotation']=note
 if i>=3:
  a=json.loads((ROOT/f'global-sparse-20261011-run{i}/validation.json').read_text())
  annotated=[]
  for field in a['fields']:
   if field['validation']!='GROUNDED_PROPOSAL':
    continue
   cid=field['candidate_id']
   issue=(cid in {'t0.r0.c1','t0.r3.c1','t0.r8.c1'})
   annotated.append({'candidate_id':cid,'value':field.get('value'),
    'manual_result':'unsupported_assignment' if issue else 'supported_assignment',
    'reason':next((x['semantic_annotation'] for x in run['samples'] if x['candidate_id']==cid),
                   'Recapito telefonico aziendale attestato nella SOURCE'),
    'source_evidence':field['source_evidence']})
  run['all_grounded_manual_review']=annotated
  run['manual_counts']={
    'grounded_inspected':len(annotated),
    'supported_assignments':sum(x['manual_result']=='supported_assignment' for x in annotated),
    'unsupported_assignments':sum(x['manual_result']=='unsupported_assignment' for x in annotated)}
  run['local_errors']=dict(__import__('collections').Counter(
    f['validation_errors'][0] for f in a['fields'] if f['validation']=='REJECTED'))
 run['raw_value_without_fact']=sum(f.get('disposition')=='value' and not f.get('fact_id')
                                  for f in raw['fields'].values())
 run['form_catalog_sha256']=hashlib.sha256(json.dumps(data['form'],sort_keys=True).encode()).hexdigest()
 run['sources_sha256']=hashlib.sha256(json.dumps(data['sources'],sort_keys=True).encode()).hexdigest()

assert len({r['form_catalog_sha256'] for r in s['runs']})==1
assert len({r['sources_sha256'] for r in s['runs']})==1
previous=json.loads((ROOT/'global-compact-20261010-run6/input.json').read_text())
assert s['runs'][0]['form_catalog_sha256']==hashlib.sha256(json.dumps(previous['form'],sort_keys=True).encode()).hexdigest()
assert s['runs'][0]['sources_sha256']==hashlib.sha256(json.dumps(previous['sources'],sort_keys=True).encode()).hexdigest()
for i in (3,4):
 r=s['runs'][i-1]
 reviewed={x['candidate_id'] for x in r['all_grounded_manual_review'] if x['manual_result']=='supported_assignment'}
 assert standard<=reviewed
s['protocol']['catalog_and_sources_identical_to_previous_compact']=True
s['software_checks']={
 'initial':{'targeted':185,'backend_full':1591,'backend_seconds':104.18},
 'final':{'targeted':188,'backend_full':1594,'backend_seconds':101.60},
 'ruff':True,'cli_help':True,'diff_check':True,'frontend':'unchanged, not rerun',
 'providers':'simulated in software tests; real DeepSeek only in the four experiments'}
final=s['runs'][2:]
mean_seconds=sum(r['metrics']['ai_seconds'] for r in final)/2
mean_tokens=sum(r['metrics']['usage']['total_tokens'] for r in final)/2
mean_output=sum(r['metrics']['usage']['completion_tokens'] for r in final)/2
old_seconds=(46.725891+46.882157)/2
old_tokens=(88650+88816)/2
old_output=(18164+18330)/2
s['comparison']={'reference':'previous compact runs 5/6, rejected globally',
 'new_mean_ai_seconds':mean_seconds,'old_mean_ai_seconds':old_seconds,
 'ai_seconds_change_percent':(mean_seconds/old_seconds-1)*100,
 'new_mean_tokens':mean_tokens,'old_mean_tokens':old_tokens,
 'tokens_change_percent':(mean_tokens/old_tokens-1)*100,
 'new_mean_output_tokens':mean_output,'old_mean_output_tokens':old_output,
 'output_tokens_change_percent':(mean_output/old_output-1)*100,
 'production_savings_demonstrated':False,
 'limits':'Two stochastic responses, changed contracts, variable cache; not full compilation'}
p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
Path('../docs/benchmarks/2026-10-11-compilation-global-sparse.json').write_text(p.read_text())
print(json.dumps({'total_tokens':s['total_tokens'],'total_ai_seconds':s['total_ai_seconds'],
 'comparison':s['comparison'],'manual_counts':[r['manual_counts'] for r in final]},ensure_ascii=False,indent=2))
