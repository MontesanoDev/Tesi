import asyncio
import collections
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import time

from app.ai_profiles import resolve_project_settings
from app.config import use_ai_settings
from app.db import get_db_path, get_storage_path
from app.retrieval_settings import public_settings

root = Path(tempfile.mkdtemp(prefix='mapi-latency-20261010-'))
report = {'root': str(root), 'http': [], 'model': [], 'stages': [], 'steps': []}

def emit(kind, payload):
    print(kind, json.dumps(payload, ensure_ascii=False), flush=True)
    (root / 'metrics.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))

original_db = get_db_path().resolve()
source = sqlite3.connect(f'file:{original_db}?mode=ro', uri=True)
source.row_factory = sqlite3.Row
row = source.execute('''SELECT s.project_id,s.form_id,f.storage_path,s.original FROM compilation_sessions s
 JOIN project_files f ON f.id=s.form_id
 JOIN project_ai_settings ps ON ps.project_id=s.project_id
 JOIN ai_profiles a ON a.id=ps.profile_id
 WHERE a.provider='ollama' ORDER BY s.updated_at DESC LIMIT 1''').fetchone()
if row is None:
    raise SystemExit('No saved local-model session available')
project, form_id = row['project_id'], row['form_id']
settings = resolve_project_settings(project)
retrieval = public_settings()
report['configuration'] = {'project': project, 'model': settings.model, 'provider': settings.provider,
                           'context_window': settings.context_window, 'retrieval': retrieval['backend']}
with sqlite3.connect(root / 'snapshot.db') as target:
    source.backup(target)
original = bytes(row['original'])
source.close()
upload = root / 'uploads' / row['storage_path']
upload.parent.mkdir(parents=True, exist_ok=True)
upload.write_bytes(original)
if retrieval['backend'] == 'qdrant':
    if retrieval['qdrant_mode'] != 'local':
        raise SystemExit('Remote vector index is not eligible for isolated diagnostics')
    shutil.copytree(str(original_db) + '.qdrant', str(root / 'snapshot.db') + '.qdrant',
                    ignore=shutil.ignore_patterns('.lock'))
os.environ['MAPI_DB_PATH'] = str(root / 'snapshot.db')
os.environ['MAPI_STORAGE_PATH'] = str(root / 'uploads')
os.environ['MAPI_KNOWLEDGE_PATH'] = str(root / 'knowledge')
emit('CONFIG', report['configuration'] | {'isolated_storage': str(root)})

import httpx
from app import compilation_session_resolution as resolution
from app import compilation_sessions as sessions
from app import generation, intents, source_planning

real_post = httpx.AsyncClient.post
async def measured_post(self, url, *args, **kwargs):
    body = kwargs.get('json') or {}
    start = time.perf_counter()
    entry = {'endpoint': str(url).split('?')[0].split('/')[-1],
             'model': body.get('model'), 'num_ctx': body.get('options', {}).get('num_ctx'),
             'input_characters': sum(len(m.get('content','')) for m in body.get('messages', []))}
    try:
        response = await real_post(self, url, *args, **kwargs)
        entry['status'] = response.status_code
        if response.is_success:
            data = response.json()
            for k in ['total_duration','load_duration','prompt_eval_duration','eval_duration']:
                if isinstance(data.get(k), (int,float)): entry[k + '_seconds'] = round(data[k]/1e9, 4)
            for k in ['prompt_eval_count','eval_count','done_reason']:
                if k in data: entry[k] = data[k]
        return response
    except BaseException as exc:
        entry['error'] = type(exc).__name__
        raise
    finally:
        entry['seconds'] = round(time.perf_counter()-start, 4)
        report['http'].append(entry)
        emit('HTTP', entry)
httpx.AsyncClient.post = measured_post

real_request = generation.request_model_content
async def measured_model(client, model_settings, body, timeout, **kwargs):
    title = (kwargs.get('response_schema') or {}).get('title', 'unstructured')
    start = time.perf_counter()
    entry = {'schema': title, 'max_tokens': body.get('max_tokens'),
             'input_characters': sum(len(m['content']) for m in body['messages'])}
    emit('MODEL_START', entry)
    try:
        result = await real_request(client, model_settings, body, timeout, **kwargs)
        raw, _, usage = result
        entry.update(output_characters=len(raw), total_tokens=usage.get('total_tokens'))
        (root / f"model-{len(report['model'])+1}-{title}.json").write_text(raw)
        return result
    except BaseException as exc:
        entry['error'] = type(exc).__name__
        raise
    finally:
        entry['seconds'] = round(time.perf_counter()-start, 4)
        report['model'].append(entry)
        emit('MODEL_END', entry)
for module in [generation, resolution, intents, source_planning]:
    if hasattr(module, 'request_model_content'): module.request_model_content = measured_model

for name in ['plan_document','classify_candidates','review_meanings','retrieve_sources','match_candidates','review_sources']:
    target = getattr(resolution, name)
    def wrap(function, phase):
        async def measured(*args, **kwargs):
            start = time.perf_counter()
            entry = {'phase': phase}
            try:
                return await function(*args, **kwargs)
            except BaseException as exc:
                entry['error'] = type(exc).__name__
                raise
            finally:
                entry['seconds'] = round(time.perf_counter()-start, 4)
                report['stages'].append(entry)
                emit('STAGE', entry)
        return measured
    setattr(resolution, name, wrap(target, name))

async def main():
    with use_ai_settings(settings):
        start=time.perf_counter()
        session = sessions.create_session(project, form_id, start_in_chat=True)
        report['create_seconds'] = round(time.perf_counter()-start,4)
        emit('CREATE', {'seconds': report['create_seconds'], 'candidate_count': session['summary']['total']})
        for step in range(2):
            start=time.perf_counter()
            try:
                session = await resolution.resolve_session(project, session['id'], session['version'], automatic=True)
            except BaseException as exc:
                emit('STEP_FAILURE', {'step': step+1,'error':type(exc).__name__,'seconds':round(time.perf_counter()-start,4)})
                session = sessions.get_session(project,session['id'])
                report['final_summary'] = session['summary']
                report['final_error'] = session['last_error']
                break
            entry={'step':step+1,'seconds':round(time.perf_counter()-start,4),'status':session['status'],
                   'summary':session['summary'],'diagnostics':session.get('last_resolution')}
            report['steps'].append(entry)
            emit('STEP',entry)
        report['fields'] = [{k:f.get(k) for k in ['id','label','status','value','reason','validation_errors','requirement','search','provenance']}
                            for f in session['fields'][:12]]
        report['final_summary'] = session['summary']
        emit('COMPLETE', {'summary':session['summary'],'metrics_file':str(root/'metrics.json')})

asyncio.run(main())
