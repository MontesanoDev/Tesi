"""Preparazione autoriale degli artefatti Minervino; non usa il motore applicativo."""
import copy
import hashlib
import json
import re
import shutil
import sqlite3
import subprocess
import zipfile
from collections import Counter
from pathlib import Path

from lxml import etree as ET

ROOT = Path(__file__).resolve().parents[4]
RAW = Path(__file__).resolve().parent
FIX = ROOT / 'demo-documents/benchmark-minervino/v1'
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
W14 = 'http://schemas.microsoft.com/office/word/2010/wordml'
NS = {'w': W, 'w14': W14}
qn = lambda tag: '{' + W + '}' + tag
PAT = re.compile(r'_(?:[ \u00a0]*_){1,}|[.\u2026](?:[ \u00a0]*[.\u2026])*')


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def text(element):
    return ''.join(t.text or '' for t in element.iter(qn('t')))


def blanks(value):
    out = []
    for match in PAT.finditer(value):
        if match.group()[0] in '.…':
            if (match.group()[0] == '.' and match.start() and value[match.start()-1].isalnum()
                    and len(match.group()) > 1 and match.group()[1] in ' \u00a0'):
                start = match.start() + 1
                while value[start] in ' \u00a0':
                    start += 1
                match = PAT.match(value, start)
            if match.group().count('.') + 3 * match.group().count('…') < 4:
                continue
        out.append(match)
    return out


def replace_span(paragraph, start, end, value):
    nodes = []
    offset = 0
    for node in paragraph.iter(qn('t')):
        length = len(node.text or '')
        nodes.append((node, offset, offset + length))
        offset += length
    inserted = False
    for node, left, right in nodes:
        if right <= start or left >= end:
            continue
        s = node.text or ''
        node.text = (s[:max(0, start-left)] + (value if not inserted else '')
                     + s[max(0, end-left):])
        node.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        inserted = True
    assert inserted


def prop(paragraph, name):
    ppr = paragraph.find(qn('pPr'))
    if ppr is None:
        ppr = ET.Element(qn('pPr'))
        paragraph.insert(0, ppr)
    item = ppr.find(qn(name))
    if item is None:
        item = ET.Element(qn(name))
        # pStyle precede keepNext, che precede keepLines nel CT_PPr OOXML.
        index = int(ppr.find(qn('pStyle')) is not None)
        if name == 'keepLines':
            index += int(ppr.find(qn('keepNext')) is not None)
        ppr.insert(index, item)
    item.set(qn('val'), '1')


ORIGINAL = ROOT/'demo-documents/bandi/minervino-elenco-sia/originali/domanda-iscrizione.docx'
REV1 = ROOT/'nuovi dati/domanda-iscrizione.GOLD-SINTETICO-REVISIONE-1.docx'
USER = ROOT/'nuovi dati/domanda-iscrizione.GOLD-SINTETICO.docx'
watched = {str(p.relative_to(ROOT)): sha(p) for p in [ORIGINAL, REV1, USER]}
review = json.loads((ROOT/'docs/benchmarks/2026-10-16-minervino-gold-review.json').read_text())
rev = json.loads((ROOT/'docs/benchmarks/2026-10-16-minervino-gold-revision-1.json').read_text())
if FIX.exists():
    raise RuntimeError('Directory della fixture già esistente: non sovrascrivere una versione.')
FIX.mkdir(parents=True)
(FIX/'input').mkdir()
(FIX/'evaluation').mkdir()
shutil.copy2(ORIGINAL, FIX/'input/modulo.docx')
shutil.copy2(ROOT/'demo-documents/bandi/minervino-elenco-sia/originali/avviso.pdf', FIX/'input/avviso.pdf')
shutil.copy2(ROOT/'demo-documents/bandi/minervino-elenco-sia/fonti.json', FIX/'evaluation/provenienza-procedura.json')

snap = ROOT/'backend/data/compilation-audit/minervino-gold-review-20261016T135700Z'
docs = json.loads((snap/'source-documents.json').read_text())
source_ids = {7: 'M01', 8: 'G01', 9: 'M02', 10: 'M03'}
source_texts = {}
sources = []
db = sqlite3.connect(f'file:{ROOT}/backend/data/mapi.db?mode=ro', uri=True)
db.row_factory = sqlite3.Row
for item in docs:
    live = db.execute('select id,name,category,storage_path,updated_at from global_documents where id=?', (item['id'],)).fetchone()
    assert live is not None
    for key in live.keys():
        assert live[key] == item[key], (item['id'], key)
    src = ROOT/'backend/data/uploads'/item['storage_path']
    previous = snap/'documents'/f"{item['id']}-{item['name']}"
    assert sha(src) == sha(previous)
    rel = f"input/sources/{item['name']}"
    (FIX/rel).parent.mkdir(exist_ok=True)
    shutil.copy2(src, FIX/rel)
    if src.suffix != '.pdf':
        source_texts[source_ids[item['id']]] = src.read_text()
    sources.append({'id': source_ids[item['id']], 'path': rel, 'role': 'SOURCE',
                    'scope': 'global', 'category': item['category'], 'live_document_id': item['id'],
                    'name': item['name'], 'sha256': sha(src),
                    'use': 'general_distractor' if item['id'] == 8 else 'company_facts'})
db.close()
sources.append({'id': 'P01', 'path': 'input/avviso.pdf', 'role': 'SOURCE',
                'scope': 'project:benchmark-minervino-v1', 'category': 'procedure',
                'use': 'procedure_requirements_not_company_facts', 'sha256': sha(FIX/'input/avviso.pdf')})
save(FIX/'sources.json', sources)

with zipfile.ZipFile(ORIGINAL) as z:
    original_xml = z.read('word/document.xml')
doc = ET.fromstring(original_xml)
body = doc.find('w:body', NS)
paragraphs = body.findall('w:p', NS)
assert len(paragraphs) == 130
original_paragraphs = [copy.deepcopy(p) for p in paragraphs]
global_indices = {p: i for i, p in enumerate(doc.iter(qn('p')))}

values = {r['original_candidate_id']: r['value_in_gold'] for r in review['source_value_checks']}
proofs = {r['original_candidate_id']: copy.deepcopy(r) for r in review['source_value_checks']}
labels = {r['original_candidate_id']: r['label'] for r in review['source_value_checks']}
for patch in rev['patched_paragraphs']:
    values.update(patch['values'])
for target in ['p51.s0','p52.s0','p52.s1','p53.s0','p53.s1','p53.s2','p53.s3','p53.s4']:
    equivalent = {'p51.s0':'p45.s0','p52.s0':'p45.s1','p52.s1':'p45.s2',
                  'p53.s0':'p45.s3','p53.s1':'p45.s4','p53.s2':'p46.s0',
                  'p53.s3':'p46.s1','p53.s4':'p46.s2'}[target]
    proofs[target] = copy.deepcopy(proofs[equivalent])
    labels[target] = labels[equivalent].replace('Socio Elisa Romano:', 'Direttore tecnico Elisa Romano:')
assert len(values) == 60
user_values = {
    113: ('esecutori.prima_riga', 'Professionisti esecutori: Elisa e Luca',
          'Ing. Elisa Romano — progettazione strutturale e direzione lavori; Ing. Luca Ferri — opere stradali e collaudo statico.', 'designazioni'),
    114: ('esecutori.seconda_riga', 'Professionista esecutore: Andrea',
          'Arch. Andrea Greco — progettazione edilizia, certificazione energetica e CSP/CSE.', 'designazioni'),
    116: ('integrazione.professionista', 'Integrazione delle prestazioni specialistiche',
          'Arch. Andrea Greco — integrazione delle prestazioni specialistiche.', 'designazioni'),
    126: ('sottoscrizione.luogo_data', 'Luogo e data della bozza', 'Bari, 15/10/2026', 'luogo_data'),
}

# Inventario letto per rami del FORM: le etichette dei vuoti sono autoriali,
# non sono tratte dalle interpretazioni del motore da valutare.
alt = {
22: 'denominazione|partita_iva',23:'comune|provincia|via|civico|telefono|email',24:'pec',
26:'nome',27:'qualifica|codice_fiscale',28:'ordine|sezione|provincia|data_iscrizione|numero_iscrizione',
29:'nome',30:'qualifica|codice_fiscale',31:'ordine|sezione|provincia|data_iscrizione|numero_iscrizione',
32:'nome',33:'qualifica|codice_fiscale',34:'ordine|sezione|provincia|data_iscrizione|numero_iscrizione',
36:'denominazione|partita_iva',37:'comune|provincia|via|civico|telefono|fax|email|pec',38:'rappresentante_legale',
55:'denominazione_rtp',56:'nome',57:'qualifica|codice_fiscale|ordine|sezione|provincia|data_iscrizione|numero_iscrizione|specifica_mandante',
58:'nome|qualifica',59:'codice_fiscale|ordine|sezione|provincia|data_iscrizione|numero_iscrizione|specifica_mandante',
60:'nome|qualifica|codice_fiscale|ordine|sezione|provincia|data_iscrizione|numero_iscrizione|specifica_mandante',
62:'denominazione_rtp',63:'capogruppo',65:'denominazione|partita_iva|comune|provincia|via|civico|telefono|email|pec',
67:'nome|qualifica|codice_fiscale',68:'ordine|sezione|provincia|data_iscrizione|numero_iscrizione|societa_consorziata',
69:'nome',70:'qualifica|codice_fiscale',71:'ordine|sezione|provincia|data_iscrizione|numero_iscrizione|societa_consorziata',
72:'nome',73:'qualifica|codice_fiscale',74:'ordine|sezione',75:'provincia|data_iscrizione|numero_iscrizione|societa_consorziata',
95:'nome',96:'qualifica|codice_fiscale|ordine|sezione',97:'provincia|data_iscrizione|numero_iscrizione',
}


def branch(pi):
    if pi <= 17:
        return 'anagrafica_firmatario_e_societa'
    if pi <= 34:
        return 'studio_associato_rappresentante'
    if pi <= 38:
        return 'studio_associato_appartenente'
    if pi <= 53:
        return 'societa_ingegneria'
    if pi <= 60:
        return 'rtp_capogruppo'
    if pi <= 63:
        return 'rtp_mandante'
    if pi <= 75:
        return 'consorzio'
    if pi <= 97:
        return 'rtp_giovane_professionista'
    return 'dichiarazioni_e_sottoscrizione'


def subject(pi, si):
    if pi in [12,13] or (pi == 14 and si == 0):
        return 'Leonardo Montemurro / firmatario della pratica'
    if 43 <= pi <= 44:
        return 'Luca Ferri / socio'
    if 45 <= pi <= 46:
        return 'Elisa Romano / socia'
    if 47 <= pi <= 49:
        return 'Andrea Greco / socio'
    if 51 <= pi <= 53:
        return 'Elisa Romano / direttore tecnico'
    return 'Mapi Ingegneria S.r.l.' if pi <= 53 and pi not in alt else branch(pi)


fields = []
edits = {}
for pi, p in enumerate(paragraphs):
    original_text = text(p)
    spans = blanks(original_text)
    if pi in alt:
        assert len(spans) == len(alt[pi].split('|')), pi
    for si, match in enumerate(spans):
        target = f'p{pi}.s{si}'
        prev = 0 if si == 0 else spans[si-1].end()
        nxt = len(original_text) if si+1 == len(spans) else spans[si+1].start()
        entry = {
            'id': f'text.{pi:03d}.{si}', 'kind': 'text',
            'location': {'body_paragraph_zero_based': pi, 'slot_zero_based': si,
                         'global_paragraph_zero_based': global_indices[p],
                         'original_span': [match.start(), match.end()], 'placeholder': match.group(),
                         'prefix': original_text[prev:match.start()], 'suffix': original_text[match.end():nxt]},
            'branch': branch(pi), 'subject': subject(pi, si),
            'label': labels.get(target),
            'conditions': ['initial.participation_and_signer'],
        }
        if target in values:
            value = values[target]
            proof = proofs[target]
            source_id = source_ids[abs(proof['source_file_id'])]
            quote = proof['source_quote']
            assert ' '.join(quote.split()) in ' '.join(source_texts[source_id].split()), target
            entry.update(expected={'action':'write', 'value':value}, provenance='SOURCE',
                         evidence=[{'source_id':source_id,'quote':quote}], available_after='T0',
                         checkpoints={'T0':'supported_source_proposal','T1':'supported_source_proposal','T2':'write'},
                         equivalences={'whitespace':True,'honorific_optional': 'nome' in (entry['label'] or '').casefold(),
                                       'reviewed_format_note':proof['normalization_or_context']})
            if pi >= 51:
                entry['evidence'].append({'source_id':'M03','quote':next(line for line in source_texts['M03'].splitlines()
                    if line.startswith('- **Elisa Romano:** direttore tecnico'))})
            edits[(pi,si)] = value
        elif pi in user_values:
            semantic, label, value, topic = user_values[pi]
            entry.update(id=semantic, label=label, expected={'action':'write','value':value}, provenance='USER',
                         available_after=f'answers.{topic}', conditions=['initial.participation_and_signer',f'answers.{topic}'],
                         checkpoints={'T0':'await_user','T1':'user_decision_available','T2':'write'},
                         evidence=[{'user_answer_id':topic}])
            edits[(pi,si)] = value
        elif pi in [117,118]:
            entry.update(label='Continuazione non utilizzata dell’integrazione specialistica',
                         expected={'action':'leave_blank','value':None}, provenance='USER',
                         available_after='answers.designazioni',
                         conditions=['initial.participation_and_signer','answers.designazioni'],
                         reason='Il caso designa un solo integratore e nessun altro professionista; mantenere i placeholder originali.',
                         checkpoints={'T0':'await_user','T1':'unused_continuation','T2':'leave_blank'})
        elif pi == 129:
            entry.update(label='Firma digitale', subject='Firmatario / azione manuale',
                         expected={'action':'leave_blank','value':None}, provenance='FORM', available_after='T0',
                         reason='La firma non è un valore da generare e non viene simulata.',
                         checkpoints={'T0':'manual','T1':'manual','T2':'leave_blank'})
        else:
            label = (alt[pi].split('|')[si] if pi in alt else
                     ['Provincia albo nel ramo alternativo professionista','Numero albo nel ramo alternativo professionista'][si-2]
                     if pi == 17 and si >= 2 else None)
            assert label is not None, target
            entry.update(label=label, expected={'action':'leave_blank','value':None}, provenance='FORM+USER',
                         available_after='T0', reason='Ramo escluso dalla partecipazione come società di ingegneria.',
                         checkpoints={'T0':'not_applicable','T1':'not_applicable','T2':'leave_blank'})
        assert entry['label']
        fields.append(entry)
    for si, match in reversed(list(enumerate(spans))):
        if (pi,si) not in edits:
            continue
        value = edits[(pi,si)]
        # Padding solo dove il modulo accosta il placeholder alla parola seguente.
        left = ' ' if match.start() and not original_text[match.start()-1].isspace() and original_text[match.start()-1] not in '“(\"' else ''
        right = ' ' if match.end() < len(original_text) and original_text[match.end()].isalnum() else ''
        replace_span(p, match.start(), match.end(), left + value + right)

# La natura sintetica resta visibile in una riga inizialmente vuota, fuori dai campi.
banner = paragraphs[8]
run = ET.SubElement(banner, qn('r'))
ET.SubElement(run, qn('t')).text = 'BENCHMARK GOLD SINTETICO — NON FIRMARE O PRESENTARE'
for pi in [126,127,128]:
    prop(paragraphs[pi], 'keepNext')
for pi in [126,128,129]:
    prop(paragraphs[pi], 'keepLines')

selected_cells = {(r['table'],r['row'],r['column']) for r in review['selected_table_cells']}
for ti, table in enumerate(body.findall('w:tbl', NS)):
    rows = table.findall('w:tr', NS)
    headers = [text(c) for c in rows[0].findall('w:tc',NS)]
    for ri, row in enumerate(rows[1:], 1):
        cells = row.findall('w:tc',NS)
        for ci, cell in enumerate(cells[1:], 1):
            assert text(cell).strip() == ''
            checked = (ti,ri,ci) in selected_cells
            fields.append({'id':f'preference.t{ti}.r{ri}.c{ci}', 'kind':'table_selection',
                'location':{'table_zero_based':ti,'row_zero_based':ri,'column_zero_based':ci},
                'label':text(cells[0])+' / '+headers[ci], 'subject':'Mapi / preferenza della pratica',
                'branch':'preferenze', 'expected':{'action':'write_x' if checked else 'leave_blank','value':'X' if checked else None},
                'selected':checked,'provenance':'USER' if checked else 'USER_GROUP_EFFECT',
                'available_after':'answers.preferenze','conditions':['answers.preferenze'],
                'reason':'Preferenza selezionata nello scenario.' if checked else 'Alternativa non selezionata; non attesta assenza di qualifiche.',
                'checkpoints':{'T0':'await_user','T1':'selected' if checked else 'unselected','T2':'write_x' if checked else 'leave_blank'}})
            if checked:
                p = cell.find('w:p',NS)
                r = ET.SubElement(p, qn('r'))
                ET.SubElement(r,qn('t')).text = 'X'

chosen_controls = {'-79988761','608863045','146172969'}
participation_controls = []
for sdt in doc.findall('.//w:sdt',NS):
    props = sdt.find('w:sdtPr',NS)
    checkbox = props.find('w14:checkbox',NS)
    if checkbox is None:
        continue
    identity = props.find('w:id',NS).get(qn('val'))
    p = next(node for node in sdt.iterancestors() if node.tag == qn('p'))
    pi = paragraphs.index(p)
    checked = identity in chosen_controls
    label = text(p).lstrip('☐☒ ').strip()
    checkbox.find('w14:checked',NS).set('{'+W14+'}val', '1' if checked else '0')
    t = sdt.find('.//w:sdtContent//w:t',NS)
    assert t.text in ['☐','☒']
    t.text = '☒' if checked else '☐'
    topic = 'attestazioni' if pi == 101 else 'designazioni' if pi == 112 else None
    available = f'answers.{topic}' if topic else 'T0'
    status = 'selected' if checked else 'unselected' if pi <= 64 else 'not_applicable'
    fields.append({'id':f'checkbox.{identity}','kind':'native_checkbox',
        'location':{'body_paragraph_zero_based':pi,'word_control_id':identity},
        'label':label,'subject':'Mapi / pratica','branch':'partecipazione' if pi<=64 else 'dichiarazioni',
        'expected':{'action':'set_boolean','value':checked}, 'available_after':available,
        'provenance':'USER' if checked else 'USER_GROUP_EFFECT',
        'conditions':[f'answers.{topic}'] if topic else ['initial.participation_and_signer'],
        'reason':'Scelta o attestazione autoriale; non una prova aziendale.' if checked else 'Alternativa esclusa dalla scelta della pratica, non un nuovo fatto.',
        'checkpoints':{'T0':'await_user' if topic else status,'T1':status,'T2':'set_boolean'}})
    if pi <= 64:
        participation_controls.append(f'checkbox.{identity}')

out = FIX/'evaluation/gold.docx'
with zipfile.ZipFile(ORIGINAL) as src, zipfile.ZipFile(out,'w') as dest:
    for info in src.infolist():
        dest.writestr(info, ET.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
                      if info.filename=='word/document.xml' else src.read(info.filename))
copy_out = ROOT/'nuovi dati/domanda-iscrizione.GOLD-V1.docx'
assert not copy_out.exists()
shutil.copy2(out,copy_out)

save(FIX/'evaluation/gold.json',{
    'schema':'minervino-authorial-gold-v1','version':1,'project_id':'benchmark-minervino-v1',
    'reference_date':'2026-10-15','authorship':'Gold dell’utente revisionato con XML autonomo; nessun output del compilatore usato per decidere le attese.',
    'authorization':'16/10/2026: l’utente autorizza a risolvere i rilievi, usare la base, creare tag e pubblicare.',
    'original_sha256':sha(ORIGINAL),'gold_sha256':sha(out),
    'checkpoint_semantics':{'T0':'Fonti + richiesta iniziale, prima delle quattro risposte USER.',
        'T1':'Tutte le risposte del copione disponibili, in qualunque ordine pertinente.',
        'T2':'Richiesta esplicita di export della bozza; firma e allegati fuori esecuzione.'},
    'evaluation_policy':{'source_support_is_not_automatic_resolution':True,'gold_and_answers_excluded_from_model_context':True,
        'identifier_checksum':'Non è oggetto di questo caso; conservare i valori dimostrativi, rilevare anomalie separatamente, non correggerli o validarli come reali.',
        'unchanged_placeholders_count_as_blank':True,'empty_alternatives_are_not_negative_company_facts':True,
        'equivalence':'Spazi/titoli personali facoltativi; date equivalenti; Bari/BA solo nel campo provincia; quote verificabili sul documento intero. Nessuna tolleranza su soggetto, ruolo o identificativo.',
        'word_layout_certification':'Non disponibile in Microsoft Word; revisione visuale alternativa esplicitata nel rapporto.'},
    'choice_groups':[
        {'id':'participation','fields':participation_controls,'min_selected':1,'max_selected':1,
         'constraint_origin':'Scelta autoriale di partecipare solo come società di ingegneria; alternative lette nel FORM.',
         'available_after':'T0'},
        {'id':'preferences','fields':[f['id'] for f in fields if f['kind']=='table_selection'],
         'max_selected':6,'expected_selected':6,'constraint_origin':'FORM, paragrafo corpo 77: max. 6 tipologie; il caso sceglie sei celle in sei righe distinte.',
         'available_after':'answers.preferenze'}],
    'manual_review_requirements':[
        {'id':'attachments','status':'outside_document_benchmark','reason':'Curricula, dichiarazioni personali e firma non prodotti o verificati. La checkbox generale è solo attestazione sintetica USER; non prova allegati disponibili né ammissibilità.'},
        {'id':'professional_qualifications','status':'not_proven_by_designations','reason':'Le assegnazioni USER non certificano abilitazioni CSP/CSE, collaudo o altri requisiti specialistici.'},
        {'id':'temporal_roles','status':'use_reference_date','reason':'Luca amministratore storico; cessato 01/10/2026, Leonardo dal 02/10/2026 secondo M03. Non trattare le foto storiche come conflitti contemporanei.'}],
    'fields':fields})

counts = Counter(f['kind'] for f in fields)
summary = {'kind':'authorial_fixture_freeze_not_llm_quality_evaluation','date':'2026-10-16',
    'code_baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'fixture':'demo-documents/benchmark-minervino/v1','gold_copy':str(copy_out.relative_to(ROOT)),
    'gold_sha256':sha(out),'original_sha256':sha(ORIGINAL),'counts':dict(counts),
    'source_text_values':len(values),'user_text_values':len(user_values),
    'selected_table_cells':len(selected_cells),'selected_native_controls':len(chosen_controls),
    'text_blank_count':sum(f['kind']=='text' and f['expected']['action']=='leave_blank' for f in fields),
    'notes_removed_by_restoring_original_placeholders':[117,118],
    'signature_keep_next':[126,127,128],'signature_keep_lines':[126,128,129],
    'source_documents_match_readonly_live_kb':True,
    'historical_inputs_unchanged':all(sha(ROOT/p)==value for p,value in watched.items()),
    'watched_input_sha256':watched,'new_provider_calls':0,'app_code_changed':False,
    'native_word_rendering_available':False,'frozen_with_known_rendering_limit':True}
save(RAW/'preparation.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
