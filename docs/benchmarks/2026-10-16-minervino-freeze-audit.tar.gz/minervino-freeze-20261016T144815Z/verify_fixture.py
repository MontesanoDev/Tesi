"""Verifica indipendente degli artefatti, senza importare il writer applicativo."""
import copy
import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

from docx import Document
from lxml import etree as E

ROOT = Path(__file__).resolve().parents[4]
RAW = Path(__file__).resolve().parent
FIX = ROOT/'demo-documents/benchmark-minervino/v1'
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
W14 = 'http://schemas.microsoft.com/office/word/2010/wordml'
N = {'w':W,'w14':W14}
Q = lambda s:'{'+W+'}'+s
txt = lambda node:''.join(t.text or '' for t in node.iter(Q('t')))
norm = lambda s:' '.join(s.split())

gold = json.loads((FIX/'evaluation/gold.json').read_text())
fields = gold['fields']
assert len(fields)==267 and len({f['id'] for f in fields})==267
assert Counter(f['kind'] for f in fields)=={'text':187,'table_selection':67,'native_checkbox':13}
assert sum(f['kind']=='text' and f['expected']['action']=='write' for f in fields)==64
assert sum(f['kind']=='text' and f['provenance']=='SOURCE' for f in fields)==60
assert sum(f['kind']=='text' and f['expected']['action']=='leave_blank' for f in fields)==123
assert sum(f['kind']=='text' and f['checkpoints']['T0']=='not_applicable' for f in fields)==120
assert sum(f['kind']=='native_checkbox' and f['expected']['value'] for f in fields)==3
assert sum(f['kind']=='table_selection' and f['selected'] for f in fields)==6

original=FIX/'input/modulo.docx'
reference=FIX/'evaluation/gold.docx'
with zipfile.ZipFile(original) as z0, zipfile.ZipFile(reference) as z1:
    assert z0.namelist()==z1.namelist()
    assert z1.testzip() is None
    for name in z1.namelist():
        if name.endswith(('.xml','.rels')):
            E.fromstring(z1.read(name))
    changed=[name for name in z0.namelist() if z0.read(name)!=z1.read(name)]
    assert changed==['word/document.xml'], changed
    r0=E.fromstring(z0.read('word/document.xml'))
    r1=E.fromstring(z1.read('word/document.xml'))
    numbering=E.fromstring(z1.read('word/numbering.xml'))
    assert z0.read('word/numbering.xml')==z1.read('word/numbering.xml')
p0=r0.find('w:body',N).findall('w:p',N)
p1=r1.find('w:body',N).findall('w:p',N)
assert len(p0)==len(p1)==130
assert len(list(r0.iter(Q('p'))))==len(list(r1.iter(Q('p'))))==246
assert len(r1.findall('.//w:tbl',N))==4
assert [len(t.findall('w:tr',N)) for t in r1.findall('.//w:tbl',N)]==[18,2,4,11]

for pi,(before,after) in enumerate(zip(p0,p1)):
    expected=txt(before)
    entries=[f for f in fields if f['kind']=='text' and f['location']['body_paragraph_zero_based']==pi]
    for f in sorted(entries,key=lambda x:x['location']['original_span'][0],reverse=True):
        a,b=f['location']['original_span']
        assert expected[a:b]==f['location']['placeholder']
        if f['expected']['action']=='write':
            value=f['expected']['value']
            # Costruzione della stringa attesa separata dall'editor dei nodi XML.
            prefix=' ' if a and not expected[a-1].isspace() and expected[a-1] not in '“(\"' else ''
            suffix=' ' if b<len(expected) and expected[b].isalnum() else ''
            expected=expected[:a]+prefix+value+suffix+expected[b:]
    if pi==8:
        expected+='BENCHMARK GOLD SINTETICO — NON FIRMARE O PRESENTARE'
    if pi in [39,101,112]:
        expected=expected.replace('☐','☒')
    assert norm(txt(after))==norm(expected), (pi,txt(after),expected)
for pi in [117,118,129]:
    assert txt(p0[pi])==txt(p1[pi]), pi
assert 'Nessun altro professionista previsto nella presente simulazione.' not in txt(r1)
assert 'Dati e qualifiche dichiarati esclusivamente per il benchmark didattico.' not in txt(r1)
for pi in [126,127,128]:
    assert p1[pi].find('w:pPr/w:keepNext',N).get(Q('val'))=='1'
for pi in [126,128,129]:
    assert p1[pi].find('w:pPr/w:keepLines',N).get(Q('val'))=='1'

# Ripristina solo le modifiche consentite, poi confronta tutto l'albero OOXML.
reverted=copy.deepcopy(r1)
rp=reverted.find('w:body',N).findall('w:p',N)
rp[8].remove(rp[8].findall('w:r',N)[-1])
for pi in [126,127,128,129]:
    current=rp[pi].find('w:pPr',N)
    prior=p0[pi].find('w:pPr',N)
    for name in ['keepNext','keepLines']:
        node=current.find('w:'+name,N) if current is not None else None
        old=prior.find('w:'+name,N) if prior is not None else None
        if node is not None:
            current.remove(node)
        if old is not None:
            current.append(copy.deepcopy(old))
    if prior is None and current is not None and len(current)==0:
        rp[pi].remove(current)
tables=reverted.find('w:body',N).findall('w:tbl',N)
for f in fields:
    if f['kind']=='table_selection':
        l=f['location']
        cell=tables[l['table_zero_based']].findall('w:tr',N)[l['row_zero_based']].findall('w:tc',N)[l['column_zero_based']]
        assert txt(cell)==('X' if f['selected'] else '')
        if f['selected']:
            p=cell.find('w:p',N)
            p.remove(p.findall('w:r',N)[-1])
for node in reverted.findall('.//w14:checked',N):
    node.set('{'+W14+'}val','0')
for tree in [r0,reverted]:
    for node in tree.iter(Q('t')):
        node.text=''
        node.attrib.pop('{http://www.w3.org/XML/1998/namespace}space',None)
assert E.tostring(r0,method='c14n')==E.tostring(reverted,method='c14n'), 'Modifica strutturale non prevista'
controls=[s for s in r1.findall('.//w:sdt',N) if s.find('w:sdtPr/w14:checkbox',N) is not None]
assert len(controls)==13
for s in controls:
    identity=s.find('w:sdtPr/w:id',N).get(Q('val'))
    expected=next(f['expected']['value'] for f in fields if f['id']=='checkbox.'+identity)
    val=s.find('w:sdtPr/w14:checkbox/w14:checked',N).get('{'+W14+'}val')
    assert val==('1' if expected else '0')
    assert txt(s)==('☒' if expected else '☐')

loaded=Document(reference)
assert len(loaded.paragraphs)==130 and len(loaded.tables)==4
assert reference.read_bytes()==(ROOT/'nuovi dati/domanda-iscrizione.GOLD-V1.docx').read_bytes()
assert hashlib.sha256(reference.read_bytes()).hexdigest()==gold['gold_sha256']
initial=(FIX/'input/richiesta-iniziale.txt').read_text()
assert 'Leonardo Montemurro' in initial and 'fascia B' not in initial
assert 'Elisa Romano' not in initial and 'veridicità' not in initial
answers=json.loads((FIX/'evaluation/risposte-user.json').read_text())
assert {a['id'] for a in answers['answers']}=={'preferenze','designazioni','attestazioni','luogo_data'}
source_text={s['id']:(FIX/s['path']).read_text() for s in json.loads((FIX/'sources.json').read_text()) if Path(s['path']).suffix!='.pdf'}
for f in fields:
    if f['provenance']=='SOURCE':
        for evidence in f['evidence']:
            assert norm(evidence['quote']) in norm(source_text[evidence['source_id']]), f['id']
manifest=json.loads((FIX/'manifest.json').read_text())
for name,expected in manifest['files'].items():
    assert hashlib.sha256((FIX/name).read_bytes()).hexdigest()==expected,name
assert not any(p.startswith('evaluation/') for p in manifest['authorized_model_input_files'])
assert set(manifest['authorized_model_input_files'])=={'input/modulo.docx','input/richiesta-iniziale.txt'}|{s['path'] for s in json.loads((FIX/'sources.json').read_text())}
result={'status':'passed','fields':267,'checked_text_destinations':187,'checked_table_selections':67,
        'checked_native_controls':13,'written_texts':64,'blank_texts':123,
        'package_parts_changed':changed,'original_structure_preserved_after_reverting_only_allowed_edits':True,
        'source_quotes_located':True,'gold_json_matches_docx':True,'input_answer_separation_checked':True,
        'python_docx_loads':True,'manifest_file_hashes_verified':len(manifest['files']),
        'native_word_rendering_performed':False,'new_provider_calls':0}
(RAW/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
