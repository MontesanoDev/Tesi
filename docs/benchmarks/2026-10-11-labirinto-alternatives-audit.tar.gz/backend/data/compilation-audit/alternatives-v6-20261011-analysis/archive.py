"""Verify/replay frozen synthetic captures, then package only public audit material."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

from app.ai_profiles import resolve_project_settings
from app.compilation_global import validate_global_proposal
from app.docx_templates import inspect_docx
from scripts.compilation_benchmark_fixture import load_fixture

repo=Path(__file__).resolve().parents[4]
base=repo/'backend/data/compilation-audit'
checks=base/'alternatives-v6-20261011-checks'
analysis=base/'alternatives-v6-20261011-analysis'
fixture=load_fixture(repo/'demo-documents/benchmark-compilazione/v1')
layout=inspect_docx(fixture['path'].read_bytes())
all_runs=[]
checks_summary={'software_checks':{
    'targeted_initial':{'passed':264,'seconds':11.06},
    'full_initial':{'passed':1670,'seconds':106.43},
    'targeted_final':{'passed':264,'seconds':10.50},
    'full_final':{'passed':1670,'seconds':106.64},
    'ruff':'passed','fixture_check':'passed','cli_help':'passed','frontend':'unchanged/not run',
    'providers':'simulated where needed in software suites; alternatives tests without LLM'},
    'initial_failures':{'scorer_fixture_key':'recapito instead of corrispondenza; corrected',
                        'ruff':'long lines corrected before frozen code',
                        'capture':'tool output and relazioni.md, no separate complete shell log'}}
(checks/'iterations.json').write_text(json.dumps(checks_summary,indent=2)+'\n')
for name in ['test_compilation_global_alternatives.py','test_compilation_benchmark_fixture.py']:
    shutil.copy2(repo/'backend/tests'/name,checks/name)
for prefix,head in [('alternatives-v6','fd016dd'),('alternatives-v6b','a405f3d')]:
    target=repo/f'docs/benchmarks/2026-10-11-labirinto-{prefix}.json'
    report=json.loads(target.read_text())
    report['software_checks']=checks_summary['software_checks']
    report['review_notes']=[
        'All proposals remain semantic_review_required; no RESOLVED or document/session writes.',
        'Five company values and director/5739 remain correct raw proposals in all runs.',
        'Correspondence/policy alternatives have individual correct SOURCE references in all runs.',
        'Identity/property are model proposals, not independently proved entailment.',
        'The backend cannot detect source alternatives omitted from the output.',
        'NA/review noise and signer inference remain; none of these is approved for rendering.',
        'Review-kind scoring checks authored state and SOURCE IDs only, not completeness or semantics.',
        'One call per run, no retries; fixture/gold unchanged and gold excluded from prompt.'
    ]
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    expected_head=subprocess.check_output(['git','rev-parse',head],cwd=repo,text=True).strip()
    for number in (1,2,3):
        root=base/f'{prefix}-20261011-run{number}'
        manifest=json.loads((root/'manifest.json').read_text())
        for relative,digest in manifest.items():
            assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==digest,(root,relative)
        code=json.loads((root/'code.json').read_text())
        assert code['head']==expected_head
        assert len(code['status'].strip().splitlines())==1,code['status']
        for file in (root/'code').rglob('*.py'):
            relative='backend/'+str(file.relative_to(root/'code'))
            expected=subprocess.check_output(['git','show',f'{code["head"]}:{relative}'],cwd=repo)
            assert file.read_bytes()==expected,(root,relative)
        for name,digest in fixture['manifest']['files'].items():
            assert hashlib.sha256((root/'fixture'/name).read_bytes()).hexdigest()==digest
        assert (root/'fixture/manifest.json').read_bytes()==(fixture['root']/'manifest.json').read_bytes()
        data=json.loads((root/'input.json').read_text())
        request=json.loads((root/'request.json').read_text())
        assert 'expected_state' not in request['messages'][1]['content']
        assert 'annotation_origin' not in request['messages'][1]['content']
        assert data['schema_output']['properties']['version']['const']==6
        assert data['form']['version']==3
        assert 901 not in [s['chunk_id'] for s in data['sources']]
        assert data['user_values']==[]
        assert json.loads(request['messages'][1]['content'])==data
        assert hashlib.sha256((root/'original.docx').read_bytes()).hexdigest()==layout.sha256
        metrics=json.loads((root/'metrics.json').read_text())
        assert metrics['http_calls']==metrics['semantic_calls']==1
        assert metrics['automatic_retries']==metrics['session_writes']==metrics['docx_writes']==0
        assert metrics['user_values']==metrics['resolved']==0
        assert metrics['original_unchanged'] and metrics['http_status']==200
        raw=(root/'response.txt').read_text()
        saved=json.loads((root/'validation.json').read_text())
        replay=validate_global_proposal(raw,layout,fixture['gold']['project_id'],fixture['sources'])
        assert replay==saved,root
        assert replay['resolved']==replay['writes']==0
        assert all(f['written_value'] is None and f['semantic_review_required'] for f in replay['fields'])
        scored=json.loads((root/'fixture-score.json').read_text())
        rows={r['key']:r for r in scored['fields']}
        fields={f['candidate_id']:f for f in replay['fields']}
        for key in ['denominazione','forma','sede','cf','piva']:
            assert rows[key]['value_and_source_match']
            assert rows[key]['local_validation']=='GROUNDED_PROPOSAL'
        for key in ['dt_nome','dt_qualifica','dt_ordine','dt_albo']:
            assert rows[key]['value_and_source_match']
        for key in ['corrispondenza','polizza']:
            field=fields[rows[key]['candidate_id']]
            assert field['validation']=='REVIEW_REQUIRED' and len(field['alternatives'])==2
            assert field['value'] is None
        all_runs.append(root)
# Used only to scan bytes; never printed, saved or included in the archive.
secret=resolve_project_settings('prova').api_key
assert secret
roots=[*all_runs,checks,analysis]
files=sorted({p for root in roots for p in root.rglob('*') if p.is_file()
              and p.name not in {'bundle-manifest.json','bundle-summary.json'}})
files += [repo/f'docs/benchmarks/2026-10-11-labirinto-{prefix}.json'
          for prefix in ['alternatives-v6','alternatives-v6b']]
files += [repo/'docs/benchmark-alternative-source-2026-10-11.md']
for file in files:
    assert file.suffix not in {'.db','.sqlite','.sqlite3','.pyc'}
    assert file.name not in {'.env','.ai-key'}
    assert secret.encode() not in file.read_bytes(),str(file.relative_to(repo))
manifest={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
manifest_file=analysis/'bundle-manifest.json'
manifest_file.write_text(json.dumps(manifest,indent=2)+'\n')
files.append(manifest_file)
target=repo/'docs/benchmarks/2026-10-11-labirinto-alternatives-audit.tar.gz'
with tarfile.open(target,'w:gz') as archive:
    for file in files:
        archive.add(file,arcname=str(file.relative_to(repo)),recursive=False)
with tarfile.open(target,'r:gz') as archive:
    assert len(archive.getmembers())==len(files)
    for file in files:
        assert archive.extractfile(str(file.relative_to(repo))).read()==file.read_bytes()
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(target.parent/(target.name+'.sha256')).write_text(f'{digest}  {target.name}\n')
summary={'files':len(files),'bytes':target.stat().st_size,'sha256':digest,
         'captures_verified':6,'validator_replays_equal':6,'frozen_code_verified':True,
         'secrets_and_db_excluded':True,'originals_unchanged':True}
(analysis/'bundle-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
