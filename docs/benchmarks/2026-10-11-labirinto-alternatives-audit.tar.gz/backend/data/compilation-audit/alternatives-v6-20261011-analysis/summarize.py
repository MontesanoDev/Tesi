"""Read frozen real captures, compare all candidates; never alters provider output."""
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from statistics import mean

repo = Path(__file__).resolve().parents[4]
base = repo / 'backend/data/compilation-audit'
prefix = sys.argv[1] if len(sys.argv) > 1 else 'alternatives-v6'
runs=[]
for number in (1,2,3):
    root=base/f'{prefix}-20261011-run{number}'
    def read(name):
        return json.loads((root/name).read_text())
    metrics,score,validation,code=map(read,['metrics.json','fixture-score.json','validation.json','code.json'])
    fields={f['candidate_id']:f for f in validation['fields']}
    rows=[]
    for scored in score['fields']:
        field=fields[scored['candidate_id']]
        rows.append({**scored,'audit':field})
    runs.append({'run':number,'audit_directory':str(root.relative_to(repo)),
                 'code':code,'metrics':metrics,'score':score,'fields':rows,
                 'grounded_improper_values':[r['key'] for r in rows if
                     r['unexpected_value'] and r['local_validation']=='GROUNDED_PROPOSAL'],
                 'grounded_alternative_reviews':[r['key'] for r in rows if
                     r['audit'].get('alternatives') and r['local_validation']=='REVIEW_REQUIRED'],
                 'validation_error_counts':dict(Counter(
                     error.splitlines()[0] for f in validation['fields'] for error in f['validation_errors'])),
                 'condition_validation_errors':{k:c['validation_errors']
                     for k,c in validation['conditions'].items() if c['validation_errors']},
                 'input_sha256':hashlib.sha256((root/'input.json').read_bytes()).hexdigest(),
                 'request_sha256':hashlib.sha256((root/'request.json').read_bytes()).hexdigest()})
assert len({r['code']['head'] for r in runs})==1
assert len({r['input_sha256'] for r in runs})==1
assert len({r['request_sha256'] for r in runs})==1
baseline=json.loads((repo/'docs/benchmarks/2026-10-11-labirinto-context-v3.json').read_text())
def measures(series):
    return {'ai_seconds_mean':mean(r['metrics']['ai_seconds'] for r in series),
            'total_tokens_mean':mean(r['metrics']['usage']['total_tokens'] for r in series),
            'prompt_tokens_mean':mean(r['metrics']['usage']['prompt_tokens'] for r in series),
            'value_and_source_matches':[r['score']['value_and_source_matches'] for r in series],
            'grounded_value_and_source_matches':[r['score']['grounded_value_and_source_matches'] for r in series],
            'unexpected_values':[r['score']['unexpected_values'] for r in series],
            'unexpected_na':[r['score']['unexpected_na'] for r in series]}
result={'date':'2026-10-11','fixture_version':1,'frozen_code':runs[0]['code']['head'],
        'hypothesis':'grounded peer SOURCE alternatives without a chosen value in one call',
        'experiment':prefix,'identical_input_and_request_within_experiment':True,
        'same_prompt_output_schema_as_baseline':False,'unchanged_form_catalog_and_corpus':True,
        'same_provider_budget_as_baseline':True,'status':'experimental proposal audit, no semantic acceptance',
        'total_calls':3,'total_tokens':sum(r['metrics']['usage']['total_tokens'] for r in runs),
        'total_ai_seconds':sum(r['metrics']['ai_seconds'] for r in runs),
        'session_writes':0,'docx_writes':0,'user_turns':'not measured',
        'comparison':{'context_v3':measures(baseline['runs']),prefix:measures(runs)},'runs':runs}
path=repo/f'docs/benchmarks/2026-10-11-labirinto-{prefix}.json'
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for r in runs:
    print(json.dumps({'run':r['run'], 'seconds':r['metrics']['ai_seconds'],
                     'tokens':r['metrics']['usage'],'matches':r['score']['value_and_source_matches'],
                     'grounded_matches':r['score']['grounded_value_and_source_matches'],
                     'unexpected_values':r['score']['unexpected_values'],
                     'unexpected_na':r['score']['unexpected_na'],
                     'grounded_wrong':r['grounded_improper_values'],
                     'reviews':r['grounded_alternative_reviews']},ensure_ascii=False))
print(json.dumps({'total_tokens':result['total_tokens'],'total_ai_seconds':result['total_ai_seconds'],
                 'input_sha256':runs[0]['input_sha256'],'request_sha256':runs[0]['request_sha256']}))
