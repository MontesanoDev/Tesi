"""Read-only replay and artifact checks for the unscored Trapani transfer call."""

import hashlib
import json
import random
import sqlite3
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from app.compilation_global import validate_global_proposal
from app.db import get_db_path
from app.docx_templates import inspect_docx

root = Path(__file__).resolve().parent.parent
repo = Path(__file__).resolve().parents[5]
run = root / "run1"


def read(name):
    return json.loads((run / name).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


selection = json.loads((root / "selection.json").read_text())
assert random.Random(selection["seed"]).choice(selection["pool"]) == selection["selected"]
manifest = read("manifest.json")
assert all(sha((run / name).read_bytes()) == digest for name, digest in manifest.items())
code = read("code.json")
for path in sorted((run / "code").rglob("*.py")):
    tracked = "backend/" + str(path.relative_to(run / "code"))
    frozen = subprocess.check_output(["git", "show", f"{code['head']}:{tracked}"], cwd=repo)
    assert path.read_bytes() == frozen

original = (run / "original.docx").read_bytes()
assert sha(original) == selection["original_sha256"]
for name, digest in selection["originals_sha256"].items():
    assert sha((repo / name).read_bytes()) == digest
layout = inspect_docx(original, require_candidates=False)
data, audit, metrics = read("input.json"), read("validation.json"), read("metrics.json")
request, http = read("request.json"), read("http-response.txt")
raw = (run / "response.txt").read_text()
proposal = json.loads(raw)
assert json.loads(request["messages"][1]["content"]) == data
assert validate_global_proposal(raw, layout, data["project_id"], data["sources"]) == audit
assert all(s["role"] == "source" and s["scope"] == "global" and s["project_id"] is None
           for s in data["sources"])
frozen_sources = json.loads((root / "input-workspace/sources.json").read_text())
assert data["sources"] == [{key: source[key] for key in data["sources"][0]}
                           for source in frozen_sources]

# Only fingerprints of the same tables acquired before the call, never DB rows.
before = json.loads((root / "preparation/live-state-before.json").read_text())
with tempfile.TemporaryDirectory(prefix="mapi-transfer-state-check-") as temporary:
    snapshot = Path(temporary) / "snapshot.db"
    with sqlite3.connect(f"file:{get_db_path().resolve()}?mode=ro", uri=True) as live:
        with sqlite3.connect(snapshot) as copy:
            live.backup(copy)
    with sqlite3.connect(f"file:{snapshot}?mode=ro", uri=True) as db:
        after = {}
        for table in before:
            rows = [list(row) for row in db.execute(f'SELECT * FROM "{table}" ORDER BY rowid')]
            after[table] = {"rows": len(rows), "sha256": sha(
                json.dumps(rows, default=str, ensure_ascii=False).encode())}
assert after == before
(root / "preparation/live-state-after.json").write_text(json.dumps(after, indent=2) + "\n")

paragraphs = {p["id"]: p["text"] for b in data["form"]["blocks"] for p in b["paragraphs"]}
fields = []
for item in audit["fields"]:
    candidate = data["form"]["candidates"][item["candidate_id"]]
    fields.append({
        "candidate_id": item["candidate_id"], "structural_candidate": candidate,
        "form_context": {pid: paragraphs[pid] for pid in candidate["anchor_paragraph_ids"]},
        "audit": item,
        "manual_observation": "Nessuna proposta. Applicabilità e valore NON valutati; non equivale a MISSING o NOT_APPLICABLE.",
    })

checks = {
    "run_manifest": True, "frozen_code_files": len(list((run / "code").rglob("*.py"))),
    "code_matches_commit": code["head"], "random_draw_reproduced": True,
    "originals_unchanged": True, "replay_identical": True,
    "request_matches_input": True, "authorized_frozen_sources_match": True,
    "same_five_live_tables_fingerprints": True, "live_tables_checked": list(before),
    "not_checked": "No pre-call fingerprints were acquired for other tables. No browser/chat/session workflow was exercised.",
}
(root / "checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
summary = {
    "experiment": "Random real-document transfer smoke test, no gold", "date": "2026-10-11",
    "selection": selection, "metrics": metrics, "raw_proposal": proposal,
    "finish_reason": http["choices"][0]["finish_reason"],
    "candidate_types": dict(Counter(c["type"] for c in data["form"]["candidates"].values())),
    "assessment": {
        "gold_available": False, "fixture_score_ignored": True, "accuracy_percent": None,
        "proposed_assignments": len(proposal["fields"]), "unassigned": audit["unassigned_count"],
        "grounded_proposals": audit["counts"].get("GROUNDED_PROPOSAL", 0),
        "resolved": 0, "writes": 0,
        "observed_failure_stage": "Model response: empty facts/conditions/bindings/fields, not local validation rejection.",
        "mechanism": "The sparse schema has no minimum map size; TASK instructs omission for unsupported/unknown conditions. Empty output parses; unassigned positions are retained as REVIEW_REQUIRED.",
        "cause_not_established": "No internal reasoning was returned. One call cannot establish why all records were omitted; no truncation/provider/schema error was reported.",
        "temporal_limit": "Historical bando and simulated company SOURCE from 2026: this is a transfer test, not proof of eligibility at the bando date.",
    },
    "manual_checks": [
        {"candidates": ["p12.s0", "p12.s3"], "observation": "Signer name and personal tax code unassigned. Company tax code and administrator identity do not automatically prove these values."},
        {"candidates": [f"p75.s{i}" for i in range(9)], "observation": "Engineering-company branch entirely unassigned. SOURCE -43/-44/-30 contain denomination, address, VAT, phone and PEC, but SOURCE data presence does not alone prove branch/representation or each exact destination."},
        {"candidates": ["p97.s0", "p112.s0", "p113.s0"], "observation": "No membership number assigned. Director's 8421 (-45/-32) cannot automatically fill declarant/architect/agronom fields."},
        {"candidates": ["p107.s0"], "observation": "Communication PEC unassigned. A company PEC is present (-44/-30); no proposal or independently verified choice/applicability was produced."},
        {"candidates": ["p175.s0"], "observation": "Signature remains unassigned and structurally write-protected."},
    ],
    "checks": checks, "fields": fields,
}
(root / "manual-review.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"checks": checks, "assessment": summary["assessment"],
                  "candidate_types": summary["candidate_types"]}, ensure_ascii=False, indent=2))
