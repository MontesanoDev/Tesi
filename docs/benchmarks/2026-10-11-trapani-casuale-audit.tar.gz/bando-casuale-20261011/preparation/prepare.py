"""Draw one other real DOCX, freeze its actual scoped SOURCE corpus, no live writes."""
import hashlib
import json
import random
import secrets
import sqlite3
import tempfile
from pathlib import Path

from app.compilation_global import build_global_input
from app.db import get_db_path
from app.docx_templates import inspect_docx
from scripts.benchmark_compilation_global import load_document_corpus

repo = Path(__file__).resolve().parents[5]
root = Path(__file__).resolve().parent.parent
pool = [
    {'name': 'Minervino di Lecce — elenco SIA', 'project_id': 'minervino-di-lecce-elenco-sia',
     'path': 'demo-documents/bandi/minervino-elenco-sia/originali/domanda-iscrizione.docx'},
    {'name': 'Trapani — Green', 'project_id': 'trapani-green',
     'path': 'demo-documents/bandi/trapani-green/originali/manifestazione-interesse.docx'},
]
seed = secrets.randbits(64)
chosen = random.Random(seed).choice(pool)
selection = {'method': 'uniform random.Random(seed).choice over two other versioned real DOCX',
             'seed': seed, 'pool': pool, 'selected': chosen, 'rerolls': 0,
             'reason_pool': 'Catanzaro already used extensively; dedicated Labirinto excluded',
             'originals_sha256': {item['path']: hashlib.sha256((repo / item['path']).read_bytes()).hexdigest() for item in pool},
             'manual_only': True, 'gold_available': False, 'user_values': [],
             'live_changes': 0}
(root / 'selection.json').write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n')
with tempfile.TemporaryDirectory(prefix='mapi-random-bando-') as directory:
    snapshot = Path(directory) / 'snapshot.db'
    with sqlite3.connect(f'file:{get_db_path().resolve()}?mode=ro', uri=True) as live:
        with sqlite3.connect(snapshot) as copy:
            live.backup(copy)
    with sqlite3.connect(f'file:{snapshot}?mode=ro', uri=True) as db:
        db.row_factory = sqlite3.Row
        sources = load_document_corpus(db, chosen['project_id'])
        selection['project_present'] = bool(db.execute('SELECT 1 FROM projects WHERE id=?', (chosen['project_id'],)).fetchone())
        selection['source_files'] = [dict(row) for row in db.execute("SELECT id,name FROM project_files WHERE project_id=? AND kind='source'", (chosen['project_id'],))]
        selection['source_chunks'] = len(sources)
        selection['scope_counts'] = {scope: sum(s['scope'] == scope for s in sources) for scope in sorted({s['scope'] for s in sources})}
        # A logical fingerprint, never a database/configuration export.
        tables = ['projects', 'project_files', 'document_compilations', 'compilation_sessions', 'compilation_fields', 'conversations', 'messages']
        present = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        fingerprints = {}
        for table in tables:
            if table in present:
                rows = [list(row) for row in db.execute(f'SELECT * FROM "{table}" ORDER BY rowid')]
                fingerprints[table] = {'rows': len(rows), 'sha256': hashlib.sha256(json.dumps(rows, default=str, ensure_ascii=False).encode()).hexdigest()}
        (root / 'preparation/live-state-before.json').write_text(json.dumps(fingerprints, indent=2) + '\n')
original = (repo / chosen['path']).read_bytes()
layout = inspect_docx(original, require_candidates=False)
data = build_global_input(layout, chosen['project_id'], sources)
selection.update(original_sha256=layout.sha256, candidate_count=len(data['form']['candidates']),
                 preflight_input_characters=len(json.dumps(data, ensure_ascii=False)),
                 source_coverage=data['source_coverage'])
# Isolated input package accepted by the existing runner. Empty expectations are
# explicitly UN-SCORED; no quality percentage or pass verdict may be derived.
fixture = root / 'input'
fixture.mkdir(exist_ok=False)
(fixture / 'original.docx').write_bytes(original)
(fixture / 'sources.json').write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n')
(fixture / 'manual-only.json').write_text(json.dumps({
    'version': 0, 'project_id': chosen['project_id'], 'form': 'original.docx',
    'original_sha256': layout.sha256, 'fields': [],
    'annotation_origin': 'Unscored transfer test. No authored gold; empty fields are NOT expected emptiness or completeness.',
    'notes': ['Ignore fixture-score.json; use manual source/form review only.'],
}, ensure_ascii=False, indent=2) + '\n')
manifest = {'version': 0, 'project_id': chosen['project_id'], 'form': 'original.docx',
            'sources': 'sources.json', 'gold': 'manual-only.json',
            'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(fixture.iterdir()) if p.is_file()},
            'assessment': 'manual_only_no_gold', 'selected_real_document': chosen['path']}
(fixture / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(root / 'selection.json').write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(selection, ensure_ascii=False, indent=2))
