"""Keep the random draw, use the existing workspace's authorized KB, no live writes."""
import hashlib
import json
import shutil
import sqlite3
import tempfile
from pathlib import Path

from app.compilation_global import build_global_input
from app.db import get_db_path
from app.docx_templates import inspect_docx
from scripts.benchmark_compilation_global import load_document_corpus

repo = Path(__file__).resolve().parents[5]
root = Path(__file__).resolve().parent.parent
shutil.copy2(root / 'selection.json', root / 'selection-before-scope-check.json')
selection = json.loads((root / 'selection.json').read_text())
selection['setup_correction'] = {
    'original_scope': selection['selected']['project_id'], 'original_source_chunks': 0,
    'reason': 'The drawn bando has no stored project. Global SOURCE requires an existing authorized workspace.',
    'scope_used': 'prova', 'new_original_or_draw': False,
    'provider_calls_before_correction': 0, 'live_writes': 0,
}
project_id = 'prova'
with tempfile.TemporaryDirectory(prefix='mapi-transfer-workspace-') as directory:
    snapshot = Path(directory) / 'snapshot.db'
    with sqlite3.connect(f'file:{get_db_path().resolve()}?mode=ro', uri=True) as live:
        with sqlite3.connect(snapshot) as copy:
            live.backup(copy)
    with sqlite3.connect(f'file:{snapshot}?mode=ro', uri=True) as db:
        db.row_factory = sqlite3.Row
        assert db.execute('SELECT 1 FROM projects WHERE id=?', (project_id,)).fetchone()
        sources = load_document_corpus(db, project_id)
        assert sources and all(s['scope'] == 'global' for s in sources)
        assert not db.execute("SELECT 1 FROM project_files WHERE project_id=? AND kind='source'", (project_id,)).fetchone()
original = (repo / selection['selected']['path']).read_bytes()
layout = inspect_docx(original, require_candidates=False)
data = build_global_input(layout, project_id, sources)
selection.update(corpus_workspace=project_id, source_chunks=len(sources),
                 scope_counts={scope: sum(s['scope'] == scope for s in sources) for scope in sorted({s['scope'] for s in sources})},
                 source_categories={category: sum(s['category'] == category for s in sources) for category in sorted({s['category'] for s in sources})},
                 source_documents=sorted({s['source_name'] for s in sources}),
                 source_coverage=data['source_coverage'],
                 preflight_input_characters=len(json.dumps(data, ensure_ascii=False)),
                 no_stored_form_or_session=True, no_user_values=True)
fixture = root / 'input-workspace'
fixture.mkdir(exist_ok=False)
(fixture / 'original.docx').write_bytes(original)
(fixture / 'sources.json').write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n')
(fixture / 'manual-only.json').write_text(json.dumps({
    'version': 0, 'project_id': project_id, 'form': 'original.docx',
    'original_sha256': layout.sha256, 'fields': [],
    'annotation_origin': 'Unscored real-document transfer test. No authored gold; empty fields are NOT expected emptiness or completeness.',
    'notes': ['Ignore fixture-score.json; manual review only. Global KB from the authorized prova workspace.'],
}, ensure_ascii=False, indent=2) + '\n')
manifest = {'version': 0, 'project_id': project_id, 'form': 'original.docx',
            'sources': 'sources.json', 'gold': 'manual-only.json',
            'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(fixture.iterdir()) if p.is_file()},
            'assessment': 'manual_only_no_gold', 'selected_real_document': selection['selected']['path']}
(fixture / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(root / 'selection.json').write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(selection, ensure_ascii=False, indent=2))
