"""Package acquired artifacts, exclude database/configuration and verify bytes."""

import hashlib
import json
import tarfile
from pathlib import Path

from app.ai_profiles import resolve_project_settings

root = Path(__file__).resolve().parent.parent
repo = Path(__file__).resolve().parents[5]
files = sorted(p for p in root.rglob("*") if p.is_file() and p.name != "inventory.json")
secret = resolve_project_settings("prova").api_key
for path in files:
    assert path.suffix not in {".db", ".sqlite", ".sqlite3", ".pyc"}
    assert path.name not in {".env", ".ai-key"}
    assert "__pycache__" not in path.parts
    assert not secret or secret.encode() not in path.read_bytes()
inventory = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root / "inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
files.append(root / "inventory.json")
archive = repo / "docs/benchmarks/2026-10-11-trapani-casuale-audit.tar.gz"
with tarfile.open(archive, "w:gz") as bundle:
    for path in files:
        bundle.add(path, arcname=str(path.relative_to(root.parent)), recursive=False)
with tarfile.open(archive, "r:gz") as bundle:
    members = bundle.getmembers()
    assert len(members) == len(files)
    for member in members:
        assert member.isfile()
        assert bundle.extractfile(member).read() == (root.parent / member.name).read_bytes()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_name(archive.name + ".sha256").write_text(f"{digest}  {archive.name}\n")
print(json.dumps({"files": len(files), "bytes": archive.stat().st_size, "sha256": digest,
                  "byte_equality_verified": True, "configured_secret_absent": True}))
