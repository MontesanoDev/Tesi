"""Clarify clause discovery versus unknown truth, same V8 validator/corpus."""
from pathlib import Path
import app.compilation_global as engine
from scripts import benchmark_compilation_global as runner
root = Path(__file__).resolve().parent
engine.TASK=(root/'compact-v8-task.txt').read_text()+'''
DISTINZIONE OBBLIGATORIA: uncertain_paragraph_ids indica soltanto paragrafi le
cui istruzioni/condizioni NON riesci a ricostruire dal testo. NON indica condizioni
chiare con verità sconosciuta. Se la clausola è comprensibile ma manca la scelta
USER o un fatto SOURCE, registra una condition semantic e proposte conditional;
NON marcare quel paragrafo incerto solo per assenza della conferma. Il backend
rifiuta tutti i dati dei paragrafi di cui non sono state comprese le istruzioni.
I ranges dei candidate sono offset di caratteri [start,end) nel paragrafo:
identificano la singola destinazione, non tutto il paragrafo. Se un paragrafo
richiede più dati, separa le proprietà e proponi ciascuna nel suo spazio preciso.
Dati dell'organizzazione e del sottoscrittore sono soggetti distinti anche nello
stesso paragrafo. L'identità del sottoscrittore non determinata non cancella i
dati documentati dell'organizzazione; questi restano proposte condizionate.
Non trasportare il dato aziendale in un ramo per persone fisiche o in un ruolo
incompatibile. Rispetta i limiti dello schema, anche per reason e quote.
'''
(root/'compact-v8-clear-task.txt').write_text(engine.TASK)
runner.run(runner.arguments(['--fixture','data/compilation-audit/bando-casuale-20261011/input-workspace',
                            '--profile-project','prova','--output',str(root/'compact-v8-clear')]))
