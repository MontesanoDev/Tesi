"""Input-only ablation: literal text adjacent to existing paragraph-slot ranges."""
from pathlib import Path
from collections import defaultdict
from scripts import benchmark_compilation_global as runner

root = Path(__file__).resolve().parent
original = runner.build_global_input

def contextual(layout, project_id, sources):
    data = original(layout, project_id, sources)
    paragraphs = {p['id']:p['text'] for b in data['form']['blocks'] for p in b['paragraphs']}
    grouped = defaultdict(list)
    for candidate in data['form']['candidates'].values():
        if 'range' in candidate:
            grouped[candidate['context_id']].append(candidate)
    for pid, group in grouped.items():
        ordered = sorted(group,key=lambda c:c['range'][0])
        text = paragraphs[pid]
        for index, candidate in enumerate(ordered):
            start,end=candidate['range']
            left=ordered[index-1]['range'][1] if index else 0
            right=ordered[index+1]['range'][0] if index+1<len(ordered) else len(text)
            candidate['slot_context']={'before':text[max(left,start-100):start],
                                       'after':text[end:min(right,end+100)]}
    return data
runner.build_global_input = contextual
runner.run(runner.arguments(['--fixture','data/compilation-audit/bando-casuale-20261011/input-workspace',
                            '--profile-project','prova','--output',str(root/'slot-context')]))
