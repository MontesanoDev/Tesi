"""Diagnostic compact TASK: same input/schema/model/validator, no live writes."""
from pathlib import Path
import app.compilation_global as engine
from scripts.benchmark_compilation_global import arguments, run
root = Path(__file__).resolve().parent
engine.TASK = (root / 'compact-task.txt').read_text()
raise SystemExit(0 if run(arguments([
    '--fixture', 'data/compilation-audit/bando-casuale-20261011/input-workspace',
    '--profile-project', 'prova', '--output', str(root / 'compact')])) else 1)
