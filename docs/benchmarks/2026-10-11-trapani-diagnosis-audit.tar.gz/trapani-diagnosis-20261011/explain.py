"""Separate diagnostic response, deliberately NOT a valid compilation proposal."""
from pathlib import Path
import app.compilation_global as engine
from scripts.benchmark_compilation_global import arguments, run
root = Path(__file__).resolve().parent
engine.TASK = '''Diagnosi documentale in JSON. L'input contiene FORM, SOURCE e schema_output.
Per QUESTA DIAGNOSI non usare schema_output: non stai compilando né approvando
valori. Rispondi invece con {"links": [{"candidate_id":"...", "requirement":"...",
"value":"...", "chunk_id":0, "source_quote":"...", "form_quote":"...",
"applicability_blocker":"..."}], "summary":"..."}.
Individua fino a 12 dati realmente presenti nelle SOURCE e pertinenti a richieste
del FORM. I candidate_id sono posizioni esistenti, i chunk_id e le quote sono
reali. Distingui dato disponibile da condizione per poterlo usare in quel ramo.
Se un dato è documentato ma il ramo non è stabilito, spiega il blocco invece
di cancellare il link. Non trasformare amministratore in firmatario, numero di
un professionista in numero di un altro, dati aziendali in dati personali.
FORM prova solo le richieste. Spiega brevemente gli ostacoli osservabili nel
contratto precedente, non inventare motivazioni interne del modello.'''
(root / 'explain-task.txt').write_text(engine.TASK)
# Failure at compilation validation is expected; raw JSON is the diagnostic result.
run(arguments(['--fixture', 'data/compilation-audit/bando-casuale-20261011/input-workspace',
               '--profile-project', 'prova', '--output', str(root / 'explain')]))
