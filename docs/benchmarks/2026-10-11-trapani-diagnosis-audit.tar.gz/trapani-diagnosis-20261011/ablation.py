"""Diagnostic prompt ablation only; application files and validator unchanged."""
from pathlib import Path
import difflib
import app.compilation_global as engine
from scripts.benchmark_compilation_global import arguments, run

original = engine.TASK
changes = {
    'da quella destinazione; tutte le condizioni sono verificabili.':
    'da quella destinazione. Proponi anche il dato SOURCE quando le condizioni\n  sono ancora sconosciute: il backend ne bloccherà comunque la compilazione.',
    'supporto, e ometti le assegnazioni dipendenti: la sola classificazione del modello':
    'supporto; conserva le proposte SOURCE dipendenti con tutti i riferimenti:\nla sola classificazione del modello',
    "Condizione falsa locale => not_applicable senza valore; sconosciuta => ometti\nl'assegnazione, NON value/not_applicable. Valore assente nelle SOURCE => ometti.":
    'Condizione falsa locale => not_applicable senza valore. Sconosciuta => conserva\nla proposta value e tutte le condizioni: NON significa campo compilabile; il\nbackend resta autoritativo e la blocca. Valore assente nelle SOURCE => ometti.',
}
for before, after in changes.items():
    assert engine.TASK.count(before) == 1
    engine.TASK = engine.TASK.replace(before, after)
root = Path(__file__).resolve().parent
(root / 'ablation-task.txt').write_text(engine.TASK)
(root / 'ablation-task.diff').write_text(''.join(difflib.unified_diff(
    original.splitlines(True), engine.TASK.splitlines(True), fromfile='current_TASK', tofile='diagnostic_TASK')))
args = arguments(['--fixture', 'data/compilation-audit/bando-casuale-20261011/input-workspace',
                  '--profile-project', 'prova', '--output', str(root / 'ablation')])
raise SystemExit(0 if run(args) else 1)
