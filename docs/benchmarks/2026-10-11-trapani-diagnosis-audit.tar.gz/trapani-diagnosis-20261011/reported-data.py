"""TASK-only ablation: document-reported data versus legal/authenticity approval."""
from pathlib import Path
import app.compilation_global as engine
from scripts import benchmark_compilation_global as runner
root = Path(__file__).resolve().parent
engine.TASK += '''\nPRECISAZIONE DEL COMPITO DOCUMENTALE: stai proponendo i valori COME RIPORTATI
nelle SOURCE, non certificando che siano autentici, attuali o utilizzabili in
una candidatura reale. Se una fonte è simulata, didattica o riferita a un altro
periodo, conserva questa qualifica nelle quote/reason. Non inventare validità
reale o storica. La qualifica della fonte non deve cancellare il riconoscimento
dei dati riportati: puoi proporli in conditional con condizioni reali ancora
da verificare. Non considerare simulazione o dati mancanti come prova di NA.
Ruolo, soggetto, proprietà e ancore devono comunque essere pertinenti; non
trasferire valori personali o aziendali a soggetti diversi. Nessuna scrittura,
nessuna accettazione semantica e nessuna autorizzazione alla candidatura.\n'''
(root / 'reported-data-task.txt').write_text(engine.TASK)
runner.run(runner.arguments(['--fixture','data/compilation-audit/bando-casuale-20261011/input-workspace',
                            '--profile-project','prova','--output',str(root/'reported-data')]))
