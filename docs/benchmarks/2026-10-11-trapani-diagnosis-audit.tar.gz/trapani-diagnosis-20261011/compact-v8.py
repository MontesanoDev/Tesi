"""Compact TASK on the actual V8 conditional schema, no application edits."""
from pathlib import Path
import app.compilation_global as engine
from scripts import benchmark_compilation_global as runner
root = Path(__file__).resolve().parent
engine.TASK = (root / 'compact-task.txt').read_text().replace('versione 7','versione 8')
engine.TASK = engine.TASK.replace('Una condizione ancora sconosciuta NON impedisce di proporre un dato documentato:',
'''Una condizione sconosciuta NON impedisce la proposta documentale: usa
"disposition":"conditional" con fact_id, property, reason e conditions non vuoto.''')
engine.TASK = engine.TASK.replace('Per value:', 'Per value (condizioni vere) o conditional (condizioni sconosciute):')
engine.TASK = engine.TASK.replace('disposition=value, form=', 'disposition=value oppure conditional, form=')
engine.TASK += '''\nSe la SOURCE qualifica un dato come simulato, non autentico o riferito a un
periodo, conserva la qualifica nelle prove e nel motivo: la proposta documentale
non certifica autenticità o eleggibilità. Non trasformare la qualifica in NA.
Nessuna compilazione reale in questo compito: conserva i dati SOURCE pertinenti
come proposte, lasciando al backend il blocco delle condizioni unknown.\n'''
(root/'compact-v8-task.txt').write_text(engine.TASK)
runner.run(runner.arguments(['--fixture','data/compilation-audit/bando-casuale-20261011/input-workspace',
                            '--profile-project','prova','--output',str(root/'compact-v8')]))
