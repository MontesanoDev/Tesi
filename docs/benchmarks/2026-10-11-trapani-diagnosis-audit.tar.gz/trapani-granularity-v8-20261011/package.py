"""Archive acquired artifacts, excluding caches, DB and credential files."""
import hashlib
import json
import tarfile
from pathlib import Path
from app.ai_profiles import resolve_project_settings

root=Path(__file__).resolve().parent
repo=root.parents[3]
roots=[root.parent/name for name in [
    'trapani-diagnosis-20261011','trapani-conditional-v8-20261011',
    'trapani-form-grounding-20261011','trapani-granularity-v8-20261011',
]]
files=sorted(p for directory in roots for p in directory.rglob('*')
             if p.is_file() and '__pycache__' not in p.parts
             and p.suffix!='.pyc' and p.name!='bundle-inventory.json')
# Include the frozen unscored inputs and original live fingerprint reference.
base=root.parent/'bando-casuale-20261011'
files+=sorted(p for p in (base/'input-workspace').rglob('*') if p.is_file())
files+=[base/'preparation/live-state-before.json']
secret=resolve_project_settings('prova').api_key
for p in files:
    assert p.suffix not in {'.db','.sqlite','.sqlite3','.pyc'}
    assert p.name not in {'.env','.ai-key'}
    assert not secret or secret.encode() not in p.read_bytes()
inventory={str(p.relative_to(root.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
index=root/'bundle-inventory.json'
index.write_text(json.dumps(inventory,indent=2)+'\n')
files.append(index)
archive=repo/'docs/benchmarks/2026-10-11-trapani-diagnosis-audit.tar.gz'
with tarfile.open(archive,'w:gz') as bundle:
    for p in files:
        bundle.add(p,arcname=str(p.relative_to(root.parent)),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    members=bundle.getmembers()
    assert len(members)==len(files)
    for m in members:
        assert m.isfile() and bundle.extractfile(m).read()==(root.parent/m.name).read_bytes()
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_name(archive.name+'.sha256').write_text(f'{digest}  {archive.name}\n')
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':digest,'byte_equality_verified':True,'configured_secret_absent':True}))
