"""Offline replay and explicit conditional metrics, without changing frozen gold."""
import hashlib
import json
import sqlite3
import sys
import subprocess
import unicodedata
from collections import Counter
from pathlib import Path

from app.compilation_global import validate_global_proposal
from app.db import get_db_path
from app.docx_templates import inspect_docx

root = Path(__file__).resolve().parent
repo = root.parents[3]
diagnosis = root.parent / 'trapani-diagnosis-20261011'
old = root.parent / 'bando-casuale-20261011/run1'

def read(path):
    return json.loads(path.read_text())

def norm(value):
    return ' '.join(unicodedata.normalize('NFC', value).split()).casefold()

def checked_run(path):
    metrics, data, raw = read(path/'metrics.json'), read(path/'input.json'), (path/'response.txt').read_text()
    proposal = json.loads(raw)
    manifest = read(path/'manifest.json')
    assert all(hashlib.sha256((path/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
    code = read(path/'code.json')
    for p in (path/'code').rglob('*.py'):
        assert p.read_bytes()==subprocess.check_output(['git','show',f"{code['head']}:backend/{p.relative_to(path/'code')}"],cwd=repo)
    assert hashlib.sha256((path/'original.docx').read_bytes()).hexdigest()==metrics['original_sha256']
    assert json.loads(read(path/'request.json')['messages'][1]['content'])==data
    if (path/'validation.json').exists():
        audit = read(path/'validation.json')
        # Replay with the code captured at acquisition, preserving historical gates.
        code_text = """import json,sys; from pathlib import Path; import app
p=Path(sys.argv[1]); app.__path__.insert(0,str(p/'code/app'))
from app.compilation_global import validate_global_proposal
from app.docx_templates import inspect_docx
d=json.loads((p/'input.json').read_text())
r=validate_global_proposal((p/'response.txt').read_text(),inspect_docx((p/'original.docx').read_bytes(),require_candidates=False),d['project_id'],d['sources'])
print(json.dumps(r,ensure_ascii=False))"""
        replay = subprocess.check_output([sys.executable, '-c', code_text, str(path)], cwd=repo/'backend', text=True)
        assert json.loads(replay)==audit
    else:
        audit = None
    return metrics,data,proposal,audit

summary={'diagnosis':[],'runs':[],'semantic_acceptance':False,'session_writes':0,'docx_writes':0}
for name in ['baseline','ablation','compact','explain','slot-context','reported-data','compact-v8','compact-v8-clear','thinking-v8']:
    metrics,data,proposal,audit=checked_run(diagnosis/name)
    if name in {'baseline','ablation','compact','explain'}:
        assert data==read(old/'input.json')
    summary['diagnosis'].append({'name':name,'metrics':metrics,'raw_output':proposal,
                                'note':'Explanation is deliberately outside compilation schema, not validated facts.' if name=='explain' else 'Diagnostic acquisition; see thinking flag and per-field audit'})

for series in ['trapani-conditional-v8-20261011','trapani-form-grounding-20261011','trapani-granularity-v8-20261011']:
  for kind in ['trapani','labirinto']:
    for number in range(1,2 if series=='trapani-granularity-v8-20261011' and kind=='labirinto' else 4):
        path=root.parent/series/f'{kind}-run{number}'
        metrics,data,proposal,audit=checked_run(path)
        assert audit and audit['resolved']==audit['writes']==0
        assert metrics['thinking']==(series!='trapani-conditional-v8-20261011')
        assert metrics['http_calls']==1 and metrics['automatic_retries']==0
        assert all(f['written_value'] is None and f['semantic_review_required'] for f in audit['fields'])
        if kind=='trapani':
            before=read(old/'input.json')
            assert {k:v for k,v in data.items() if k!='schema_output'}=={k:v for k,v in before.items() if k!='schema_output'}
        paragraphs={p['id']:p['text'] for b in data['form']['blocks'] for p in b['paragraphs']}
        gold=read(path/'fixture'/('manual-only.json' if kind=='trapani' else 'gold.json'))
        targets=[]
        for expected in gold['fields']:
            item=proposal['fields'].get(expected['candidate_id'],{})
            fact=proposal['facts'].get(item.get('fact_id'),{})
            actual=item.get('choice') if expected['type']=='checkbox' else fact.get('value')
            citations=[e['chunk_id'] for e in fact.get('evidence',[])]
            target=expected['expected_value']
            matches=(type(actual) is bool and actual==target) if type(target) is bool else (isinstance(actual,str) and isinstance(target,str) and norm(actual)==norm(target))
            matches=expected['expected_state']=='RESOLVED' and item.get('disposition') in {'value','conditional'} and matches and bool(citations) and all(c in expected['source_chunk_ids'] for c in citations)
            checked=next(f for f in audit['fields'] if f['candidate_id']==expected['candidate_id'])
            targets.append({'key':expected['key'],'candidate_id':expected['candidate_id'],
                            'expected_state':expected['expected_state'],'expected_value':target,
                            'disposition':item.get('disposition'),'actual_value':actual,
                            'literal_target_and_source_match':bool(matches),
                            'conditional_grounded':bool(matches and checked.get('proposal_grounding')=='GROUNDED_PROPOSAL'),
                            'value_grounded':bool(matches and checked['validation']=='GROUNDED_PROPOSAL'),
                            'audit_validation':checked['validation']})
        fields=[]
        for f in audit['fields']:
            candidate=data['form']['candidates'][f['candidate_id']]
            fields.append({'candidate_id':f['candidate_id'],'structural_candidate':candidate,
                           'form_context':{pid:paragraphs[pid] for pid in candidate['anchor_paragraph_ids']},
                           'audit':f})
        summary['runs'].append({'series':series,'kind':kind,'run':number,'metrics':metrics,'targets':targets,
                               'literal_target_proposals':sum(t['literal_target_and_source_match'] for t in targets),
                               'grounded_conditional_targets':sum(t['conditional_grounded'] for t in targets),
                               'grounded_value_targets':sum(t['value_grounded'] for t in targets),
                               'gold_available':kind=='labirinto','fields':fields,
                               'note':'Literal target metrics do not verify role/branch/property entailment; conditional values are NOT selected or writable.'})
        print(json.dumps({'series':series,'kind':kind,'run':number,'counts':audit['counts'],
                          'conditional':audit['grounded_conditional_proposals'],
                          'targets':sum(t['literal_target_and_source_match'] for t in targets),
                          'proposed':len(proposal['fields']),'facts':len(proposal['facts']),
                          'conditions':len(proposal['conditions'])},ensure_ascii=False))

# Recheck old audits under their historical versions; no raw/output is overwritten.
historical=[]
for name in ['bando-casuale-20261011/run1','subject-binding-v7c-20261011-run1','alternatives-v6b-20261011-run1']:
    path=root.parent/name
    if path.exists():
        checked_run(path)
        historical.append(name)
# One explicit no-thinking control after the same final prompt correction.
path=root/'trapani-no-thinking-run1'
metrics,data,proposal,audit=checked_run(path)
assert not metrics['thinking'] and metrics['http_calls']==1
assert audit and audit['resolved']==audit['writes']==0
assert data==read(root/'trapani-run1/input.json')
summary['runs'].append({'series':root.name,'kind':'trapani-no-thinking','run':1,'metrics':metrics,'fields':audit['fields'],'gold_available':False,'raw_output':proposal})
summary['historical_replays_identical']=historical
thinking = diagnosis/'thinking-v8'
data=read(thinking/'input.json')
current=validate_global_proposal((thinking/'response.txt').read_text(),inspect_docx((thinking/'original.docx').read_bytes(),require_candidates=False),data['project_id'],data['sources'])
previous=read(thinking/'validation.json')
summary['form_normalization_replay']={'before':previous['grounded_conditional_proposals'],'after':current['grounded_conditional_proposals'],'changed_candidates':[a['candidate_id'] for a,b in zip(previous['fields'],current['fields'],strict=True) if a!=b]}
assert summary['form_normalization_replay']=={'before':6,'after':8,'changed_candidates':['p75.s0','p75.s6']}
assert current==read(root.parent/'trapani-form-grounding-20261011/thinking-v8-replay-new-validator.json')
# Final series differs only in explicit thinking and validator code, not input/TASK.
for kind in ['trapani','labirinto']:
    base=root.parent/'trapani-conditional-v8-20261011'/f'{kind}-run1'
    for number in range(1,4):
        final=root.parent/'trapani-form-grounding-20261011'/f'{kind}-run{number}'
        assert read(base/'input.json')==read(final/'input.json')
        a,b=read(base/'request.json'),read(final/'request.json')
        assert a['messages']==b['messages']
        assert b['thinking']=={'type':'enabled'} and b['reasoning_effort']=='low'

before=read(root.parent/'bando-casuale-20261011/preparation/live-state-before.json')
with sqlite3.connect(f'file:{get_db_path().resolve()}?mode=ro',uri=True) as db:
    after={}
    for table in before:
        rows=[list(row) for row in db.execute(f'SELECT * FROM "{table}" ORDER BY rowid')]
        after[table]={'rows':len(rows),'sha256':hashlib.sha256(json.dumps(rows,default=str,ensure_ascii=False).encode()).hexdigest()}
assert after==before
summary['same_five_live_table_fingerprints']=True
summary['metrics_totals']={'new_real_calls':len(summary['diagnosis'])+len(summary['runs']),
                          'total_tokens':sum(r['metrics']['usage']['total_tokens'] for r in summary['diagnosis']+summary['runs']),
                          'ai_seconds':sum(r['metrics']['ai_seconds'] for r in summary['diagnosis']+summary['runs'])}
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(root/'live-state-after.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps(summary['metrics_totals']))
