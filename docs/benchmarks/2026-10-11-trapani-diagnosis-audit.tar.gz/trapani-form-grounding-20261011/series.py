"""Six independent full-document measurements on one frozen code revision."""
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
backend = root.parents[2]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
for kind, fixture in [
    ('trapani', backend / 'data/compilation-audit/bando-casuale-20261011/input-workspace'),
    ('labirinto', backend.parent / 'demo-documents/benchmark-compilazione/v1'),
]:
    for number in range(1, 4):
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == head
        output = root / f'{kind}-run{number}'
        with (root / f'{kind}-run{number}.log').open('w') as log:
            code = subprocess.run([
                'uv', 'run', '--locked', 'python', 'scripts/benchmark_compilation_global.py',
                '--fixture', str(fixture), '--profile-project', 'prova', '--output', str(output), '--thinking',
            ], cwd=backend, stdout=log, stderr=subprocess.STDOUT).returncode
        metrics = json.loads((output / 'metrics.json').read_text())
        print(json.dumps({'kind': kind, 'run': number, 'exit_code': code,
                          'code': head, 'state': metrics.get('state'),
                          'seconds': metrics.get('ai_seconds'), 'usage': metrics.get('usage'),
                          'conditional': metrics.get('grounded_conditional_proposals'),
                          'counts': metrics.get('validation_counts'),
                          'assessment': metrics.get('proposal_assessment')}, ensure_ascii=False), flush=True)
