"""Freeze sanitized artifacts; no DB/key copied, no benchmark reruns."""
import hashlib,json,shutil,sys,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(root/'backend'))
from scripts.benchmark_compilation_dialogue import FIXTURE,real_settings
raw=root/'backend/data/compilation-audit/dialogue-v1-20261012-r1'
preflight=root/'backend/data/compilation-audit/dialogue-v1-preflight'
results=json.loads((raw/'results.json').read_text())
summary=json.loads((raw/'summary.json').read_text())
verification=json.loads((raw/'verification.json').read_text())
shutil.copytree(FIXTURE,raw/'frozen-fixture',dirs_exist_ok=True)
shutil.copy2(root/'backend/scripts/benchmark_compilation_dialogue.py',raw/'frozen-runner.py')
shutil.copytree(preflight,raw/'preflight',dirs_exist_ok=True)
shutil.copy2(root/'backend/data/compilation-audit/dialogue-v1-20261012/protocol.json',raw/'preflight/aborted-before-api-protocol.json')
secret=real_settings('prova').api_key.encode()
files=sorted(p for p in raw.rglob('*') if p.is_file() and p.name!='artifact-manifest.json')
entries={}
for p in files:
 assert p.suffix not in {'.db','.sqlite','.ai-key','.env'},p
 content=p.read_bytes()
 assert secret not in content,p
 entries[str(p.relative_to(raw))]={'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
(raw/'artifact-manifest.json').write_text(json.dumps({'files':entries,'no_credentials':True,'no_database':True},indent=2)+'\n')
public=root/'docs/benchmarks';public.mkdir(exist_ok=True)
bundle=public/'2026-10-12-dialogue-v1-audit.tar.gz'
with tarfile.open(bundle,'w:gz') as tar:
 for p in sorted(raw.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(Path('dialogue-v1')/p.relative_to(raw)))
with tarfile.open(bundle,'r:gz') as tar:
 for m in tar.getmembers():
  data=tar.extractfile(m).read()
  local=raw/Path(m.name).relative_to('dialogue-v1')
  assert data==local.read_bytes()
  assert secret not in data
archive={'file':bundle.name,'file_count':len(entries)+1,'bytes':bundle.stat().st_size,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'verified_byte_for_byte':True,'credentials_scan_passed':True}
metrics={'summary':summary,'verification':verification,'archive':archive,'cases':[{k:r.get(k) for k in ('id','category','intent','decision','effective_decision','effects','export_requested','generated','message','command','error','seconds','score')} for r in results]}
(public/'2026-10-12-dialogue-v1.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(archive,indent=2))
