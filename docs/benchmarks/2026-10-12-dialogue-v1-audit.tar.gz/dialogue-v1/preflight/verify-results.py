"""Read-only verification of the frozen series, including all actual exports."""
import hashlib,json,statistics
from collections import Counter
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn
from app.docx_templates import DRAFT_NOTICE,text_of
from scripts.benchmark_compilation_dialogue import FIXTURE,load_fixture
root=Path('data/compilation-audit/dialogue-v1-20261012-r1')
manifest,contexts,cases=load_fixture(FIXTURE)
results=json.loads((root/'results.json').read_text())
assert [r['id'] for r in results]==[c['id'] for c in cases]
assert len(results)==43 and all(len(r['calls'])==1 for r in results)
assert all(c['schema_valid'] for r in results for c in r['calls'])
assert all(r['effects']['provenance_ok'] for r in results)
assert all(not r['effects']['unexpected_recipients'] for r in results)
assert all(r['error'] is None for r in results)
materialization=[]
for r in results:
 p=root/r['id']
 after=json.loads((p/'after.json').read_text())
 context=contexts[next(c['context'] for c in cases if c['id']==r['id'])]
 values={}
 for s in context['slots']:
  a=after['global_compilation']['dialogue']['answers'].get(s['key'],{})
  if a.get('value') is not None:values[str(s['slot'])]=a['value']
 assert r['effects']['values']==values
 if not r['generated']:continue
 report=json.loads((p/'generated-report.json').read_text())
 original,draft=[Document(p/n) for n in ('template.docx','bozza.docx')]
 old,new=[list(d.element.body.iter(qn('w:tbl'))) for d in (original,draft)]
 changes=[]
 for t,(bt,at) in enumerate(zip(old,new,strict=True)):
  for row,(br,ar) in enumerate(zip(bt.findall(qn('w:tr')),at.findall(qn('w:tr')),strict=True)):
   for col,(bc,ac) in enumerate(zip(br.findall(qn('w:tc')),ar.findall(qn('w:tc')),strict=True)):
    if text_of(bc)!=text_of(ac):changes.append(f't{t}.r{row}.c{col}')
 assert set(changes)=={f['cell_id'] for f in report['fields']}
 for f in report['fields']:
  t,row,col=(int(s[1:]) for s in f['cell_id'].split('.'))
  assert text_of(new[t].findall(qn('w:tr'))[row].findall(qn('w:tc'))[col])==f['written_value']
  assert f['provenance']=='USER' and f['source_evidence']==[]
 assert hashlib.sha256((p/'template.docx').read_bytes()).hexdigest()==manifest['files']['modulo-dialogo.docx']
 assert draft.paragraphs[0].text==DRAFT_NOTICE
 assert [p.text for p in draft.paragraphs[1:]]==[p.text for p in original.paragraphs]
 materialization.append({'case':r['id'],'written':report['written_field_count'],'actual_cells':changes,'provenance':'USER' if changes else None,'original_unchanged':True})
summary={'cases':43,'passed_strict_gold':sum(r['score']['passed'] for r in results),'raw_schema_valid':43,'retry':0,'generation_count':len(materialization),'materialization':materialization,'failed_cases':[r['id'] for r in results if not r['score']['passed']],'model_response_names':dict(Counter(c['model'] for r in results for c in r['calls'])),'user_slot_mutations':sum(len(r['effects']['actions']) for r in results),'user_value_mutations':sum(len(r['effects']['values']) for r in results),'backend_exception_count':0,'median_turn_seconds':statistics.median(r['seconds'] for r in results),'max_turn_seconds':max(r['seconds'] for r in results),'total_ai_seconds':sum(c['seconds'] for r in results for c in r['calls']),'input_tokens':sum(c['usage']['prompt_tokens'] for r in results for c in r['calls']),'output_tokens':sum(c['usage']['completion_tokens'] for r in results for c in r['calls']),'scope':'Prepared checkpoints, not a new automatic compilation or a SOURCE evaluation','live_db_access':'read-only profile lookup only; all mutating services point to a TemporaryDirectory'}
(root/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
