"""Read-only comparison of frozen captures, not a semantic model grader."""
import hashlib
import json
from pathlib import Path
from statistics import mean

repo = Path(__file__).resolve().parents[4]
base = repo / 'backend/data/compilation-audit'
baseline = json.loads((repo/'docs/benchmarks/2026-10-11-labirinto-v1-baseline.json').read_text())
runs=[]
for n in (1,2,3):
    root=base/f'context-v3-20261011-run{n}'
    read=lambda name:json.loads((root/name).read_text())
    metrics,score,audit,code=map(read,['metrics.json','fixture-score.json','validation.json','code.json'])
    validations={f['candidate_id']:f for f in audit['fields']}
    for row in score['fields']:
        row['validation_errors']=validations[row['candidate_id']]['validation_errors']
    runs.append({'run':n,'audit_directory':str(root.relative_to(repo)),'code':code,
                 'metrics':metrics,'score':score,
                 'input_sha256':hashlib.sha256((root/'input.json').read_bytes()).hexdigest(),
                 'request_sha256':hashlib.sha256((root/'request.json').read_bytes()).hexdigest(),
                 'observed_grounded_improper_assignments':[
                     f['key'] for f in score['fields'] if f['unexpected_value']
                     and f['local_validation']=='GROUNDED_PROPOSAL']})
assert len({r['input_sha256'] for r in runs})==1
assert len({r['request_sha256'] for r in runs})==1
assert len({r['code']['head'] for r in runs})==1
assert all(r['metrics']['original_unchanged'] for r in runs)
old_request=json.loads((base/'labirinto-v1-20261011-run1/request.json').read_text())
new_request=json.loads((base/'context-v3-20261011-run1/request.json').read_text())
assert old_request['messages'][0]==new_request['messages'][0]
assert {k:v for k,v in old_request.items() if k!='messages'}=={
    k:v for k,v in new_request.items() if k!='messages'}
summary=lambda records:{
    'ai_seconds_mean':mean(r['metrics']['ai_seconds'] for r in records),
    'total_tokens_mean':mean(r['metrics']['usage']['total_tokens'] for r in records),
    'prompt_tokens_mean':mean(r['metrics']['usage']['prompt_tokens'] for r in records),
    'value_and_source_matches':[r['score']['value_and_source_matches'] for r in records],
    'grounded_value_and_source_matches':[r['score']['grounded_value_and_source_matches'] for r in records],
    'unexpected_values':[r['score']['unexpected_values'] for r in records],
    'grounded_improper_assignments':[r['observed_grounded_improper_assignments'] for r in records]}
result={'date':'2026-10-11','fixture_version':1,'frozen_code':runs[0]['code']['head'],
        'hypothesis':'physical reading contexts and explicit headers; input-only except stricter local anchors',
        'identical_input_and_request_within_experiment':True,'same_prompt_output_schema_and_provider_budget':True,
        'status':'real exploratory comparison; no semantic acceptance or DOCX generation',
        'total_calls':sum(r['metrics']['semantic_calls'] for r in runs),
        'total_tokens':sum(r['metrics']['usage']['total_tokens'] for r in runs),
        'total_ai_seconds':sum(r['metrics']['ai_seconds'] for r in runs),
        'session_writes':0,'docx_writes':0,'user_turns':'not measured',
        'comparison':{'baseline':summary(baseline['runs']),'context_v3':summary(runs)},'runs':runs}
(repo/'docs/benchmarks/2026-10-11-labirinto-context-v3.json').write_text(
    json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='runs'},ensure_ascii=False,indent=2))
