"""Read-only structural comparison; no provider or DB access."""
import hashlib
import json
from pathlib import Path

from app.compilation_global import build_global_input
from app.docx_templates import inspect_docx
from scripts.compilation_benchmark_fixture import load_fixture
from scripts.create_compilation_benchmark import FIXTURE

repo = Path(__file__).resolve().parents[4]
base = repo / 'backend/data/compilation-audit'
fixture = load_fixture(FIXTURE)
old = json.loads((base / 'labirinto-v1-20261011-run1/input.json').read_text())
new = build_global_input(inspect_docx(fixture['path'].read_bytes()),
                         fixture['gold']['project_id'], fixture['sources'])
size = lambda data: len(json.dumps(data, ensure_ascii=False, separators=(',', ':')))
text = lambda data: [(p['id'],p['text']) for b in data['form']['blocks'] for p in b['paragraphs']]
assert text(old) == text(new)
for key in ('sources', 'schema_output', 'source_coverage', 'user_values', 'project_id'):
    assert old[key] == new[key], key
for key, candidate in old['form']['candidates'].items():
    assert {k:v for k,v in candidate.items() if k != 'anchor_paragraph_ids'} == {
        k:v for k,v in new['form']['candidates'][key].items()
        if k not in ('anchor_paragraph_ids','location')}, key
results = {'fixture_text_and_order_unchanged':True,
           'fixture_sources_output_schema_inventory_unchanged':True,
           'fixture_input_characters_before':size(old),'fixture_input_characters_after':size(new),
           'candidate_location_count':sum('location' in c for c in new['form']['candidates'].values()),
           'original_sha256':new['form']['template_sha256'], 'external_regressions':[]}
for path in [repo/'demo-documents/bandi/catanzaro-dl-cse/modello/domanda-partecipazione.docx',
             repo/'demo-documents/bandi/minervino-elenco-sia/originali/domanda-iscrizione.docx']:
    original = path.read_bytes()
    data = build_global_input(inspect_docx(original,require_candidates=False),'alpha',[])
    form = data['form']
    item = {'path':str(path.relative_to(repo)), 'sha256':hashlib.sha256(original).hexdigest(),
            'candidate_count':len(form['candidates']), 'catalog_characters':size(form),
            'original_unchanged':path.read_bytes()==original}
    if 't0.r5.c1' in form['candidates']:
        candidate = form['candidates']['t0.r5.c1']
        item['example_candidate']={'id':'t0.r5.c1',**candidate,
            'location':candidate['location']}
    results['external_regressions'].append(item)
(root := Path(__file__).parent/'structure.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
