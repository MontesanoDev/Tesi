"""Package public synthetic captures and verify them; never include configuration/DB."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

from app.ai_profiles import resolve_project_settings

repo = Path(__file__).resolve().parents[4]
base = repo / 'backend/data/compilation-audit'
checks=base/'context-v2-20261011-checks'
shutil.copy2(repo/'backend/tests/test_compilation_reading_context.py',checks/'test_compilation_reading_context.py')
(checks/'iterations.json').write_text(json.dumps({
    'initial_v2':{'passed':228,'failed':1,'reason':'complete Catanzaro catalog exceeds unchanged budget',
                  'capture':'tool result summarized in relazioni.md; no complete shell log'},
    'v2':{'targeted':229,'targeted_seconds':11.23,'full':1635,'full_seconds':106.56},
    'v3_intermediate':{'targeted':229,'targeted_seconds':10.28,'full':1635,'full_seconds':111.17},
    'v3_final':{'targeted':230,'targeted_seconds':10.00,'full':1636,'full_seconds':105.70},
    'namespace_reproduction':'w-prefixed XPath fails with SyntaxError on valid alternate prefix; expanded QName fixed',
    'ruff':'passed; first import-order issue fixed before v2 capture',
    'fixture_check':'passed, no fixture changes','cli_help':'passed','frontend':'unchanged/not run'
},indent=2)+'\n')
all_runs=[]
for version in (2,3):
    target=repo/f'docs/benchmarks/2026-10-11-labirinto-context-v{version}.json'
    result=json.loads(target.read_text())
    result['software_checks']={'targeted_passed':229 if version==2 else 230,
        'full_backend_passed':1635 if version==2 else 1636,
        'provider_in_software_tests':'simulated where needed; no semantic provider evaluation',
        'ruff':'passed','fixture_reproducibility':'passed','diff_check':'passed',
        'frontend':'unchanged/not run'}
    result['review_notes']=[
        'Only literal value/boolean and authored SOURCE IDs are scored; semantic acceptance remains false.',
        'All five core company values remain correct in every run; no USER values supplied.',
        'All director values, including 5739 rather than 8821, are correct proposals blocked on unknown applicability.',
        'No factual field is promoted to RESOLVED and no document is written.',
        'Policy A is selected in all runs without resolving the discordant attestation.',
        ('V2 creates unsupported signer, participation and NA proposals in run 1; signer values also in run 3.'
         if version==2 else 'V3 operative site correctly NA in runs 1/2, incorrectly assigned but rejected in run 3.'),
        ('More metadata does not yield stable semantic gains.' if version==2 else
         'Run 3 concatenates two alternative correspondence addresses; literal grounding cannot resolve ambiguity.'),
    ]
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    for n in (1,2,3):
        root=base/f'context-v{version}-20261011-run{n}'
        manifest=json.loads((root/'manifest.json').read_text())
        for rel,digest in manifest.items():
            assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,(root,rel)
        code=json.loads((root/'code.json').read_text())
        assert code['status'].strip().splitlines()==[
            f'## prune-backend...origin/prune-backend [ahead {19 if version==2 else 21}]']
        for file in (root/'code').rglob('*.py'):
            rel='backend/'+str(file.relative_to(root/'code'))
            expected=subprocess.check_output(['git','show',f'{code["head"]}:{rel}'],cwd=repo)
            assert file.read_bytes()==expected,(root,rel)
        request=json.loads((root/'request.json').read_text())
        assert 'expected_state' not in request['messages'][1]['content']
        assert 'annotation_origin' not in request['messages'][1]['content']
        assert 901 not in [s['chunk_id'] for s in json.loads(request['messages'][1]['content'])['sources']]
        assert hashlib.sha256((root/'original.docx').read_bytes()).hexdigest()==(
            'eaa3c2b8e45e147d35766e71f77b90bbb0bdc9a339ee79dd12e6ab007ad9c7ca')
        all_runs.append(root)
# This secret is used solely for a byte scan and is never printed/saved.
secret=resolve_project_settings('prova').api_key
assert secret
roots=[*all_runs,checks,base/'context-v2-20261011-analysis',base/'context-v3-20261011-analysis']
files=sorted({p for root in roots for p in root.rglob('*') if p.is_file() and p.name != 'bundle-manifest.json'})
files += [repo/f'docs/benchmarks/2026-10-11-labirinto-context-v{v}.json' for v in (2,3)]
for file in files:
    assert file.suffix not in {'.db','.sqlite','.sqlite3'}
    assert file.name not in {'.env','.ai-key'}
    assert secret.encode() not in file.read_bytes(),str(file.relative_to(repo))
bundle_manifest={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
manifest_file=base/'context-v3-20261011-analysis/bundle-manifest.json'
manifest_file.write_text(json.dumps(bundle_manifest,indent=2)+'\n')
files.append(manifest_file)
target=repo/'docs/benchmarks/2026-10-11-labirinto-context-audit.tar.gz'
with tarfile.open(target,'w:gz') as bundle:
    for p in files:
        bundle.add(p,arcname=str(p.relative_to(repo)),recursive=False)
with tarfile.open(target,'r:gz') as bundle:
    assert len(bundle.getmembers())==len(files)
    for p in files:
        assert bundle.extractfile(str(p.relative_to(repo))).read()==p.read_bytes()
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(target.parent/(target.name+'.sha256')).write_text(f'{digest}  {target.name}\n')
print(json.dumps({'files':len(files),'bytes':target.stat().st_size,'sha256':digest,
    'captures_verified':len(all_runs),'frozen_code_verified':True,'secrets_and_db_excluded':True},indent=2))
