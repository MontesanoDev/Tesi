"""Versioned experimental output: shared SOURCE facts and FORM conditions.

These records are model proposals, including their semantic metadata. Predicate
evaluation is a necessary local check, never independent semantic acceptance.
"""

from typing import Annotated, Literal

from pydantic import Field

from app.document_compilation import StrictModel

Aspect = Literal[
    "identity", "legal_type", "location", "participation", "representation",
    "professional", "other",
]
Reference = Annotated[str, Field(min_length=1, max_length=80)]


class FormSpan(StrictModel):
    paragraph_id: str = Field(min_length=1, max_length=80)
    quote: str = Field(max_length=500)


class SourceSpan(StrictModel):
    chunk_id: int
    quote: str = Field(min_length=1, max_length=800)


class SharedFact(StrictModel):
    subject: str = Field(min_length=1, max_length=150)
    entity: Literal["company", "person", "project", "authority", "other"]
    aspect: Aspect
    property: str = Field(min_length=1, max_length=150)
    value: str = Field(min_length=1, max_length=1500)
    evidence: list[SourceSpan] = Field(min_length=1, max_length=2)


class SharedCondition(StrictModel):
    form: FormSpan
    aspect: Aspect
    operator: Literal["same", "different", "semantic"]
    fact_ids: list[Reference] = Field(max_length=2)
    reason: str = Field(min_length=1, max_length=250)


class SharedField(StrictModel):
    label: str = Field(min_length=1, max_length=250)
    kind: Literal["data", "choice", "declaration", "signature", "decorative"]
    disposition: Literal["value", "missing", "review", "not_applicable", "ignore"]
    form: FormSpan
    # Empty explicitly means no condition proposed, not proof of completeness.
    conditions: list[Reference] = Field(max_length=8)
    fact_id: Reference | None = None
    choice: bool | None = None
    reason: str = Field(default="", max_length=200)


class SharedGlobalProposal(StrictModel):
    version: Literal[2]
    facts: dict[Reference, SharedFact] = Field(max_length=128)
    conditions: dict[Reference, SharedCondition] = Field(max_length=128)
    fields: dict[Reference, SharedField] = Field(max_length=400)


class ScopedCondition(SharedCondition):
    # Semantic scope is proposed by the model, never a new structural location.
    applies_to: list[Reference] = Field(max_length=400)


class AtomicField(SharedField):
    disposition: Literal["value", "not_applicable"]
    property: str | None = Field(default=None, min_length=1, max_length=150)


class CompactGlobalProposal(StrictModel):
    version: Literal[4]
    # Receipt/uncertainty only. The inverse clause map is derived by the backend
    # from each condition's grounded FORM origin, not supplied a second time.
    reviewed_paragraph_ids: list[Reference] = Field(max_length=2048)
    uncertain_paragraph_ids: list[Reference] = Field(max_length=2048)
    conditions: dict[Reference, ScopedCondition] = Field(max_length=128)
    fields: dict[Reference, AtomicField] = Field(max_length=128)
    # Explicitly accounted for, not silently defaulted to missing/decorative.
    deferred: list[Reference] = Field(max_length=400)
    facts: dict[Reference, SharedFact] = Field(max_length=128)


class ConditionTarget(StrictModel):
    kind: Literal["candidate", "paragraph", "table", "section"]
    id: Reference


class StructuralCondition(SharedCondition):
    # These are existing structural scopes, not alternative writable positions.
    scope: list[ConditionTarget] = Field(max_length=400)


class ValueAssignment(AtomicField):
    disposition: Literal["value"]
    fact_id: Reference
    property: str = Field(min_length=1, max_length=150)


class NonApplicableAssignment(AtomicField):
    disposition: Literal["not_applicable"]
    fact_id: None = None
    property: None = None
    choice: None = None


SparseAssignment = Annotated[
    ValueAssignment | NonApplicableAssignment, Field(discriminator="disposition"),
]


class SparseGlobalProposal(StrictModel):
    version: Literal[5]
    conditions: dict[Reference, StructuralCondition] = Field(max_length=128)
    # The structural inventory already bounds destinations; no second, smaller
    # partition budget can discard valid siblings before local validation.
    fields: dict[Reference, SparseAssignment] = Field(max_length=400)
    facts: dict[Reference, SharedFact] = Field(max_length=128)
    # Only substantive uncertainty; the model need not repeat the FORM inventory.
    uncertain_paragraph_ids: list[Reference] = Field(default_factory=list, max_length=2048)
