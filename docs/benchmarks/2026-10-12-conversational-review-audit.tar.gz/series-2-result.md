# Serie reale 2 — codice d6f9991 congelato

Catanzaro: ripresa esplicita della sola sintesi dopo lo schema fallito,
pausa/ripresa, conferma applicabilità società ingegneria e consenso alla bozza.
13 valori SOURCE, nessun valore fattuale USER. Cinque dati societari +8421.
Labirinto V1: nuova analisi/sintesi con tre chiarimenti; unico messaggio USER
con condizione vera + SKIP recapito + UNKNOWN polizza; nessun loop;
poi consenso alla bozza. 17 valori SOURCE, nessun valore fattuale USER.
Materializzazione e originali verificati separatamente senza altre chiamate AI.

Limite osservato nella sintesi Catanzaro post-conferma: la frase «professionista
che firma» attribuisce un ruolo non giustificato dall'audit. Nessun firmatario
scritto nel DOCX, ma il testo è impreciso. Il contesto del binding personale
verificato dal V10 non viene passato esplicitamente alla sintesi: da preservare.
La sintesi ha espresso un dubbio sul recapito unificato senza trattenerlo:
non costituisce una verifica semantica perfetta. Review SOURCE resta un gate
backend distinto dalla prosa; nessuna garanzia di completezza.

Errori di harness: numerazione iniziale saltava perché contava anche i file
planner; corretta senza ripetere richieste AI. Primo runner Labirinto leggeva
created.json Catanzaro, GET404 prima di ogni POST/provider: corretto solo il
runner, failure conservata. Prima verifica DOCX lanciata da cwd radice invece
che backend: nessun file letto/scritto nell'app, poi rieseguita nel cwd corretto.
Serie terminata prima del successivo refinement del contesto di sintesi.
