# Errori intermedi conservati

- Ruff iniziale: cinque E501 sulle nuove righe (poi import order nel nuovo test).
- Test nuovo planner: chiamato parse_turn_plan senza allowed_slots, poi con JSON
  stringa invece che dict; corretti i test, nessuna modifica ai gate.
- Test frontend nuovo: mock projectAnswer assumeva un oggetto body invece della
  stringa question; causava mancato download/chiavi turn duplicate. Corretto mock.
- Dopo correzione: 55 mirati, 101 frontend, 12 browser, 1.878 backend completi.

Questi errori furono osservati nell'output dei tool; il raw dei primi tentativi
non fu scritto su disco. I log delle verifiche successive sono in questa cartella.

- Harness reale: numerazione contava anche richieste planner (1,3,5), poi corretta.
- Primo turno Labirinto leggeva created.json Catanzaro: GET404 e KeyError prima
  del POST/provider. Log originale e before-failed conservati; poi corretto runner.
- Verifica DOCX lanciata da cwd radice: percorso ROOT assente, nessun export/AI.
- Verifica checksum: file DB live con hash fisico cambiato, assert iniziale fallita.
  Log materialization.log conservato, confronto read-only archiviato e limite
  dichiarato; non si è modificato il DB per forzare il controllo.
- Sintesi reale 1: JSON text invece di question, backend rifiuta. Nuova serie
  dopo fix schema, nessun alias/retry automatico o analisi ripetuta.
- Sintesi reale 2: relazione «professionista che firma» non giustificata; nessuna
  scrittura di firmatario. Replay finale con binding personale corretto.
