"""Read-only materialization controls on actual conversational exports."""
import hashlib, json
from pathlib import Path
from io import BytesIO
from docx import Document
from docx.oxml.ns import qn
from lxml import etree
from app.docx_templates import text_of,DRAFT_NOTICE
from app.db import DEFAULT_DB_PATH,DEFAULT_STORAGE_PATH
ROOT=Path('data/compilation-audit/conversation-review-20261012').resolve()
outcomes={}
for case in ['catanzaro','labirinto']:
    folder=ROOT/case
    if not (folder/'generated.docx').exists(): continue
    report=json.loads((folder/'generated-report.json').read_text())
    state=json.loads((folder/'latest-state.json').read_text())
    original=(folder/'template.docx').read_bytes()
    generated=(folder/'generated.docx').read_bytes()
    template=Document(BytesIO(original)); document=Document(BytesIO(generated))
    old=list(template.element.body.iter(qn('w:tbl')))
    new=list(document.element.body.iter(qn('w:tbl')))
    checks=[]
    for f in report['fields']:
        cid=f['cell_id']; t,row,col=(int(p[1:]) for p in cid.split('.'))
        actual=text_of(new[t].findall(qn('w:tr'))[row].findall(qn('w:tc'))[col])
        checks.append({'candidate_id':cid,'label':f['label'],'expected':f['written_value'],
                       'actual':actual,'match':actual==f['written_value'],
                       'provenance':f['provenance'],'source_evidence':f['source_evidence']})
        assert actual==f['written_value']
    changed=[]
    for t,(before,after) in enumerate(zip(old,new,strict=True)):
        for r,(br,ar) in enumerate(zip(before.findall(qn('w:tr')),after.findall(qn('w:tr')),strict=True)):
            for c,(bc,ac) in enumerate(zip(br.findall(qn('w:tc')),ar.findall(qn('w:tc')),strict=True)):
                if text_of(bc)!=text_of(ac): changed.append(f't{t}.r{r}.c{c}')
    expected={f['cell_id'] for f in report['fields']}
    assert set(changed)==expected,(case,changed,expected)
    assert document.paragraphs[0].text==DRAFT_NOTICE
    assert [p.text for p in template.paragraphs]==[p.text for p in document.paragraphs[1:]]
    assert [etree.tostring(n,method='c14n') for n in template.element.iter(qn('w:sdt'))]==[etree.tostring(n,method='c14n') for n in document.element.iter(qn('w:sdt'))]
    assert hashlib.sha256(original).hexdigest()==state['template_sha256']
    assert state['summary']['resolved']==0
    outcomes[case]={'written_count':len(checks),'source_values':sum(f['provenance']=='SOURCE' for f in checks),
        'user_values':sum(f['provenance']=='USER' for f in checks),'checks':checks,
        'changed_cells':changed,'unselected_cells_unchanged':True,'native_controls_unchanged':True,
        'original_unchanged':True,'draft_only':True,'ready_for_submission':False,
        'user_answers':state['global_compilation']['dialogue'].get('answers',{})}
(ROOT/'materialization.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2))
protocol=json.loads((ROOT/'real-protocol.json').read_text())
original=DEFAULT_STORAGE_PATH/'prova/_forms/d2783f0c9bca4796b1c3f445ba38a655.docx'
result={'live_db_unchanged':hashlib.sha256(DEFAULT_DB_PATH.read_bytes()).hexdigest()==protocol['live_db_before_sha256'],
        'live_original_unchanged':hashlib.sha256(original.read_bytes()).hexdigest()==protocol['original_sha256']}
result['live_physical_hash_note']='Physical DB bytes changed; readonly logical comparison archived separately. No claim of identical physical file.'
assert result['live_original_unchanged']
(ROOT/'final-integrity.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:{a:b for a,b in v.items() if a not in ['checks','user_answers','changed_cells']} for k,v in outcomes.items()},ensure_ascii=False))
