"""Real narration only, from existing real audit in a read-only temporary DB."""
import asyncio,json,os,sqlite3,subprocess
from pathlib import Path
ROOT=Path('data/compilation-audit/conversation-review-20261012').resolve()
from app.compilation_global_dialogue import narrate
from app.ai_profiles import project_ai_context

async def main():
    protocol={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
              'kind':'real narration replay only, not a new global analysis or compilation',
              'cases':['catanzaro','labirinto'],'provider':'deepseek-flash','calls_planned':2,
              'changes_during_series':False,'database_read_only':True}
    (ROOT/'series-3-protocol.json').write_text(json.dumps(protocol,indent=2))
    results={}
    for case,db,storage,knowledge in [
        ('catanzaro','snapshot.db','uploads','knowledge'),
        ('labirinto','fixture.db','fixture-uploads','fixture-knowledge')]:
        os.environ.update(MAPI_DB_PATH=str(ROOT/'runtime'/db),
                          MAPI_STORAGE_PATH=str(ROOT/'runtime'/storage),
                          MAPI_KNOWLEDGE_PATH=str(ROOT/'runtime'/knowledge))
        created=json.loads((ROOT/case/'created.json').read_text())
        with sqlite3.connect(f'file:{ROOT/"runtime"/db}?mode=ro',uri=True) as c:
            row=c.execute('SELECT state_json FROM compilation_sessions WHERE id=?',(created['id'],)).fetchone()
            data=json.loads(row[0])['global_compilation']
        folder=ROOT/'narration-replay'/case
        with project_ai_context(created['project_id']):
            result=await narrate(data,folder)
        (ROOT/f'{case}-replayed-dialogue.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
        assert not result.get('error'),result
        results[case]={'message':result['message'],'usage':result['usage'],
                       'ai_seconds':result['ai_seconds'],'http_calls':result['http_calls'],
                       'held_candidate_ids':result['held_candidate_ids']}
        print(case,json.dumps(results[case],ensure_ascii=False),flush=True)
    (ROOT/'series-3-result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
asyncio.run(main())
