"""Actual HTTP-provider/API smoke on temporary SQLite/storage. Never live writes.
Observer delegates actual planner request unchanged; global adapter records its own call.
"""
import asyncio
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
from datetime import UTC, datetime
from pathlib import Path

import httpx

from app import ai_profiles, intents
from app.db import get_db_path, get_storage_path, get_knowledge_path
from app.compilation_global import load_document_corpus
from app.main import app

ROOT = Path('data/compilation-audit/conversation-review-20261012').resolve()
LIVE_DB, LIVE_STORAGE, LIVE_KNOWLEDGE = get_db_path().resolve(), get_storage_path().resolve(), get_knowledge_path().resolve()
RUNTIME = ROOT / 'runtime'
secret = ''

def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)
    if secret: raw = raw.replace(secret, '[REDACTED]')
    path.write_text(raw+'\n')

os.environ.update(MAPI_DB_PATH=str(RUNTIME/'snapshot.db'),
                  MAPI_STORAGE_PATH=str(RUNTIME/'uploads'),
                  MAPI_KNOWLEDGE_PATH=str(RUNTIME/'knowledge'))
frozen_settings = ai_profiles.resolve_project_settings('prova')
secret = frozen_settings.api_key
profile = {'id': frozen_settings.profile_id} if hasattr(frozen_settings,'profile_id') else {}
save('labirinto-protocol.json', {'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'case':'frozen fixture Labirinto V1; fresh database/API upload, one real analysis + narration',
    'provider':frozen_settings.provider,'model':frozen_settings.model,'manual_SOURCE_values':False,
    'limit':'integration smoke, no comparative accuracy claim; app frozen throughout'})

planner_request = intents.request_model_content
case_name = 'labirinto'
planner_calls = 0
async def observe(client, settings, body, timeout, **kwargs):
    global planner_calls
    planner_calls += 1
    number = planner_calls
    save(f'{case_name}/planner-{number}-request.json', {'body': body, 'schema': kwargs.get('response_schema')})
    result = await planner_request(client, settings, body, timeout, **kwargs)
    save(f'{case_name}/planner-{number}-response.json', {'raw': result[0], 'model': result[1], 'usage': result[2]})
    return result
intents.request_model_content = observe

async def run_case(client, name, project, form_id):
    global case_name, planner_calls, secret
    case_name, planner_calls = name, 0
    selected = await client.put(f'/api/projects/{project}/ai-model', json={'profile_id': profile['id']})
    assert selected.status_code == 200, selected.text
    settings = ai_profiles.resolve_project_settings(project)
    assert settings.provider == 'deepseek' and settings.model == 'deepseek-flash' and settings.configured
    secret = settings.api_key
    answer = await client.post(f'/api/projects/{project}/answer', json={'question': 'me lo compili?', 'document_id': form_id})
    save(f'{name}/answer.json', {'status': answer.status_code, 'body': answer.json()})
    assert answer.status_code == 200, answer.text
    sid = answer.json()['compilation']['session_id']
    path = f'/api/projects/{project}/compilation-sessions/{sid}'
    created = (await client.get(path)).json()
    assert created['engine'] == 'global' and created['chat']['auto_continue']
    save(f'{name}/created.json', created)
    print(name, 'CREATED', sid, flush=True)
    result = await client.post(path + '/resolve', json={'version': created['version'], 'automatic': True})
    save(f'{name}/resolve.json', {'status': result.status_code, 'body': result.json()})
    state = (await client.get(path)).json()
    save(f'{name}/state.json', state)
    if state['global_compilation'].get('artifact_path'):
        origin = get_storage_path().resolve() / state['global_compilation']['artifact_path']
        if origin.is_dir():
            shutil.copytree(origin, ROOT / name / 'analysis', dirs_exist_ok=True)
    assert result.status_code == 200, result.text
    assert state['status'] == 'WAITING_FOR_USER' and not state['chat']['auto_continue']
    assert state['last_generation'] is None and state['summary']['resolved'] == 0
    reread = (await client.get(path)).json()
    assert reread == state
    audit_response = await client.get(path + '/global-report')
    save(f'{name}/downloaded-audit.json', audit_response.json())
    fields = state['global_compilation']['fields']
    save(f'{name}/summary.json', {'session_id': sid, 'project_id': project, 'planner_calls': planner_calls,
         'phase': state['global_compilation']['phase'], 'proposals': state['global_compilation']['proposal_count'],
         'omitted': state['global_compilation']['omitted'], 'fields': [
             {k:f[k] for k in ['candidate_id','label','value','selectable','conditions','issues']} for f in fields]})
    print(name, 'REVIEW', len(fields), 'selectable', state['global_compilation']['proposal_count'], flush=True)

async def main():
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://isolated', timeout=400) as client:
        # Fixture corpus is ingested into a separate temporary project/database;
        # the copied Company KB is removed only in this private runtime snapshot
        # by creating a second DB containing no live documents/profiles.
        from app.db import init_database
        from app.ai_profiles import ProfileInput, save_profile
        from app.retrieval_settings import RetrievalInput, save_settings
        fixture_db = RUNTIME / 'fixture.db'
        os.environ.update(MAPI_DB_PATH=str(fixture_db), MAPI_STORAGE_PATH=str(RUNTIME / 'fixture-uploads'),
                          MAPI_KNOWLEDGE_PATH=str(RUNTIME / 'fixture-knowledge'))
        init_database()
        save_settings(RetrievalInput(backend='fts5'))
        fixture_profile = save_profile(ProfileInput(name='DeepSeek smoke', provider='deepseek',
            base_url=frozen_settings.base_url, model=frozen_settings.model, api_key=frozen_settings.api_key,
            context_window=frozen_settings.context_window))
        # sqlite.Row cannot be mutated; pass the configured profile via a copied mapping.
        globals()['profile'] = fixture_profile
        project_response = await client.post('/api/projects', json={'title': 'Benchmark compilazione V1', 'description': 'Smoke isolato'})
        assert project_response.status_code == 201, project_response.text
        project = project_response.json()['id']
        fixture = Path('../demo-documents/benchmark-compilazione/v1')
        for source_path in sorted((fixture / 'sources').glob('*.txt')):
            category = 'general' if source_path.name.startswith('07-') else 'company'
            r = await client.post('/api/global-knowledge/files', data={'category':category},
                files={'file':(source_path.name, source_path.read_bytes())})
            assert r.status_code == 201, r.text
        r = await client.post(f'/api/projects/{project}/forms', files={'file':('modulo-benchmark.docx', (fixture/'modulo-benchmark.docx').read_bytes())})
        assert r.status_code == 201, r.text
        await run_case(client, 'labirinto', project, r.json()['id'])

asyncio.run(main())
