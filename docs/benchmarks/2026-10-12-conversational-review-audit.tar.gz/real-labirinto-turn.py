"""Real composer turns against the isolated smoke session; no simulated providers."""
import asyncio, json, os, shutil, sys, time, re
from pathlib import Path
import httpx

ROOT = Path('data/compilation-audit/conversation-review-20261012').resolve()
RUNTIME = ROOT / 'runtime'
os.environ.update(MAPI_DB_PATH=str(RUNTIME/'fixture.db'),
                  MAPI_STORAGE_PATH=str(RUNTIME/'fixture-uploads'),
                  MAPI_KNOWLEDGE_PATH=str(RUNTIME/'fixture-knowledge'))
from app import ai_profiles, intents
from app.db import get_storage_path
from app.main import app

created = json.loads((ROOT/'labirinto/created.json').read_text())
case = ROOT / 'labirinto'
step = max([int(m[1]) for p in case.glob('turn-*-request.json')
            if (m := re.fullmatch(r'turn-(\d+)-request.json',p.name))] or [0]) + 1
prefix = f'turn-{step:02d}'
secret = ai_profiles.resolve_project_settings(created['project_id']).api_key

def save(name, value):
    path = case / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)
    path.write_text(raw.replace(secret,'[REDACTED]')+'\n')

original = intents.request_model_content
calls = 0
async def observe(client, settings, body, timeout, **kwargs):
    global calls
    calls += 1
    save(f'{prefix}-planner-{calls}-request.json', {'body':body,'schema':kwargs.get('response_schema')})
    result = await original(client,settings,body,timeout,**kwargs)
    save(f'{prefix}-planner-{calls}-response.json', {'raw':result[0],'model':result[1],'usage':result[2]})
    return result
intents.request_model_content = observe

async def main():
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://isolated',timeout=400) as client:
        path = f"/api/projects/{created['project_id']}/compilation-sessions/"+created['id']
        s = (await client.get(path)).json()
        save(f'{prefix}-before.json',s)
        question = Path(sys.argv[1]).read_text().strip()
        body = {'question':question,'document_id':s['form_id'], 'conversation_id':s['conversation_id'],
                'compilation_session_id':s['id'],'compilation_version':s['version']}
        save(f'{prefix}-request.json',body)
        before = time.perf_counter()
        response = await client.post(f"/api/projects/{created['project_id']}/answer",json=body)
        save(f'{prefix}-response.json',{'status':response.status_code,'body':response.json(),
                                     'seconds':time.perf_counter()-before})
        assert response.status_code == 200,response.text
        s = (await client.get(path)).json()
        save(f'{prefix}-after-turn.json',s)
        if s['chat']['auto_continue']:
            r = await client.post(path+'/resolve',json={'version':s['version'],'automatic':True})
            save(f'{prefix}-resolve.json',{'status':r.status_code,'body':r.json()})
            assert r.status_code==200,r.text
            s = r.json()
        save(f'{prefix}-after.json',s)
        save('latest-state.json',s)
        c = await client.get(f"/api/projects/{created['project_id']}/conversations/"+s['conversation_id'])
        save(f'{prefix}-conversation.json',c.json())
        artifact = s['global_compilation'].get('artifact_path')
        if artifact:
            shutil.copytree(get_storage_path().resolve()/artifact,case/'analysis',dirs_exist_ok=True)
        if s['last_generation']:
            for kind,url in s['last_generation']['downloads'].items():
                r = await client.get(url)
                if kind=='report': save('generated-report.json',r.json())
                else: (case/('generated.docx' if kind=='docx' else 'template.docx')).write_bytes(r.content)
        print(json.dumps({'step':step,'planner_calls':calls,'status':s['status'],'message':
            s['global_compilation']['dialogue'].get('message'),'command':response.json().get('compilation'),
            'auto_continue':s['chat']['auto_continue']},ensure_ascii=False),flush=True)

asyncio.run(main())
