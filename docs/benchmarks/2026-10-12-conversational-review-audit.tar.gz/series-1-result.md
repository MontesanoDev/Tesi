# Serie reale 1 — codice fe73786 congelato

Un routing + un'analisi globale + una sintesi, tutti DeepSeek reali.
Analisi: 13 proposte SOURCE selezionabili, cinque dati societari e direttore
incluso 8421 presenti. Sintesi: JSON con questions[].text invece di question.
Backend rifiuta per extra_forbidden/missing; nessuna bozza o update USER.
La semantica del messaggio era pertinente, ma il contratto strutturale fallisce.
Raw, richiesta e validazione offline conservati in catanzaro/analysis/dialogue/.
Serie terminata prima di modificare codice; nessun retry automatico AI.
