import asyncio,hashlib,json,sqlite3,time,traceback
from pathlib import Path
from app import intents,compilation_chat,compilation_global_sessions as gs
from app.config import use_ai_settings
from app.db import get_db_path
from scripts.benchmark_compilation_dialogue import real_settings

OUT=Path('data/compilation-audit/generate-consent-20261013')
SID='0ce44c51adcb4b3c995f1100f71aa5e1'
async def main():
 settings=real_settings('minervino-di-lecce-elenco-sia')
 def save(name,data):
  text=json.dumps(data,ensure_ascii=False,indent=2,default=str)
  if settings.api_key: text=text.replace(settings.api_key,'[REDACTED]')
  (OUT/name).write_text(text+'\n')
 with sqlite3.connect(f'file:{get_db_path().resolve()}?mode=ro',uri=True) as db:
  db.row_factory=sqlite3.Row
  row=db.execute('select * from compilation_sessions where id=?',(SID,)).fetchone()
  state=json.loads(row['state_json']); payload=gs.session_payload(row,state)
  turns=[dict(r) for r in db.execute('select question,answer from conversation_turns where conversation_id=? and id<207 order by id',(row['conversation_id'],))]
  print('provider',settings.provider,'model',settings.model)
  save('session-payload.json',payload)
  save('initial-row-hashes.json',{'id':SID,'version':row['version'],'state':hashlib.sha256(row['state_json'].encode()).hexdigest(),'original':hashlib.sha256(row['original']).hexdigest()})
 calls=[];original=intents.request_model_content
 async def capture(client,config,body,timeout,**kwargs):
  entry={'request':body,'schema':kwargs.get('response_schema')}; calls.append(entry); index=len(calls)
  start=time.perf_counter()
  try:
   raw,model,usage=await original(client,config,body,timeout,**kwargs)
   entry.update(raw=raw,model=model,usage=usage)
   return raw,model,usage
  except Exception as exc:
   entry.update(error=type(exc).__name__,message=str(exc)); raise
  finally:
   entry['seconds']=time.perf_counter()-start;save(f'before-call-{index}.json',entry)
 intents.request_model_content=capture
 try:
  with use_ai_settings(settings):
   result=await intents.plan_chat_turn('si',turns,[{'id':row['form_id'],'name':state['template_name']}],selected_document={'document_id':row['form_id'],'name':state['template_name'],'role':'form','can_compile':True},compilation=compilation_chat.planner_context(payload))
  save('before-result.json',{'intent':result.intent,'decision':result.decision.model_dump(),'calls':len(calls)})
  print('RESULT',result.intent,result.decision.model_dump())
 except Exception as exc:
  save('before-result.json',{'error':type(exc).__name__,'message':str(exc),'cause':str(exc.__cause__),'traceback':traceback.format_exc(),'calls':len(calls)})
  print('ERROR',type(exc).__name__,str(exc),'CAUSE',str(exc.__cause__))
 print('calls',len(calls))
asyncio.run(main())
