import asyncio,json,sqlite3,time
from pathlib import Path
from app import intents,compilation_chat,compilation_global_sessions as gs
from app.db import get_db_path
from app.config import use_ai_settings
from scripts.benchmark_compilation_dialogue import real_settings
ROOT=Path('data/compilation-audit/generate-consent-20261013')
async def main():
 settings=real_settings('minervino-di-lecce-elenco-sia')
 with sqlite3.connect(f'file:{get_db_path().resolve()}?mode=ro',uri=True) as db:
  db.row_factory=sqlite3.Row
  row=db.execute('select * from compilation_sessions where id=?',('0ce44c51adcb4b3c995f1100f71aa5e1',)).fetchone(); state=json.loads(row['state_json']); s=gs.session_payload(row,state)
  turns=[dict(r) for r in db.execute('select question,answer from conversation_turns where conversation_id=? order by id',(row['conversation_id'],))]
 original=intents.request_model_content
 variants=[('si',turns[:2],True),('si',turns[:2],False),('sì',turns[:2],True),('ok si va bene',turns[:2],True),('si',turns,True)]
 for index,(message,history,document) in enumerate(variants,1):
  calls=[]
  async def capture(client,config,body,timeout,**kwargs):
   entry={'request':body,'schema':kwargs.get('response_schema')};calls.append(entry);start=time.perf_counter()
   try:
    raw,model,usage=await original(client,config,body,timeout,**kwargs);entry.update(raw=raw,model=model,usage=usage);return raw,model,usage
   except Exception as exc:
    entry.update(error=type(exc).__name__,message=str(exc));raise
   finally: entry['seconds']=time.perf_counter()-start
  intents.request_model_content=capture
  selection=({'selected_document':{'document_id':row['form_id'],'name':state['template_name'],'role':'form','can_compile':True}} if document else {'selected_form':{'form_id':row['form_id'],'name':state['template_name']}})
  record={'message':message,'has_document_reference':document,'history':history}
  try:
   with use_ai_settings(settings):
    result=await intents.plan_chat_turn(message,history,[{'id':row['form_id'],'name':state['template_name']}],compilation=compilation_chat.planner_context(s),**selection)
   record.update(intent=result.intent,decision=result.decision.model_dump())
  except Exception as exc:
   record.update(error=type(exc).__name__,message=str(exc),cause=str(exc.__cause__))
  record['calls']=calls
  raw=json.dumps(record,ensure_ascii=False,indent=2).replace(settings.api_key,'[REDACTED]')
  (ROOT/f'before-variant-{index}.json').write_text(raw+'\n')
  print(json.dumps({'case':index,'intent':record.get('intent'),'error':record.get('error'),'cause':record.get('cause'),'calls':len(calls)},ensure_ascii=False),flush=True)
asyncio.run(main())
