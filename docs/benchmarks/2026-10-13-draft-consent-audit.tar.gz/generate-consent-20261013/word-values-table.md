| Candidate | Dato | Valore scritto | Provenienza | SOURCE |
|---|---|---|---|---|
| `p14.s1` | Denominazione operatore economico | Mapi Ingegneria S.r.l. | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p15.s1` | Provincia sede operatore | BA | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p15.s2` | Telefono operatore | +39 080 000 2040 | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -44 |
| `p16.s0` | E-mail operatore | segreteria@mapi-ingegneria.demo | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -44 |
| `p16.s1` | PEC operatore | mapi.ingegneria@pec.demo | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -44 |
| `p16.s2` | Partita IVA operatore | IT01234567890 | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p40.s0` | Denominazione/ragione sociale | Mapi Ingegneria S.r.l. | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p41.s0` | P. IVA società | IT01234567890 | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p41.s1` | Sede legale società | Via Giovanni Amendola 172/C, 70126 Bari (BA), Italia | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p42.s0` | Provincia sede legale | BA | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p42.s1` | Via/Piazza sede legale | Via Giovanni Amendola | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p42.s2` | Numero civico sede legale | 172/C | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -43 |
| `p42.s3` | Telefono società | +39 080 000 2040 | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -44 |
| `p42.s4` | E-mail società | segreteria@mapi-ingegneria.demo | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -44 |
| `p42.s5` | PEC società | mapi.ingegneria@pec.demo | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -44 |
| `p51.s0` | Direttore Tecnico - nome e cognome | Elisa Romano | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -45 |
| `p52.s0` | Direttore Tecnico - qualifica professionale | Ingegnere | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -45 |
| `p53.s0` | Direttore Tecnico - Ordine/Collegio professionale | Ordine degli Ingegneri di Bari | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -45 |
| `p53.s2` | Direttore Tecnico - provincia ordine | Bari | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -45 |
| `p53.s4` | Direttore Tecnico - numero iscrizione | 8421 | SOURCE, conferma condizioni USER | generalita-mapi.md, chunk -45 |
