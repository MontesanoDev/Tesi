"""Analyze every frozen response; no inference of semantic acceptance from counts."""
import hashlib
import json
from collections import Counter
from pathlib import Path
from statistics import mean

repo = Path(__file__).resolve().parents[4]
base = repo / 'backend/data/compilation-audit'
runs = []
for number in (1, 2, 3):
    root = base / f'subject-binding-v7b-20261011-run{number}'
    def read(name):
        return json.loads((root / name).read_text())
    metrics, score, validation, code = map(read, ['metrics.json', 'fixture-score.json', 'validation.json', 'code.json'])
    fields = {f['candidate_id']: f for f in validation['fields']}
    rows = [{**row, 'audit': fields[row['candidate_id']]} for row in score['fields']]
    runs.append({'run': number, 'audit_directory': str(root.relative_to(repo)), 'code': code,
                 'metrics': metrics, 'score': score, 'fields': rows,
                 'bindings': validation.get('bindings', {}),
                 'grounded_improper_values': [r['key'] for r in rows if r['unexpected_value'] and r['local_validation'] == 'GROUNDED_PROPOSAL'],
                 'grounded_alternative_reviews': [r['key'] for r in rows if r['audit'].get('alternatives') and r['local_validation'] == 'REVIEW_REQUIRED'],
                 'validation_error_counts': dict(Counter(error.splitlines()[0] for f in validation['fields'] for error in f['validation_errors'])),
                 'input_sha256': hashlib.sha256((root / 'input.json').read_bytes()).hexdigest(),
                 'request_sha256': hashlib.sha256((root / 'request.json').read_bytes()).hexdigest()})
assert len({r['code']['head'] for r in runs}) == 1
assert len({r['input_sha256'] for r in runs}) == 1
assert len({r['request_sha256'] for r in runs}) == 1
baseline = json.loads((repo / 'docs/benchmarks/2026-10-11-labirinto-alternatives-v6b.json').read_text())
def measures(series):
    return {'ai_seconds_mean': mean(r['metrics']['ai_seconds'] for r in series),
            'total_tokens_mean': mean(r['metrics']['usage']['total_tokens'] for r in series),
            'prompt_tokens_mean': mean(r['metrics']['usage']['prompt_tokens'] for r in series),
            'value_and_source_matches': [r['score']['value_and_source_matches'] for r in series],
            'grounded_value_and_source_matches': [r['score']['grounded_value_and_source_matches'] for r in series],
            'unexpected_values': [r['score']['unexpected_values'] for r in series],
            'unexpected_na': [r['score']['unexpected_na'] for r in series],
            'grounded_improper_values': [r['grounded_improper_values'] for r in series]}
result = {'date': '2026-10-11', 'fixture_version': 1, 'frozen_code': runs[0]['code']['head'],
          'hypothesis': 'prevent administrator-to-signer role substitution with a literal shared person-role binding',
          'identical_input_and_request_within_experiment': True,
          'same_prompt_output_schema_as_baseline': False, 'unchanged_form_catalog_and_corpus': True,
          'same_provider_budget_as_baseline': True, 'status': 'experimental literal traceability, semantic review still required',
          'total_calls': 3, 'total_tokens': sum(r['metrics']['usage']['total_tokens'] for r in runs),
          'total_ai_seconds': sum(r['metrics']['ai_seconds'] for r in runs),
          'session_writes': 0, 'docx_writes': 0, 'user_values': 0, 'user_turns': 'not measured',
          'comparison': {'alternatives_v6b': measures(baseline['runs']), 'subject_binding_v7': measures(runs)},
          'runs': runs,
          'review_notes': ['literal_match is not independent semantic entailment or RESOLVED.',
                           'Entity/property/full role are model proposals; no general semantic verifier.',
                           'No applicability, source-property attribution or completeness improvement claimed.',
                           'All raw responses retained; unchanged gold excluded from input.',
                           'Positive explicit role case tested in software, not a new positive real signer fixture.']}
path = repo / 'docs/benchmarks/2026-10-11-labirinto-subject-binding-v7b.json'
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
for run in runs:
    rows = {r['key']: r for r in run['fields']}
    details = {key: {'raw_value': rows[key]['actual_value'], 'validation': rows[key]['local_validation'],
                     'binding': rows[key]['audit'].get('subject_binding'),
                     'errors': rows[key]['audit']['validation_errors']} for key in
               ['firmatario', 'carica', 'dt_nome', 'dt_qualifica', 'dt_ordine', 'dt_albo']}
    print(json.dumps({'run': run['run'], 'metrics': run['metrics'],
                     'score': {k: v for k, v in run['score'].items() if k != 'fields'},
                     'wrong_grounded': run['grounded_improper_values'],
                     'reviews': run['grounded_alternative_reviews'], 'details': details}, ensure_ascii=False))
print(json.dumps({'total_tokens': result['total_tokens'], 'total_ai_seconds': result['total_ai_seconds'],
                  'comparison': result['comparison']}, ensure_ascii=False))
