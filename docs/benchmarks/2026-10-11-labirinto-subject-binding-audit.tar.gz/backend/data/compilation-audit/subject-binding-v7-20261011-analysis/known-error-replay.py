"""Offline, distinct counterfactual input; never rewrite a real capture."""
import json
from pathlib import Path

from app.compilation_global import validate_global_proposal
from app.docx_templates import inspect_docx
from scripts.compilation_benchmark_fixture import load_fixture

repo = Path(__file__).resolve().parents[4]
root = Path(__file__).resolve().parent
baseline = repo / 'backend/data/compilation-audit/alternatives-v6b-20261011-run3'
fixture = load_fixture(repo / 'demo-documents/benchmark-compilazione/v1')
layout = inspect_docx(fixture['path'].read_bytes())
raw = (baseline / 'response.txt').read_text()
saved = json.loads((baseline / 'validation.json').read_text())
old = validate_global_proposal(raw, layout, fixture['gold']['project_id'], fixture['sources'])
assert old == saved
payload = json.loads(raw)
payload.update(version=7, bindings={})
new_raw = json.dumps(payload, ensure_ascii=False)
new = validate_global_proposal(new_raw, layout, fixture['gold']['project_id'], fixture['sources'])
key = next(f['candidate_id'] for f in fixture['gold']['fields'] if f['key'] == 'firmatario')
old_field = next(f for f in old['fields'] if f['candidate_id'] == key)
new_field = next(f for f in new['fields'] if f['candidate_id'] == key)
assert old_field['validation'] == 'GROUNDED_PROPOSAL'
assert new_field['validation'] == 'REVIEW_REQUIRED' and new_field['value'] is None
assert new_field['subject_binding']['result'] == 'review_required'
(root / 'known-error-counterfactual-input.json').write_text(new_raw + '\n')
(root / 'known-error-counterfactual-validation.json').write_text(json.dumps(new, ensure_ascii=False, indent=2) + '\n')
report = {'method': 'Offline counterfactual: same V6 real proposal, version=7, bindings empty; not a new AI response',
          'baseline_capture': str(baseline.relative_to(repo)), 'historical_v6_replay_unchanged': True,
          'candidate_id': key, 'before': old_field, 'after': new_field,
          'semantic_acceptance': False, 'writes': 0}
(root / 'known-error-replay.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'candidate_id': key, 'before': old_field['validation'], 'after': new_field['validation'],
                  'value_after': new_field['value'], 'historical_replay_unchanged': True}))
