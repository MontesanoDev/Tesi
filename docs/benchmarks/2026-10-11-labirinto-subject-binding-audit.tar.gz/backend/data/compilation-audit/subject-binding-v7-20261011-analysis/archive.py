"""Verify frozen code/raw/provenance/replay; package synthetic audit, never live data."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

from app.ai_profiles import resolve_project_settings
from app.compilation_global import validate_global_proposal
from app.docx_templates import inspect_docx
from scripts.compilation_benchmark_fixture import load_fixture

repo = Path(__file__).resolve().parents[4]
base = repo / 'backend/data/compilation-audit'
analysis = Path(__file__).resolve().parent
checks = base / 'subject-binding-v7-20261011-checks'
fixture = load_fixture(repo / 'demo-documents/benchmark-compilazione/v1')
layout = inspect_docx(fixture['path'].read_bytes())
roots, public = [], []
all_tokens, all_seconds = 0, 0.0
baseline_input = json.loads((base / 'alternatives-v6b-20261011-run1/input.json').read_text())
for suffix, short_head in [('', '97d84fb'), ('b', 'c2b30b0'), ('c', '5962cb6')]:
    public.append(repo / f'docs/benchmarks/2026-10-11-labirinto-subject-binding-v7{suffix}.json')
    for number in (1, 2, 3):
        root = base / f'subject-binding-v7{suffix}-20261011-run{number}'
        roots.append(root)
        def read(name):
            return json.loads((root / name).read_text())
        manifest = read('manifest.json')
        for relative, digest in manifest.items():
            assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == digest, (root, relative)
        code = read('code.json')
        head = subprocess.check_output(['git', 'rev-parse', short_head], cwd=repo, text=True).strip()
        assert code['head'] == head and len(code['status'].strip().splitlines()) == 1
        for file in (root / 'code').rglob('*.py'):
            relative = 'backend/' + str(file.relative_to(root / 'code'))
            expected = subprocess.check_output(['git', 'show', f'{head}:{relative}'], cwd=repo)
            assert file.read_bytes() == expected, (root, relative)
        for name, digest in fixture['manifest']['files'].items():
            assert hashlib.sha256((root / 'fixture' / name).read_bytes()).hexdigest() == digest
        assert (root / 'fixture/manifest.json').read_bytes() == (fixture['root'] / 'manifest.json').read_bytes()
        data, request = read('input.json'), read('request.json')
        assert data['form'] == baseline_input['form']
        assert data['sources'] == baseline_input['sources']
        assert data['schema_output']['properties']['version']['const'] == 7
        assert data['form']['version'] == 3 and data['user_values'] == []
        assert json.loads(request['messages'][1]['content']) == data
        assert all(token not in request['messages'][1]['content'] for token in ['expected_state', 'annotation_origin'])
        assert 901 not in [source['chunk_id'] for source in data['sources']]
        assert hashlib.sha256((root / 'original.docx').read_bytes()).hexdigest() == layout.sha256
        metrics = read('metrics.json')
        assert metrics['http_calls'] == metrics['semantic_calls'] == 1
        assert metrics['automatic_retries'] == metrics['session_writes'] == metrics['docx_writes'] == 0
        assert metrics['user_values'] == metrics['resolved'] == 0
        assert metrics['original_unchanged'] and metrics['http_status'] == 200
        all_tokens += metrics['usage']['total_tokens']
        all_seconds += metrics['ai_seconds']
        saved = read('validation.json')
        replay = validate_global_proposal((root / 'response.txt').read_text(), layout,
                                          fixture['gold']['project_id'], fixture['sources'])
        assert replay == saved, root
        assert replay['resolved'] == replay['writes'] == 0
        assert all(field['written_value'] is None and field['semantic_review_required'] for field in replay['fields'])
        rows = {row['key']: row for row in read('fixture-score.json')['fields']}
        fields = {field['candidate_id']: field for field in replay['fields']}
        for key in ['denominazione', 'forma', 'sede', 'cf', 'piva']:
            assert rows[key]['value_and_source_match']
            assert rows[key]['local_validation'] == 'GROUNDED_PROPOSAL'
        for key in ['firmatario', 'carica']:
            field = fields[rows[key]['candidate_id']]
            assert field['validation'] != 'GROUNDED_PROPOSAL'
            assert field.get('value') is None
        for key in ['corrispondenza', 'polizza']:
            field = fields[rows[key]['candidate_id']]
            assert field['validation'] == 'REVIEW_REQUIRED' and len(field['alternatives']) == 2
            assert field['value'] is None
        if suffix == 'c':
            for key in ['dt_nome', 'dt_qualifica', 'dt_ordine', 'dt_albo']:
                assert rows[key]['value_and_source_match']
                field = fields[rows[key]['candidate_id']]
                assert field['subject_binding']['result'] == 'literal_match'
                assert field['validation'] == 'REJECTED'
            assert rows['dt_albo']['actual_value'] == '5739'
# Include the frozen historical response used in the offline counterfactual;
# all code/input/HTTP/gold needed to inspect/reproduce the original are retained.
roots.append(base / 'alternatives-v6b-20261011-run3')
for name in ['test_compilation_global_bindings.py', 'test_compilation_global_sparse.py',
             'test_compilation_global_alternatives.py', 'test_compilation_global_conditions.py']:
    shutil.copy2(repo / 'backend/tests' / name, checks / name)
# Used only for a byte scan, never printed or included in any artifact.
secret = resolve_project_settings('prova').api_key
assert secret
roots += [checks, analysis]
files = sorted({file for root in roots for file in root.rglob('*') if file.is_file()
                and '__pycache__' not in file.parts
                and file.name not in {'bundle-manifest.json', 'bundle-summary.json'}})
files += public + [repo / 'docs/benchmark-persona-ruolo-2026-10-11.md',
                   repo / 'docs/proposta-globale-compilazione.md']
assert len(files) == len(set(files))
for file in files:
    assert file.suffix not in {'.db', '.sqlite', '.sqlite3', '.pyc'}
    assert file.name not in {'.env', '.ai-key'}
    assert secret.encode() not in file.read_bytes(), str(file.relative_to(repo))
manifest = {str(file.relative_to(repo)): hashlib.sha256(file.read_bytes()).hexdigest() for file in files}
manifest_file = analysis / 'bundle-manifest.json'
manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
files.append(manifest_file)
target = repo / 'docs/benchmarks/2026-10-11-labirinto-subject-binding-audit.tar.gz'
with tarfile.open(target, 'w:gz') as archive:
    for file in files:
        archive.add(file, arcname=str(file.relative_to(repo)), recursive=False)
with tarfile.open(target, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(files)
    for file in files:
        assert archive.extractfile(str(file.relative_to(repo))).read() == file.read_bytes()
digest = hashlib.sha256(target.read_bytes()).hexdigest()
(target.parent / (target.name + '.sha256')).write_text(f'{digest}  {target.name}\n')
summary = {'files': len(files), 'bytes': target.stat().st_size, 'sha256': digest,
           'real_new_captures_verified': 9, 'validator_replays_equal': 9,
           'historical_capture_included': 1, 'frozen_code_verified': True,
           'same_catalog_and_sources_as_baseline': True, 'secrets_and_db_excluded': True,
           'originals_unchanged': True, 'total_real_new_tokens': all_tokens,
           'total_real_new_ai_seconds': all_seconds}
(analysis / 'bundle-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
