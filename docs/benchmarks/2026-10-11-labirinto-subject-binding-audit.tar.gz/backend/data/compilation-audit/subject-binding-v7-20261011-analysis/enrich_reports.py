"""Attach actual software checks to the three complete, immutable-capture reports."""
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[4]
checks = {
    'initial_targeted': {'passed': 109, 'seconds': 5.06},
    'extended_before_schema_expectation_fix': {'passed': 294, 'failed': 1, 'seconds': 12.87},
    'full_before_schema_expectation_fix': {'passed': 1700, 'failed': 1, 'seconds': 110.36},
    'targeted_corrected': {'passed': 295, 'seconds': 13.38},
    'full_corrected': {'passed': 1701, 'seconds': 106.31},
    'targeted_second_prompt': {'passed': 295, 'seconds': 12.06},
    'full_second_prompt': {'passed': 1701, 'seconds': 104.52},
    'targeted_final': {'passed': 295, 'seconds': 11.95},
    'full_final': {'passed': 1701, 'seconds': 105.41},
    'ruff': 'passed after fixing one long line; initial failure saved',
    'fixture_check': 'passed; original, corpus, gold unchanged across nine captures',
    'cli_help': 'passed', 'diff_check': 'passed',
    'frontend': 'unchanged/not run',
    'providers': 'software suites simulated where needed, new role gates without LLM; nine separate real DeepSeek calls',
}
for suffix in ['', 'b', 'c']:
    path = repo / f'docs/benchmarks/2026-10-11-labirinto-subject-binding-v7{suffix}.json'
    report = json.loads(path.read_text())
    report['experiment'] = f'subject-binding-v7{suffix}'
    if suffix:
        report['comparison'][f'subject_binding_v7{suffix}'] = report['comparison'].pop('subject_binding_v7')
    report['software_checks'] = checks
    report['review_notes'][-1] = 'Explicit signer designation positive covered in software; final real director literal role check passes in 3/3.'
    report['review_notes'].append('Final coverage 17/22, five type checkbox omissions; no claim of general completeness improvement.')
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
root = repo / 'backend/data/compilation-audit/subject-binding-v7-20261011-checks'
(root / 'iterations.json').write_text(json.dumps(checks, indent=2) + '\n')
