"""Real DeepSeek calls on isolated copies of the reported session; never live writes.

Checkpoint replay, not a new analysis/coverage benchmark. Four frozen cases.
"""
import asyncio
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from io import BytesIO
from pathlib import Path

import httpx
from docx import Document
from docx.oxml.ns import qn

from app import ai_profiles, intents
from app.db import DEFAULT_DB_PATH, DEFAULT_STORAGE_PATH
from app.docx_templates import DRAFT_NOTICE, text_of
from app.main import app

ROOT = Path(__file__).resolve().parent
PRIVATE = ROOT / 'runtime'
PRIVATE.mkdir(exist_ok=False)
SID = sys.argv[1]
secret = ''
case = ROOT
calls = 0
metrics = []

def save(name, value):
    path = case / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
    path.write_text(raw.replace(secret, '[REDACTED]') + '\n' if secret else raw + '\n')

def digest(value):
    return hashlib.sha256(value).hexdigest()

with sqlite3.connect(DEFAULT_DB_PATH.resolve().as_uri() + '?mode=ro', uri=True) as live:
    live.row_factory = sqlite3.Row
    row = dict(live.execute('SELECT * FROM compilation_sessions WHERE id=?', (SID,)).fetchone())
    state = json.loads(row['state_json'])
    profile = live.execute("SELECT id FROM ai_profiles WHERE provider='deepseek' AND model='deepseek-flash'").fetchone()[0]
    form = dict(live.execute('SELECT * FROM project_files WHERE id=?', (row['form_id'],)).fetchone())
    with sqlite3.connect(PRIVATE / 'baseline.db') as copied:
        live.backup(copied)
original_path = DEFAULT_STORAGE_PATH / form['storage_path']
original_sha = digest(original_path.read_bytes())
artifact = DEFAULT_STORAGE_PATH / state['global_compilation']['artifact_path']
first_dialogue = next(json.loads(p.read_text()) for p in artifact.glob('dialogue/*/result.json')
                      if (json.loads(p.read_text()).get('question') or {}).get('kind') == 'clarifications')
save('protocol.json', {'head': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
     'session': SID, 'version': row['version'], 'model':'deepseek-flash', 'original_sha256': original_sha,
     'cases':['current-si','current-siii','skip-si','confirm-si'],
     'method':'Replay real persisted checkpoint and archived first dialogue on private SQLite/storage copies. No new global analysis.',
     'application_changes_during_benchmark':False, 'simulated_providers':False})

transport = intents.request_model_content
async def observe(client, settings, body, timeout, **kwargs):
    global calls
    assert settings.provider == 'deepseek' and settings.model == 'deepseek-flash'
    calls += 1
    number = calls
    save(f'planner-{number}-request.json', {'body':body,'schema':kwargs.get('response_schema')})
    started = time.perf_counter()
    result = await transport(client,settings,body,timeout,**kwargs)
    save(f'planner-{number}-response.json', {'raw':result[0],'model':result[1],
                                         'usage':result[2],'seconds':time.perf_counter()-started})
    return result
intents.request_model_content = observe

async def run(name, consent, reset):
    global case, calls, secret
    case, calls = ROOT / name, 0
    runtime = PRIVATE / name
    runtime.mkdir()
    snapshot = runtime / 'mapi.db'
    with sqlite3.connect(PRIVATE / 'baseline.db') as frozen, sqlite3.connect(snapshot) as copied:
        frozen.backup(copied)
        if reset:
            initial = json.loads(row['state_json'])
            initial['global_compilation']['dialogue'] = first_dialogue
            copied.execute('UPDATE compilation_sessions SET state_json=? WHERE id=?',
                           (json.dumps(initial,ensure_ascii=False),SID))
            # Match the archived checkpoint's chat history, only in this private fixture.
            copied.execute('DELETE FROM conversation_turns WHERE conversation_id=? AND id>=180',
                           (row['conversation_id'],))
    shutil.copy2(DEFAULT_DB_PATH.with_suffix('.ai-key'), snapshot.with_suffix('.ai-key'))
    uploads = runtime / 'uploads'
    copied_artifact = uploads / state['global_compilation']['artifact_path']
    shutil.copytree(artifact,copied_artifact)
    local_original = uploads / form['storage_path']
    local_original.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(original_path,local_original)
    os.environ.update(MAPI_DB_PATH=str(snapshot), MAPI_STORAGE_PATH=str(uploads),
                      MAPI_KNOWLEDGE_PATH=str(runtime/'knowledge'))
    project = row['project_id']
    path = f'/api/projects/{project}/compilation-sessions/{SID}'
    started = time.perf_counter()
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://isolated',timeout=400) as client:
        r = await client.put(f'/api/projects/{project}/ai-model',json={'profile_id':profile})
        assert r.status_code == 200,r.text
        secret = ai_profiles.resolve_project_settings(project).api_key
        s = (await client.get(path)).json()
        save('before.json',s)
        for index, message in enumerate(([reset] if reset else []) + [consent],start=1):
            body = {'question':message,'document_id':row['form_id'],
                    'conversation_id':row['conversation_id'],'compilation_session_id':SID,
                    'compilation_version':s['version']}
            save(f'turn-{index}-request.json',body)
            r = await client.post(f'/api/projects/{project}/answer',json=body)
            save(f'turn-{index}-response.json',{'status':r.status_code,'body':r.json()})
            assert r.status_code == 200,r.text
            s = (await client.get(path)).json()
            if s['chat']['auto_continue']:
                r = await client.post(path+'/resolve',json={'version':s['version'],'automatic':True})
                save(f'turn-{index}-resolve.json',{'status':r.status_code,'body':r.json()})
                assert r.status_code == 200,r.text
                s = r.json()
            save(f'turn-{index}-state.json',s)
        assert s['status'] == 'GENERATED',s['global_compilation']['dialogue']['message']
        assert s['chat']['question'] is None
        run = s['last_generation']
        for kind,url in run['downloads'].items():
            r = await client.get(url)
            assert r.status_code == 200
            if kind == 'report':
                report = r.json(); save('report.json',report)
            else:
                (case/f'{kind}.docx').write_bytes(r.content)
        original = Document(BytesIO((case/'template.docx').read_bytes()))
        draft = Document(BytesIO((case/'docx.docx').read_bytes()))
        old, new = [list(d.element.body.iter(qn('w:tbl'))) for d in (original,draft)]
        changes = []
        for t,(bt,at) in enumerate(zip(old,new,strict=True)):
            for r,(br,ar) in enumerate(zip(bt.findall(qn('w:tr')),at.findall(qn('w:tr')),strict=True)):
                for c,(bc,ac) in enumerate(zip(br.findall(qn('w:tc')),ar.findall(qn('w:tc')),strict=True)):
                    if text_of(bc) != text_of(ac): changes.append(f't{t}.r{r}.c{c}')
        assert set(changes) == {f['cell_id'] for f in report['fields']}
        for f in report['fields']:
            t,r,c = (int(p[1:]) for p in f['cell_id'].split('.'))
            assert text_of(new[t].findall(qn('w:tr'))[r].findall(qn('w:tc'))[c]) == f['written_value']
            assert f['provenance'] == 'SOURCE'
        assert draft.paragraphs[0].text == DRAFT_NOTICE
        assert [p.text for p in original.paragraphs] == [p.text for p in draft.paragraphs[1:]]
        assert digest((case/'template.docx').read_bytes()) == original_sha
        expected_empty = name != 'confirm-si'
        assert (report['written_field_count']==0) == expected_empty
        assert not s['global_compilation']['dialogue'].get('user_values')
        if expected_empty:
            assert report['user_review']['confirmed_condition_ids'] == []
        shutil.copytree(copied_artifact,case/'analysis',dirs_exist_ok=True)
        save('conversation.json',(await client.get(f'/api/projects/{project}/conversations/{row["conversation_id"]}')).json())
        summary = {'case':name,'status':s['status'],'version':s['version'],'planner_calls':calls,
                   'seconds':time.perf_counter()-started,'written':report['written_field_count'],
                   'user_factual_values':0,'answers':s['global_compilation']['dialogue'].get('answers',{}),
                   'materialized_cells':changes,'message':s['global_compilation']['dialogue']['message']}
        save('summary.json',summary); metrics.append(summary)
        print(json.dumps(summary,ensure_ascii=False),flush=True)

async def main():
    await run('current-si','si',None)
    await run('current-siii','siii',None)
    await run('skip-si','si','senti lascia in bianco')
    await run('confirm-si','si','Confermo entrambe le condizioni indicate.')

try:
    asyncio.run(main())
finally:
    case = ROOT
    save('metrics.json',metrics)
    with sqlite3.connect(DEFAULT_DB_PATH.resolve().as_uri()+'?mode=ro',uri=True) as live:
        latest = live.execute('SELECT version,state_json FROM compilation_sessions WHERE id=?',(SID,)).fetchone()
    integrity = {'live_session_unchanged':latest==(row['version'],row['state_json']),
                 'original_unchanged':digest(original_path.read_bytes())==original_sha}
    save('integrity.json',integrity)
    assert all(integrity.values())
