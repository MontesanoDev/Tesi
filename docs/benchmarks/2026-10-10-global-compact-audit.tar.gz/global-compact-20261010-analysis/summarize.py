"""Read captured responses only; no provider/application mutations."""
import hashlib
import json
from collections import Counter
from pathlib import Path

root = Path('backend/data/compilation-audit')
analysis = root / 'global-compact-20261010-analysis'
baseline = json.loads((root/'global-conditions-20261010-run2/metrics.json').read_text())
previous_input = json.loads((root/'global-conditions-20261010-run2/input.json').read_text())
ids = ['t0.r5.c1','t0.r6.c1','t0.r7.c1','t0.r9.c1','t0.r10.c1',
       't0.r0.c1','t0.r3.c1','t0.r4.c1','t0.r8.c1','t0.r11.c1',
       't26.r0.c1','t26.r1.c1','t26.r3.c1','t26.r4.c1','t26.r2.c1',
       't25.r3.c1','t40.r0.c1','p55.cb0']
runs = []
for number in range(1,7):
    directory = root / f'global-compact-20261010-run{number}'
    metrics = json.loads((directory/'metrics.json').read_text())
    data = json.loads((directory/'input.json').read_text())
    code = json.loads((directory/'code.json').read_text())
    row = {'name':directory.name, 'metrics':metrics, 'frozen_commit':code['head'],
           'code_status':code['status'],
           'input_sha256':hashlib.sha256((directory/'input.json').read_bytes()).hexdigest(),
           'same_form_as_previous':data['form']==previous_input['form'],
           'same_sources_as_previous':data['sources']==previous_input['sources'],
           'accepted_proposals':0, 'resolved':0, 'writes':0,
           'comparison_previous_v2_run2': {
              'total_token_change_percent':100*(metrics['usage']['total_tokens']/baseline['usage']['total_tokens']-1),
              'ai_time_change_percent':100*(metrics['ai_seconds']/baseline['ai_seconds']-1),
              'output_token_change_percent':100*(metrics['usage']['completion_tokens']/baseline['usage']['completion_tokens']-1),
              'note':'Different contract/work allocation; failures are not usable compilations.'}}
    response_file=directory/'response.txt'
    if response_file.exists():
        raw=json.loads(response_file.read_text())
        expected=set(data['form']['candidates']); fields=set(raw['fields']); deferred=raw['deferred']
        paragraph_ids = data.get('form_review_paragraph_ids',data.get('condition_scan_paragraph_ids'))
        paragraphs={p['id']:p['text'] for b in data['form']['blocks'] for p in b['paragraphs']}
        sources={s['chunk_id']:s for s in data['sources']}
        row['raw_counts']={'facts':len(raw['facts']),'conditions':len(raw['conditions']),
                           'fields':len(raw['fields']),'deferred':len(raw['deferred']),
                           'dispositions':dict(Counter(f['disposition'] for f in raw['fields'].values()))}
        row['candidate_partition_issues']={
            'missing':sorted(expected-fields-set(deferred)),
            'unknown_fields':sorted(fields-expected),
            'unknown_deferred':sorted(set(deferred)-expected),
            'overlap':sorted(fields&set(deferred)),
            'duplicate_deferred':len(deferred)-len(set(deferred))}
        row['condition_scope_unknown_targets']={
            key:sorted(set(c['applies_to'])-expected) for key,c in raw['conditions'].items()
            if set(c['applies_to'])-expected}
        refs={f.get('fact_id') for f in raw['fields'].values()} | {
            f for c in raw['conditions'].values() for f in c['fact_ids']}
        row['unreferenced_facts']=sorted(set(raw['facts'])-refs)
        row['reviewed_paragraphs_match']=set(raw.get('reviewed_paragraph_ids',raw.get('condition_scan',{})))==set(paragraph_ids)
        row['manual_annotations']=[]
        for cid in ids:
            field=raw['fields'].get(cid)
            fact=raw['facts'].get(field.get('fact_id')) if field else None
            value=fact.get('value') if fact else None
            if field is None:
                verdict='safe_unwritten_unclassified'
                reason='ID rinviato/assente; non è un requisito missing né un valore risolto.'
            elif field['disposition'] not in {'value','not_applicable'}:
                verdict='safe_unwritten'
                reason='Proposta senza valore; output comunque rifiutato integralmente.'
            elif field['disposition']=='value' and fact is None:
                verdict='invalid_value_without_fact'
                reason='Dichiara value ma non referenzia un fatto SOURCE valido.'
            elif cid in ids[:5]:
                verdict='supported_standard_value_proposal'
                reason='Valore societario presente nelle SOURCE demo; non accettato/RESOLVED perché envelope rifiutato.'
            elif cid in {'t0.r0.c1','t0.r3.c1'}:
                verdict='unsupported_signatory_role'
                reason='Il ruolo aziendale non prova chi sottoscrive questa specifica domanda.'
            elif cid=='t0.r4.c1':
                verdict='unavailability_is_not_a_value'
                reason='Indisponibilità della procura non è un estremo di procura; condizione non determinata.'
            elif cid=='t0.r8.c1':
                verdict='wrong_applicability'
                reason='FORM richiede la sede operativa solo se diversa; SOURCE indica coincidenza. Operatore semantic non verifica il vincolo.'
            elif cid in {'t26.r0.c1','t26.r1.c1','t26.r3.c1','t26.r4.c1'}:
                verdict='supported_atomic_professional_value_proposal'
                reason='Proprietà separata supportata dalle SOURCE del direttore tecnico; ramo/assegnazione non approvati dal backend.'
            elif cid=='t26.r2.c1':
                verdict='unsupported_qualification_date'
                reason='Non risulta una data di abilitazione nelle SOURCE; nessuna disponibilità inferibile.'
            elif cid=='t25.r3.c1':
                verdict='wrong_property_or_unavailable'
                reason='REA non equivale al numero/data CCIAA; una dichiarazione di indisponibilità non è un valore utilizzabile.'
            elif cid=='t40.r0.c1':
                verdict='unsupported_participation_branch'
                reason='La denominazione aziendale non dimostra il ruolo di consorziata esecutrice nella pratica.'
            elif cid=='t0.r11.c1':
                verdict='telephone_only_not_both_contacts'
                reason='Telefono aziendale attestato; non dimostra anche un cellulare.'
            else:
                verdict='checkbox_not_approved'
                reason='Selezione non approvata; checkbox strutturale non scritta e ambito da verificare.'
            proofs=[]
            for citation in (fact or {}).get('evidence',[]):
                source=sources.get(citation['chunk_id'],{})
                proofs.append({**citation,**{k:source.get(k) for k in [
                    'file_id','source_name','role','scope','project_id','category','chunk_index']}})
            row['manual_annotations'].append({
                'candidate_id':cid,'proposal':field,'model_proposed_value':value,
                'proposed_source_evidence':proofs,'manual_verdict':verdict,'reason':reason,
                'backend_acceptance':'whole response rejected; no per-field audit was reached',
                'written_value':None,'resolved':False})
        (analysis/f'run{number}-annotations.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
    else:
        row['diagnostic_prefix']=json.loads((analysis/'run1-prefix-diagnostic.json').read_text())
    runs.append(row)
result={'date':'2026-10-10','experiment':'compact single-call FORM inventory and atomic SOURCE proposals',
        'provider':'deepseek','model':'deepseek-flash','real_calls':6,'automatic_retries':0,
        'frozen_pairs':[[1,2],[3,4],[5,6]],'same_form_and_corpus_all_runs':all(r['same_form_as_previous'] and r['same_sources_as_previous'] for r in runs),
        'pair_inputs_byte_identical':[runs[a-1]['input_sha256']==runs[b-1]['input_sha256'] for a,b in [[1,2],[3,4],[5,6]]],
        'original_sha256':runs[0]['metrics']['original_sha256'],'candidate_count':307,'source_count':51,
        'session_writes':0,'docx_writes':0,'resolved':0,'user_values':0,'production_v1_changed':False,
        'runs':runs,'aggregate_usage':{k:sum(r['metrics']['usage'][k] for r in runs) for k in ['prompt_tokens','completion_tokens','total_tokens']},
        'aggregate_ai_seconds':sum(r['metrics']['ai_seconds'] for r in runs),
        'decision':'DO_NOT_ACTIVATE: output shortened and facts more atomic, but all six responses rejected; no usable correctness improvement demonstrated',
        'limits':['Literal grounding and semantic applicability are different guarantees.',
                  'Model metadata/property/scope can still be wrong; no independently accepted values.',
                  'Reviewed paragraph receipt does not prove semantic condition completeness.',
                  'Deferred is unclassified, not necessarily missing/mandatory.',
                  'Known SOURCE values can be proposed for wrong participation/signatory roles.',
                  'All final conditions are semantic/unknown; same/different inference not observed.',
                  'Sampled manual annotations; not a review of every candidate.',
                  'Post-benchmark generic plural unavailability guard tested with software, not another real model call.'],
        'next_step_proposal':'Discuss removing redundant model-generated partitions and representing condition scopes with real structural context; keep all omitted positions unresolved, reject invented destinations. No automatic activation.'}
(analysis/'benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
Path('docs/benchmarks/2026-10-10-compilation-global-compact.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for row in runs:
 m=row['metrics'];print(row['name'],round(m['ai_seconds'],2),m['usage']['total_tokens'],m['error_type'],m['error'])
print('total',result['aggregate_usage'],round(result['aggregate_ai_seconds'],2))
