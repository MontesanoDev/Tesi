"""Offline verification, never invokes a model or mutates live state."""
import hashlib
import json
import statistics
from collections import Counter
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn
from app.docx_templates import DRAFT_NOTICE, text_of
from scripts.benchmark_compilation_dialogue import FIXTURE, load_fixture

root = Path(__file__).resolve().parent
manifest, contexts, cases = load_fixture(FIXTURE)
results = json.loads((root/'dialogue/results.json').read_text())
assert [r['id'] for r in results] == [c['id'] for c in cases]
assert len(results) == 43
assert all(c['schema_valid'] for r in results for c in r['calls'])
assert all(r['effects']['provenance_ok'] for r in results)
assert all(not r['effects']['unexpected_recipients'] for r in results)
assert all(r['error'] is None for r in results)
materialization = []
for r, case in zip(results, cases, strict=True):
    folder = root/'dialogue'/r['id']
    before, after = [json.loads((folder/name).read_text()) for name in ('before.json','after.json')]
    context = contexts[case['context']]
    values = {}
    for slot in context['slots']:
        answer = after['global_compilation']['dialogue']['answers'].get(slot['key'], {})
        if answer.get('value') is not None:
            values[str(slot['slot'])] = answer['value']
    assert r['effects']['values'] == values
    if r['id'] == 'correction-outside':
        assert before == after, 'Wrong field still mutated'
        assert r['effects']['values'] == {}
    if not r['generated']:
        continue
    report = json.loads((folder/'generated-report.json').read_text())
    original, draft = [Document(folder/name) for name in ('template.docx','bozza.docx')]
    old, new = [list(d.element.body.iter(qn('w:tbl'))) for d in (original, draft)]
    changes = []
    for t, (bt, at) in enumerate(zip(old, new, strict=True)):
        for row, (br, ar) in enumerate(zip(bt.findall(qn('w:tr')), at.findall(qn('w:tr')), strict=True)):
            for col, (bc, ac) in enumerate(zip(br.findall(qn('w:tc')), ar.findall(qn('w:tc')), strict=True)):
                if text_of(bc) != text_of(ac):
                    changes.append(f't{t}.r{row}.c{col}')
    assert set(changes) == {f['cell_id'] for f in report['fields']}
    for f in report['fields']:
        t, row, col = (int(s[1:]) for s in f['cell_id'].split('.'))
        assert text_of(new[t].findall(qn('w:tr'))[row].findall(qn('w:tc'))[col]) == f['written_value']
        assert f['provenance'] == 'USER' and f['source_evidence'] == []
    assert hashlib.sha256((folder/'template.docx').read_bytes()).hexdigest() == manifest['files']['modulo-dialogo.docx']
    assert draft.paragraphs[0].text == DRAFT_NOTICE
    assert [p.text for p in draft.paragraphs[1:]] == [p.text for p in original.paragraphs]
    materialization.append({'case': r['id'], 'written': report['written_field_count'],
                            'actual_cells': changes, 'original_unchanged': True})

calls = [c for r in results for c in r['calls']]
def cost(subset):
    return {'calls': len(subset), 'seconds': sum(c['seconds'] for c in subset),
            'input_tokens': sum(c['usage']['prompt_tokens'] for c in subset),
            'output_tokens': sum(c['usage']['completion_tokens'] for c in subset),
            'total_tokens': sum(c['usage']['total_tokens'] for c in subset)}
summary = {'cases': len(results), 'strict_gold_passed': sum(r['score']['passed'] for r in results),
           'failed_cases': [r['id'] for r in results if not r['score']['passed']],
           'model_response_names': dict(Counter(c['model'] for c in calls)),
           'all_schema_valid': True, 'backend_exceptions': 0,
           'user_slot_mutations': sum(len(r['effects']['actions']) for r in results),
           'user_value_mutations': sum(len(r['effects']['values']) for r in results),
           'turn_seconds': sum(r['seconds'] for r in results),
           'median_turn_seconds': statistics.median(r['seconds'] for r in results),
           'max_turn_seconds': max(r['seconds'] for r in results),
           'all': cost(calls), 'routing': cost([c for c in calls if c['stage']=='routing']),
           'scope_check': cost([c for c in calls if c['stage']=='scope_check']),
           'scope_check_median_seconds': statistics.median(c['seconds'] for c in calls if c['stage']=='scope_check'),
           'generation_count': len(materialization), 'materialization': materialization,
           'wrong_field_state_unchanged': True, 'source_promotions': 0,
           'scope': 'Prepared checkpoints; not new full compilation or SOURCE-quality evaluation'}

checks = json.loads((root/'guard/results.json').read_text())
assert len(checks) == 9
for r in checks:
    folder = root/'guard'/r['case']
    before, after = [json.loads((folder/name).read_text()) for name in ('before.json','after.json')]
    assert r['effects']['provenance_ok'] and not r['effects']['unexpected_recipients']
    if not r['allowed']:
        assert before == after
assert all(r['passed'] for r in checks), 'Independent guard gold failure'
guard_calls = [json.loads((root/'guard'/r['case']/'response.json').read_text()) for r in checks]
assert all(c['schema_valid'] for c in guard_calls)
summary['independent_guard'] = {'cases': len(checks), 'passed': sum(r['passed'] for r in checks),
                                'cost': cost(guard_calls),
                                'method': 'Prepared proposals, first replaying actual baseline failure; no new router outputs'}
(root/'verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
