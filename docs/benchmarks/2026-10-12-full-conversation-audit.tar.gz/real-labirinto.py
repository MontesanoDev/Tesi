"""Fresh Labirinto fixture/API ingestion, same real continuous conversation runner."""

import argparse
import asyncio
import importlib.util
import json
import os
import sqlite3
import subprocess
from datetime import UTC, datetime
from pathlib import Path

import httpx

from app.ai_profiles import ProfileInput, save_profile
from app.compilation_global import load_document_corpus
from app.db import init_database
from app.retrieval_settings import RetrievalInput, save_settings
from scripts.benchmark_compilation_dialogue import real_settings

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("runner", ROOT / "real-conversation.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.ROOT = ROOT / "labirinto"
runner.RUNTIME = runner.ROOT / "private-runtime"
runner.LIVE_STORAGE = runner.RUNTIME / "uploads"


async def initialize_fixture():
    settings = real_settings("prova")
    runner.SECRET = settings.api_key
    runner.RUNTIME.mkdir(parents=True, exist_ok=False)
    os.environ.update(
        MAPI_DB_PATH=str(runner.RUNTIME / "snapshot.db"),
        MAPI_STORAGE_PATH=str(runner.RUNTIME / "uploads"),
        MAPI_KNOWLEDGE_PATH=str(runner.RUNTIME / "knowledge"),
    )
    init_database()
    save_settings(RetrievalInput(backend="fts5"))
    profile = save_profile(
        ProfileInput(
            name="Real full conversation",
            provider="deepseek",
            base_url=settings.base_url,
            model=settings.model,
            api_key=settings.api_key,
            context_window=settings.context_window,
        )
    )
    fixture = Path("../demo-documents/benchmark-compilazione/v1").resolve()
    manifest = json.loads((fixture / "manifest.json").read_text())
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=runner.app), base_url="http://isolated", timeout=400
    ) as client:
        response = await client.post(
            "/api/projects",
            json={"title": "Prova", "description": "Labirinto, conversazione reale isolata"},
        )
        assert response.status_code == 201 and response.json()["id"] == "prova"
        response = await client.put(
            "/api/projects/prova/ai-model", json={"profile_id": profile["id"]}
        )
        assert response.status_code == 200
        for source in sorted((fixture / "sources").glob("*.txt")):
            response = await client.post(
                "/api/global-knowledge/files",
                data={"category": "general" if source.name.startswith("07-") else "company"},
                files={"file": (source.name, source.read_bytes())},
            )
            assert response.status_code == 201, response.text
        response = await client.post(
            "/api/projects/prova/forms",
            files={
                "file": ("modulo-benchmark.docx", (fixture / "modulo-benchmark.docx").read_bytes())
            },
        )
        assert response.status_code == 201, response.text
        form = response.json()
    with sqlite3.connect(runner.RUNTIME / "snapshot.db") as db:
        db.row_factory = sqlite3.Row
        form = dict(db.execute("SELECT * FROM project_files WHERE id=?", (form["id"],)).fetchone())
        sources = load_document_corpus(db, "prova")
    with sqlite3.connect(runner.LIVE_DB.as_uri() + "?mode=ro", uri=True) as db:
        fingerprints = runner.database_fingerprint(db)
    runner.save(
        "protocol.json",
        {
            "registered_at": datetime.now(UTC).isoformat(),
            "head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "application_files": runner.code_fingerprint(),
            "project": "prova",
            "form": form,
            "provider": settings.provider,
            "model": settings.model,
            "source_chunks": len(sources),
            "original_sha256": runner.sha((fixture / "modulo-benchmark.docx").read_bytes()),
            "fixture_manifest": manifest,
            "live_database_tables_before": fingerprints,
            "max_turns": 12,
            "max_automatic_resolves_per_turn": 3,
            "prepared_checkpoints": False,
            "real_provider": True,
            "browser": False,
            "gold_in_prompt": False,
            "note": "New isolated DB, original frozen fixture ingested via normal APIs; FTS5",
        },
    )
    runner.save("sources-before.json", sources)


async def main(args):
    if args.operation == "start":
        await initialize_fixture()
        runner.initialize = lambda: None
    await runner.run(args)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["start", "turn"])
    parser.add_argument("--message")
    args = parser.parse_args()
    if args.operation == "turn" and not args.message:
        parser.error("turn requires --message")
    asyncio.run(main(args))
