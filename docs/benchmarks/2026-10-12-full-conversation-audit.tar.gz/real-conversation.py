"""Real API conversation observer. Only private snapshot writes, no seeded state."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

import httpx

from app import ai_profiles, intents
from app import compilation_global_dialogue as dialogue
from app import compilation_global_sessions as adapter
from app.compilation_global import load_document_corpus
from app.db import get_db_path, get_storage_path
from app.main import app

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "private-runtime"
LIVE_DB = get_db_path().resolve()
LIVE_STORAGE = get_storage_path().resolve()
SECRET = ""
CALLS = []
PREFIX = ""


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
    path.write_text((raw.replace(SECRET, "[REDACTED]") if SECRET else raw) + "\n")


def code_fingerprint():
    return {str(p): sha(p.read_bytes()) for p in sorted(Path("app").rglob("*.py"))}


def database_fingerprint(db):
    result = {}
    for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
        table = row[0]
        quoted = '"' + table.replace('"', '""') + '"'
        rows = [tuple(r) for r in db.execute(f"SELECT * FROM {quoted}")]
        result[table] = sha(json.dumps(sorted(rows, key=str), default=str).encode())
    return result


def configure():
    global SECRET
    os.environ.update(
        MAPI_DB_PATH=str(RUNTIME / "snapshot.db"),
        MAPI_STORAGE_PATH=str(RUNTIME / "uploads"),
        MAPI_KNOWLEDGE_PATH=str(RUNTIME / "knowledge"),
    )
    settings = ai_profiles.resolve_project_settings("prova")
    assert settings.configured and settings.provider == "deepseek"
    assert settings.model == "deepseek-flash"
    SECRET = settings.api_key


def initialize():
    RUNTIME.mkdir(parents=True, exist_ok=False)
    with sqlite3.connect(LIVE_DB.as_uri() + "?mode=ro", uri=True) as live:
        live.row_factory = sqlite3.Row
        form = dict(
            live.execute(
                "SELECT * FROM project_files WHERE project_id=? AND kind='form' AND name=?",
                ("prova", "domanda-partecipazione.docx"),
            ).fetchone()
        )
        sources = load_document_corpus(live, "prova")
        fingerprints = database_fingerprint(live)
        with sqlite3.connect(RUNTIME / "snapshot.db") as snapshot:
            live.backup(snapshot)
    shutil.copy2(LIVE_DB.with_suffix(".ai-key"), RUNTIME / "snapshot.ai-key")
    original = LIVE_STORAGE / form["storage_path"]
    private_original = RUNTIME / "uploads" / form["storage_path"]
    private_original.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, private_original)
    save(
        "protocol.json",
        {
            "registered_at": datetime.now(UTC).isoformat(),
            "head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "application_files": code_fingerprint(),
            "project": "prova",
            "form": form,
            "provider": "deepseek",
            "model": "deepseek-flash",
            "source_chunks": len(sources),
            "original_sha256": sha(original.read_bytes()),
            "live_database_tables_before": fingerprints,
            "max_turns": 12,
            "max_automatic_resolves_per_turn": 3,
            "prepared_checkpoints": False,
            "real_provider": True,
            "browser": False,
            "gold_in_prompt": False,
        },
    )
    save("sources-before.json", sources)
    configure()


def observe_transport(original, stage):
    async def observe(client, settings, body, timeout, **kwargs):
        assert settings.provider == "deepseek" and settings.model == "deepseek-flash"
        schema = kwargs.get("response_schema") or {}
        effective_stage = "user_scope" if schema.get("title") == "ReplyScopeChecks" else stage
        index = len(CALLS) + 1
        prefix = f"{PREFIX}/call-{index:02d}-{effective_stage}"
        save(prefix + "-request.json", {"body": body, "schema": schema, "timeout": timeout})
        record = {"stage": effective_stage, "path": prefix}
        CALLS.append(record)
        start = time.perf_counter()
        try:
            result = await original(client, settings, body, timeout, **kwargs)
            record.update(seconds=time.perf_counter() - start, model=result[1], usage=result[2])
            save(prefix + "-response.json", {"raw": result[0], **record})
            return result
        except BaseException as exc:
            record.update(seconds=time.perf_counter() - start, error=type(exc).__name__)
            save(prefix + "-failure.json", record)
            raise

    return observe


async def run(args):
    global PREFIX
    if args.operation == "start":
        initialize()
    else:
        configure()
    protocol = json.loads((ROOT / "protocol.json").read_text())
    assert protocol["application_files"] == code_fingerprint(), "Application changed during run"
    intents.request_model_content = observe_transport(intents.request_model_content, "routing")
    adapter.request_model_content = observe_transport(adapter.request_model_content, "analysis")
    dialogue.request_model_content = observe_transport(dialogue.request_model_content, "narration")
    previous = (
        json.loads((ROOT / "latest-state.json").read_text()) if args.operation != "start" else None
    )
    turns = len(list(ROOT.glob("turn-*/request.json")))
    assert turns < protocol["max_turns"]
    PREFIX = f"turn-{turns + 1:02d}"
    save(
        f"{PREFIX}/process.json", {"pid": os.getpid(), "started_at": datetime.now(UTC).isoformat()}
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://isolated", timeout=400
    ) as client:
        if previous:
            path = f"/api/projects/prova/compilation-sessions/{previous['id']}"
            response = await client.get(path)
            assert response.status_code == 200
            state = response.json()
            assert state == previous, "Persisted state differs after process restart"
            save(f"{PREFIX}/reread.json", state)
            body = {
                "question": args.message,
                "document_id": state["form_id"],
                "conversation_id": state["conversation_id"],
                "compilation_session_id": state["id"],
                "compilation_version": state["version"],
            }
        else:
            body = {"question": "me lo compili?", "document_id": protocol["form"]["id"]}
        save(f"{PREFIX}/request.json", body)
        start = time.perf_counter()
        result = await client.post("/api/projects/prova/answer", json=body)
        save(
            f"{PREFIX}/response.json",
            {
                "status": result.status_code,
                "body": result.json(),
                "seconds": time.perf_counter() - start,
            },
        )
        assert result.status_code == 200, result.text
        command = result.json().get("compilation")
        sid = previous["id"] if previous else command["session_id"]
        assert not command or command.get("session_id", sid) == sid
        path = f"/api/projects/prova/compilation-sessions/{sid}"
        state = (await client.get(path)).json()
        save(f"{PREFIX}/after-answer.json", state)
        for step in range(protocol["max_automatic_resolves_per_turn"]):
            if not state["chat"]["auto_continue"]:
                break
            print(f"{PREFIX} automatic resolve {step + 1}", flush=True)
            result = await client.post(
                path + "/resolve", json={"version": state["version"], "automatic": True}
            )
            save(
                f"{PREFIX}/resolve-{step + 1}.json",
                {"status": result.status_code, "body": result.json()},
            )
            state = (await client.get(path)).json()
            save(f"{PREFIX}/after-resolve-{step + 1}.json", state)
            if result.status_code != 200:
                break
        save(f"{PREFIX}/state.json", state)
        save("latest-state.json", state)
        response = await client.get(f"/api/projects/prova/conversations/{state['conversation_id']}")
        save(f"{PREFIX}/conversation.json", response.json())
        artifact = state["global_compilation"].get("artifact_path")
        if artifact:
            shutil.copytree(get_storage_path() / artifact, ROOT / "analysis", dirs_exist_ok=True)
        if state.get("last_generation"):
            for kind, url in state["last_generation"]["downloads"].items():
                response = await client.get(url)
                assert response.status_code == 200
                if kind == "report":
                    save("generated-report.json", response.json())
                else:
                    filename = "generated.docx" if kind == "docx" else "template.docx"
                    (ROOT / filename).write_bytes(response.content)
        save(f"{PREFIX}/calls.json", CALLS)
        with sqlite3.connect(LIVE_DB.as_uri() + "?mode=ro", uri=True) as live:
            integrity = database_fingerprint(live) == protocol["live_database_tables_before"]
        original = LIVE_STORAGE / protocol["form"]["storage_path"]
        save(
            "integrity.json",
            {
                "application_unchanged": code_fingerprint() == protocol["application_files"],
                "live_tables_unchanged": integrity,
                "live_original_unchanged": sha(original.read_bytes())
                == protocol["original_sha256"],
                "private_original_unchanged": sha(
                    (get_storage_path() / protocol["form"]["storage_path"]).read_bytes()
                )
                == protocol["original_sha256"],
            },
        )
        view = state["global_compilation"]
        print(
            json.dumps(
                {
                    "session": sid,
                    "version": state["version"],
                    "status": state["status"],
                    "phase": view["phase"],
                    "proposals": view["proposal_count"],
                    "omitted": view["omitted"],
                    "chat": state["chat"],
                    "dialogue": view.get("dialogue"),
                    "calls": CALLS,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["start", "turn"])
    parser.add_argument("--message")
    args = parser.parse_args()
    if args.operation == "turn" and not args.message:
        parser.error("turn requires --message")
    asyncio.run(run(args))
