"""Offline comparison of real persisted selections, report and actual Word locations."""

import hashlib
import json
import sqlite3
from collections import Counter
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from docx.oxml.ns import qn
from lxml import etree

from app.docx_templates import DRAFT_NOTICE, text_of

ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(root):
    state = load(root / "latest-state.json")
    report = load(root / "generated-report.json")
    original = (root / "template.docx").read_bytes()
    generated = (root / "generated.docx").read_bytes()
    template, document = Document(BytesIO(original)), Document(BytesIO(generated))
    old = list(template.element.body.iter(qn("w:tbl")))
    new = list(document.element.body.iter(qn("w:tbl")))
    by_id = {f["candidate_id"]: f for f in state["global_compilation"]["fields"]}
    checks = []
    for field in report["fields"]:
        cid = field["cell_id"]
        table, row, column = (int(part[1:]) for part in cid.split("."))
        actual = text_of(new[table].findall(qn("w:tr"))[row].findall(qn("w:tc"))[column])
        if field["provenance"] == "SOURCE":
            assert by_id[cid]["selectable"]
            assert field["written_value"] == by_id[cid]["value"]
            assert field["source_evidence"] == by_id[cid]["source_evidence"]
            assert all(e["role"] == "source" for e in field["source_evidence"])
        else:
            assert field["provenance"] == "USER" and not field["source_evidence"]
        checks.append(
            {
                "candidate_id": cid,
                "label": field["label"],
                "expected": field["written_value"],
                "actual": actual,
                "match": actual == field["written_value"],
                "provenance": field["provenance"],
                "source_evidence": field["source_evidence"],
            }
        )
        assert actual == field["written_value"]
    changed = []
    for table, (before, after) in enumerate(zip(old, new, strict=True)):
        for row, (br, ar) in enumerate(
            zip(before.findall(qn("w:tr")), after.findall(qn("w:tr")), strict=True)
        ):
            for column, (bc, ac) in enumerate(
                zip(br.findall(qn("w:tc")), ar.findall(qn("w:tc")), strict=True)
            ):
                if text_of(bc) != text_of(ac):
                    changed.append(f"t{table}.r{row}.c{column}")
    assert set(changed) == {f["cell_id"] for f in report["fields"]}
    assert document.paragraphs[0].text == DRAFT_NOTICE
    assert [p.text for p in template.paragraphs] == [p.text for p in document.paragraphs[1:]]
    assert [etree.tostring(n, method="c14n") for n in template.element.iter(qn("w:sdt"))] == [
        etree.tostring(n, method="c14n") for n in document.element.iter(qn("w:sdt"))
    ]
    assert sha(original) == state["template_sha256"]
    assert state["summary"]["resolved"] == 0
    with ZipFile(BytesIO(original)) as old_zip, ZipFile(BytesIO(generated)) as new_zip:
        assert set(old_zip.namelist()) == set(new_zip.namelist())
        changed_parts = [p for p in old_zip.namelist() if old_zip.read(p) != new_zip.read(p)]
    assert changed_parts == ["word/document.xml"]
    deferred = state["global_compilation"]["dialogue"].get("answers", {})
    deferred_fields = {
        key.removeprefix("field:")
        for key, answer in deferred.items()
        if key.startswith("field:") and answer["action"] in {"SKIP", "UNKNOWN"}
    }
    assert not deferred_fields.intersection(changed)
    turns = []
    for folder in sorted(root.glob("turn-*")):
        if not (folder / "state.json").exists():
            continue
        final = load(folder / "state.json")
        reply = load(folder / "response.json")
        turns.append(
            {
                "turn": folder.name,
                "request": load(folder / "request.json"),
                "answer": reply["body"]["answer"],
                "command": reply["body"].get("compilation"),
                "seconds_answer": reply["seconds"],
                "version": final["version"],
                "status": final["status"],
                "paused": final["chat"]["paused_by_user"],
                "question": final["chat"]["question"],
                "calls": load(folder / "calls.json"),
                "pid": load(folder / "process.json")["pid"],
            }
        )
    calls = [call for turn in turns for call in turn["calls"]]
    costs = {}
    for stage in sorted({c["stage"] for c in calls}):
        subset = [c for c in calls if c["stage"] == stage]
        costs[stage] = {
            "calls": len(subset),
            "seconds": sum(c["seconds"] for c in subset),
            "prompt_tokens": sum(c["usage"]["prompt_tokens"] for c in subset),
            "completion_tokens": sum(c["usage"]["completion_tokens"] for c in subset),
            "total_tokens": sum(c["usage"]["total_tokens"] for c in subset),
        }
    with sqlite3.connect(root / "private-runtime/snapshot.db") as db:
        db.row_factory = sqlite3.Row
        revisions = [
            dict(r)
            for r in db.execute(
                "SELECT version,event_json,created_at FROM compilation_session_revisions "
                "WHERE session_id=? ORDER BY version",
                (state["id"],),
            )
        ]
    for r in revisions:
        r["event"] = json.loads(r.pop("event_json"))
    result = {
        "candidate_count": state["summary"]["total"],
        "proposal_count": state["global_compilation"]["proposal_count"],
        "omitted_positions": state["global_compilation"]["omitted"],
        "resolved": state["summary"]["resolved"],
        "state": state["status"],
        "source_written": sum(f["provenance"] == "SOURCE" for f in checks),
        "user_written": sum(f["provenance"] == "USER" for f in checks),
        "written_count": len(checks),
        "checks": checks,
        "changed_cells": changed,
        "unselected_cells_unchanged": True,
        "paragraphs_unchanged_except_banner": True,
        "native_controls_unchanged": True,
        "package_changed_parts": changed_parts,
        "deferred_fields_not_written": sorted(deferred_fields),
        "original_unchanged": True,
        "partial_draft": True,
        "ready_for_submission": False,
        "costs": costs,
        "api_calls": len(calls),
        "total_tokens": sum(c["usage"]["total_tokens"] for c in calls),
        "ai_seconds": sum(c["seconds"] for c in calls),
        "user_turns_including_start": len(turns),
        "answer_actions": dict(Counter(a["action"] for a in deferred.values())),
        "turns": turns,
        "revisions": revisions,
        "integrity": load(root / "integrity.json"),
    }
    (root / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k not in {"turns", "revisions", "checks", "changed_cells"}
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return result


if __name__ == "__main__":
    all_results = {}
    for name, root in [("catanzaro", ROOT), ("labirinto", ROOT / "labirinto")]:
        if (root / "generated.docx").exists():
            all_results[name] = verify(root)
    (ROOT / "summary.json").write_text(json.dumps(all_results, ensure_ascii=False, indent=2) + "\n")
