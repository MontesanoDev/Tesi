# Scenario del gold Minervino — revisione da controllare

**Bozza del 16 ottobre 2026. Non congelata: in attesa dell'OK dell'utente.**

Word da controllare:
[domanda-iscrizione.GOLD-SINTETICO-REVISIONE-1.docx](domanda-iscrizione.GOLD-SINTETICO-REVISIONE-1.docx).

La revisione ripristina il blocco del direttore tecnico e le etichette originali
nei paragrafi della società e dei soci. Mantiene dati e scelte del gold
dell'utente, comprese le note didattiche, le sei preferenze e le tre checkbox
selezionate. Il file precedente è conservato.

## Dati documentati

Le fonti di riferimento rimangono generalita-mapi.md, visura simulata e
integrazione-company.md attualmente nella Company KB. Non sono state modificate.

- Operatore: Mapi Ingegneria S.r.l.
- Rappresentante legale documentato dal 2 ottobre 2026: Leonardo Montemurro.
- Soci: Luca Ferri, Elisa Romano e Andrea Greco.
- Direttore tecnico: Elisa Romano, Ingegnere, CF RMNLSI85C47A662Y,
  Ordine degli Ingegneri di Bari, sezione A, provincia Bari,
  iscrizione dal 18/05/2015, numero 8421.
- Gli identificativi sintetici rimangono quelli del gold e delle fonti.
  La policy di valutazione della loro validità formale è ancora da confermare.

## Decisioni della pratica contenute nel gold dell'utente

Queste scelte non devono essere inferite dalla Company KB. Nel benchmark
andranno comunicate al sistema tramite istruzioni o risposte USER.

| Decisione | Scelta contenuta nel gold |
|---|---|
| Partecipante | Mapi Ingegneria S.r.l., ramo società di ingegneria |
| Firmatario | Leonardo Montemurro, in qualità di rappresentante legale |
| Luogo e data della bozza | Bari, 15/10/2026 |
| Dichiarazione generale | Checkbox di veridicità selezionata nello scenario sintetico |
| Professionisti esecutori | Checkbox relativa ai professionisti selezionata |
| Firma digitale | Vuota, da non simulare |

### Preferenze

| Voce | Fascia / scelta |
|---|---|
| Edilizia scolastica e sanitaria | B |
| Strutture | B |
| Opere stradali | A |
| CSP/CSE | A |
| Collaudo statico | X |
| Certificato di prestazione energetica | X |

Le marcature sono sei; le altre celle rimangono vuote.

### Designazioni specifiche

| Persona | Designazione contenuta nel gold |
|---|---|
| Elisa Romano | Progettazione strutturale e direzione lavori |
| Luca Ferri | Opere stradali e collaudo statico |
| Andrea Greco | Progettazione edilizia, certificazione energetica e CSP/CSE |
| Andrea Greco | Integrazione delle prestazioni specialistiche |

Questa tabella registra le scelte autoriali del caso. Non introduce prove di
abilitazioni o requisiti ulteriori rispetto alle fonti.

## Prima del congelamento

- Controllare il Word revisionato, in particolare direttore, soci e impaginazione.
- Registrare l'OK dell'utente ed eventuali altre correzioni.
- Definire quali scelte sono fornite all'avvio e quali soltanto dopo le domande.
- Completare la mappa delle aspettative e dei vuoti nelle destinazioni originali.
- Chiarire policy degli identificativi sintetici e perimetro degli allegati.
- Decidere come valutare le note autoriali finali, distinte dai fatti aziendali.
- Solo successivamente congelare versione, fonti, scenario, gold e manifest.

Il Word gold e questa scheda di valutazione non sono stati caricati nella KB.
Le risposte previste dal caso diventano input del sistema soltanto nel momento
definito dal protocollo.
